package refactoringexample.analysis;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;

import com.ibm.wala.ipa.callgraph.CGNode;
import com.ibm.wala.ipa.callgraph.CallGraph;
import com.ibm.wala.ssa.SSACheckCastInstruction;
import com.ibm.wala.ssa.SSAComparisonInstruction;
import com.ibm.wala.ssa.SSAConditionalBranchInstruction;
import com.ibm.wala.ssa.SSAFieldAccessInstruction;
import com.ibm.wala.ssa.SSAGotoInstruction;
import com.ibm.wala.ssa.SSAInstanceofInstruction;
import com.ibm.wala.ssa.SSAInstruction;
import com.ibm.wala.ssa.SSAInvokeInstruction;
import com.ibm.wala.ssa.SSAReturnInstruction;
import com.ibm.wala.types.MemberReference;
import com.ibm.wala.types.MethodReference;
import com.ibm.wala.types.TypeReference;
import com.ibm.wala.util.strings.Atom;

public class PatternAnalysis {
   private CallGraph cg;
	public PatternAnalysis(CallGraph cg) {
		this.cg=cg;
	}

    public void patternAnalysis(String typeTemp, MethodDeclaration m, CompilationUnit root, IJavaElement element) {
//    	System.out.println("patternAnalysis:"+typeTemp);
    	String typeName = dealTypeName(typeTemp);
    	String methodName=m.getName().toString();
    	if (typeName != null) {
//    		System.out.println(typeName);
    	for (CGNode cgNode : cg) {
//    		System.out.println(cgNode.getMethod().getDeclaringClass().getName().toString());
//    		System.out.println(cgNode.getMethod().getName().toString());
    		//可合并的模式
    		//Could infold code
    		if (cgNode.getMethod().getDeclaringClass().getName().toString().equals(typeName)
    				&&cgNode.getMethod().getName().toString().equals("equals")) {
//				System.out.println("===============================");
//				System.out.println(cgNode.getIR());
//				System.out.println("===============================");
    			SSAInstruction[] ssais = cgNode.getIR().getInstructions();
    			for (int label = 0; label < ssais.length; label++) {
    				SSAInstruction si = ssais[label];
//    				System.out.println(si);
					if(si instanceof SSAInstanceofInstruction) {
						SSAInstanceofInstruction ssaInstanceofInstruction=(SSAInstanceofInstruction)si;
						List<SSAInstruction> ssaInstructions=new ArrayList<SSAInstruction>();
						for(int inlabel=label+1;inlabel<ssais.length;inlabel++) {
						   if(ssais[inlabel]!=null) {
								ssaInstructions.add(ssais[inlabel]);
						   }
						 }
//						  System.out.println(ssaInstructions);
						  if(ssaInstructions.get(0) instanceof SSAConditionalBranchInstruction
								  &&ssaInstructions.get(1) instanceof SSAReturnInstruction
								  &&ssaInstructions.get(2) instanceof SSACheckCastInstruction) {
							  SSAReturnInstruction ssaReturnInstruction=(SSAReturnInstruction)ssaInstructions.get(1);
							  SSACheckCastInstruction ssaCheckCastInstruction=(SSACheckCastInstruction)ssaInstructions.get(2);
							  if(ssaCheckCastInstruction.toString().contains(ssaInstanceofInstruction.getCheckedType().toString())
									  &&ssaInstanceofInstruction.getRef()==ssaCheckCastInstruction.getVal()
									  &&ssaInstructions.get(ssaInstructions.size()-2) instanceof SSAReturnInstruction
									  &&ssaInstructions.get(ssaInstructions.size()-4) instanceof SSAFieldAccessInstruction) {
								  SSAFieldAccessInstruction ssaFieldAccessInstruction=(SSAFieldAccessInstruction)ssaInstructions.get(ssaInstructions.size()-4);
								  SSAReturnInstruction ssacompareReturn=(SSAReturnInstruction)ssaInstructions.get(ssaInstructions.size()-2);
								  if(ssaFieldAccessInstruction.getDef()+1==ssacompareReturn.getResult()) {
//									  System.out.println("could be fold");
									  
								  }
							  }
							 
						  }
					}
    			}
    		}
    		
    		
    		//保卫模式
    		//Guard pattern Analysis
    		if (cgNode.getMethod().getDeclaringClass().getName().toString().equals(typeName)
    				&&cgNode.getMethod().getName().toString().equals("hello")) {
//				System.out.println("===============================");
//				System.out.println(cgNode.getIR());
//				System.out.println("===============================");
				SSAInstruction[] ssais=cgNode.getIR().getInstructions();
				for (int label = 0; label < ssais.length; label++) {
					SSAInstruction si = ssais[label];
//					if(si!=null) {
//					System.out.println(si);
//					}
					if(si instanceof SSAInstanceofInstruction) {
						SSAInstanceofInstruction siInstanceof = (SSAInstanceofInstruction) si;
						List<SSAInstruction> ssaInstructions=new ArrayList<SSAInstruction>();
						for(int inlabel=label+1;inlabel<ssais.length;inlabel++) {
							if(ssais[inlabel]!=null) {
								ssaInstructions.add(ssais[inlabel]);
							}
						}
//						System.out.println(ssaInstructions);
						if(ssaInstructions!=null
								&&ssaInstructions.get(0) instanceof SSAConditionalBranchInstruction
								&&ssaInstructions.get(1) instanceof SSACheckCastInstruction) {
							SSAConditionalBranchInstruction ssaConditionalBranchInstruction=(SSAConditionalBranchInstruction)ssaInstructions.get(0);
//							System.out.println(ssaConditionalBranchInstruction.getUse(0));
//							System.out.println(siInstanceof.getDef());
							SSACheckCastInstruction ssaCheckCastInstruction=(SSACheckCastInstruction)ssaInstructions.get(1);
							if(ssaConditionalBranchInstruction.getUse(0)==siInstanceof.getDef()
						       &&ssaCheckCastInstruction.toString().contains(siInstanceof.getCheckedType().toString())) {
								if(siInstanceof.getRef()==ssaCheckCastInstruction.getVal()
										&&ssaInstructions.get(2) instanceof SSAInvokeInstruction) {
									SSAInvokeInstruction ssaInvokeInstruction=(SSAInvokeInstruction)ssaInstructions.get(2);
									if(ssaInvokeInstruction.getReceiver()==ssaCheckCastInstruction.getDef()) {
										//SSAComparisonInstruction or SSAConditionalBranchInstruction
										System.out.println(ssaInvokeInstruction.getReceiver());
										if(ssaInstructions.get(3) instanceof SSAConditionalBranchInstruction) {
											SSAConditionalBranchInstruction ssaconditionalguard=(SSAConditionalBranchInstruction)ssaInstructions.get(3);
//											System.out.println(ssaconditionalguard.getUse(0));
//											System.out.println(ssaInvokeInstruction.getDef());
											if(ssaconditionalguard.getUse(0)==ssaInvokeInstruction.getDef()) {
//												System.out.println(ssaconditionalguard.getUse(0));
//											      System.out.println("yes it is guard");
											}
										}else if(ssaInstructions.get(3) instanceof SSAComparisonInstruction) {
											SSAComparisonInstruction ssaComparisonInstruction=(SSAComparisonInstruction)ssaInstructions.get(3);
											if(ssaComparisonInstruction.getUse(0)==ssaInvokeInstruction.getDef()
													&&ssaInstructions.get(4) instanceof SSAConditionalBranchInstruction) {
//												System.out.println(ssaComparisonInstruction.getUse(0));
//											      System.out.println("yes it is guard");
											}
										}
									}
									
								}else if(siInstanceof.getRef()==ssaCheckCastInstruction.getVal()
										&&ssaInstructions.get(2) instanceof SSAFieldAccessInstruction) {
									     SSAFieldAccessInstruction ssaFieldAccessInstruction=(SSAFieldAccessInstruction)ssaInstructions.get(2);
//									     System.out.println(ssaFieldAccessInstruction.getDeclaredField().getDeclaringClass());
//									     System.out.println(siInstanceof.getCheckedType());
									     if(ssaFieldAccessInstruction.getDeclaredField().getDeclaringClass().toString().equals(siInstanceof.getCheckedType().toString())
									    		 &&ssaCheckCastInstruction.getDef()==ssaFieldAccessInstruction.getRef()) {
									    	 if(ssaInstructions.get(3) instanceof SSAConditionalBranchInstruction) {
									    		 SSAConditionalBranchInstruction conditionalbranchsecond=(SSAConditionalBranchInstruction)ssaInstructions.get(3);
//									    		 System.out.println(conditionalbranchsecond.getUse(0));
//									    		 System.out.println(ssaFieldAccessInstruction.getDef());
									    		 if(conditionalbranchsecond.getUse(0)==ssaFieldAccessInstruction.getDef()) {
//									    			 System.out.println("yes is guard");
									    		 }
									    	 }
//									    	 System.out.println(ssaCheckCastInstruction.getDef());
//									    	 System.out.println(ssaFieldAccessInstruction.getRef());
//									    	 System.out.println("yes");

									     }
								}
							}
						}
					}
				}
    		}
    		
    		//switch模式
    		//switch pattern Analysis
    		if (cgNode.getMethod().getDeclaringClass().getName().toString().equals(typeName)
    				&&cgNode.getMethod().getName().toString().equals("switche")) {
    		     	System.out.println("===============================");
				    System.out.println(cgNode.getIR());
				    System.out.println("===============================");
				    SSAInstruction[] ssais=cgNode.getIR().getInstructions();
				    List<SSAInstruction> compareSSA=new ArrayList<SSAInstruction>();
				    List<SSAInstruction> comparein=new ArrayList<SSAInstruction>();
				    List<Integer> labelnum=new ArrayList<Integer>();
				    List<SSAInstruction> memorySSA=new ArrayList<SSAInstruction>();
				    for(int label=0;label<ssais.length;label++) {
				    	if(ssais[label]!=null) {
				    		SSAInstruction si=ssais[label];
				    		System.out.println(si);
				    		memorySSA.add(si);
				    	}
				    }
				    for(int label=0;label<memorySSA.size();label++) {
				    	if(memorySSA.get(label) instanceof SSAInstanceofInstruction) {
				    		SSAInstanceofInstruction siInstanceof=(SSAInstanceofInstruction)memorySSA.get(label);
				    		List<SSAInstruction> ssaInstructions=new ArrayList<SSAInstruction>();
				    		for(int inlabel=label+1;inlabel<memorySSA.size();inlabel++) {
				    			ssaInstructions.add(memorySSA.get(inlabel));
				    		}
//				    		System.out.println(ssaInstructions);
				    		if(ssaInstructions.get(0) instanceof SSAConditionalBranchInstruction) {
				    			SSAConditionalBranchInstruction ssaConditionalBranchInstruction=(SSAConditionalBranchInstruction)ssaInstructions.get(0);
				    			if(siInstanceof.getDef()==ssaConditionalBranchInstruction.getUse(0)) {
				    				if(ssaInstructions.get(1) instanceof SSACheckCastInstruction) {
				    					SSACheckCastInstruction ssaCheckCastInstruction=(SSACheckCastInstruction)ssaInstructions.get(1);
				    					if(ssaCheckCastInstruction.toString().contains(siInstanceof.getCheckedType().toString())) {
				    						if(ssaConditionalBranchInstruction.getUse(1)-ssaConditionalBranchInstruction.getUse(0)!=1) {
				    							labelnum.add(label);
				    						}
				    					}else {
				    						break;
				    					}
				    				}
				    			}
				    		}
				    	}
				    }
				    if(!labelnum.isEmpty()) {
				    	for(int i=0;i<labelnum.size();i++) {
				    		compareSSA.add(memorySSA.get(labelnum.get(i)-1));
				    		comparein.add(memorySSA.get(labelnum.get(i)-2));
				    	}
//				    	   System.out.println(compareSSA);
//				    	   System.out.println(comparein);
				    	if(compareSSA.size()>1) {
				    	for(int i=0;i<compareSSA.size()-1;i++) {
				    		for(int j=i+1;j<compareSSA.size();j++) {
				    			if(compareSSA.get(i).getClass().equals(compareSSA.get(j).getClass())) {
				    				if(compareSSA.get(i) instanceof SSAGotoInstruction
				    						&&compareSSA.get(j) instanceof SSAGotoInstruction) {
				    					SSAGotoInstruction goto1=(SSAGotoInstruction)compareSSA.get(i);
				    					SSAGotoInstruction goto2=(SSAGotoInstruction)compareSSA.get(j);
				    				    if(goto1.getTarget()!=goto2.getTarget()) {
				    				    	compareSSA.clear();
				    				    	break;
				    				    }
				    				}
//				    				else if(compareSSA.get(i) instanceof SSAReturnInstruction
//				    						&&compareSSA.get(j) instanceof SSAReturnInstruction) {
//				    					
//				    				}			    				
				    			}else {
				    				compareSSA.clear();	
				    				break;
				    			}
				    		}
				    	}
				    	if(!compareSSA.isEmpty()) {
				    		if(comparein.get(0) instanceof SSAInvokeInstruction) {
				    			SSAInvokeInstruction ssatest=(SSAInvokeInstruction)comparein.get(0);
				    			TypeReference type=ssatest.getDeclaredTarget().getDeclaringClass();
				    			Atom name=ssatest.getDeclaredTarget().getName();
				    			for(int i=1;i<comparein.size();i++) {
				    				if(comparein.get(i) instanceof SSAInvokeInstruction) {
				    					SSAInvokeInstruction ssa2=(SSAInvokeInstruction)comparein.get(i);
				    					if(!ssa2.getDeclaredTarget().getDeclaringClass().equals(type)
				    							&&ssa2.getDeclaredTarget().getName().equals(name)) {
				    						compareSSA.clear();
					    					comparein.clear();
					    					break;
				    					}
				    				}else {
				    					compareSSA.clear();
				    					comparein.clear();
				    					break;
				    				}
				    			}
				    		}
				    	}else {
				    		comparein.clear();
				    		compareSSA.clear();
				    		break;
				    	}
				    	}
//				    	System.out.println(compareSSA);
				        List<SSAInstruction> judglist=new ArrayList<SSAInstruction>();
				    	if(!compareSSA.isEmpty()
				    			&&!comparein.isEmpty()) {
//				    		System.out.println("*******************");
			    				if(comparein.get(0) instanceof SSAInvokeInstruction) {
					    			SSAInvokeInstruction ssatest=(SSAInvokeInstruction)comparein.get(0);
					    			TypeReference type=ssatest.getDeclaredTarget().getDeclaringClass();
					    			Atom name=ssatest.getDeclaredTarget().getName();
					    			System.out.println(comparein.get(0));
					    			System.out.println(type);
					    			System.out.println(name);
					    			for(int label=labelnum.get(labelnum.size()-1);label<memorySSA.size();label++) {
//					    				System.out.println(memorySSA.get(label));
					    				if(memorySSA.get(label) instanceof SSAInvokeInstruction) {
					    					SSAInvokeInstruction ssaInvokeInstruction=(SSAInvokeInstruction)memorySSA.get(label);
//					    					System.out.println(ssaInvokeInstruction);
					    					if(ssaInvokeInstruction.getDeclaredTarget().getDeclaringClass().equals(type)
					    							&&ssaInvokeInstruction.getDeclaredTarget().getName().equals(name)) {
					    						   judglist.add(memorySSA.get(label));
					    					}
					    				}
					    			}
			    			}
//				    		if(compareSSA.get(0) instanceof SSAGotoInstruction) {
//				    			SSAGotoInstruction ssaGotoInstruction=(SSAGotoInstruction)compareSSA.get(0);
//				    			System.out.println(memorySSA.get(labelnum.get(labelnum.size()-1)));
//				    			System.out.println(labelnum.get(labelnum.size()-1));
//				    			for(int label=labelnum.get(labelnum.size()-1);label<memorySSA.size();label++) {
//				    				if(memorySSA.get(label) instanceof SSAGotoInstruction) {
//				    					SSAGotoInstruction ssago2=(SSAGotoInstruction)memorySSA.get(label);
//				    					if(ssago2.getTarget()!=ssaGotoInstruction.getTarget()) {
//								    		comparein.clear();
//								    		compareSSA.clear();
//								    		break;
//				    					}
//				    				}
//				    			}
				    			
				    			
//				    		}
//				    		else if(compareSSA.get(0) instanceof SSAReturnInstruction) {
//				    			
//				    		}
				    		
				    		if(judglist.size()==2||judglist.size()==1) {
				    			System.out.println("yes is switchpattern");
				    		}
				    		
				    	}else {
				    		break;
				    	}
				    }else {
				    	break;
				    }
				    
//				    for(int label=0;label<ssais.length;label++) {
//				    	if(ssais[label]!=null) {
//				    	SSAInstruction si=ssais[label];
////				    	System.out.println(si);
//				    	memorySSA.add(si);
//				    	if(si instanceof SSAInstanceofInstruction) {
//				    		SSAInstanceofInstruction siInstanceof=(SSAInstanceofInstruction)si;
//				    		List<SSAInstruction> ssaInstructions=new ArrayList<SSAInstruction>();
//				    		for(int inlabel=label+1;inlabel<ssais.length;inlabel++) {
//				    			if(ssais[inlabel]!=null) {
//				    				ssaInstructions.add(ssais[inlabel]);
//				    			}
//				    		}
////				    		System.out.println(ssaInstructions);
//				    		if(ssaInstructions.get(0) instanceof SSAConditionalBranchInstruction) {
//				    			SSAConditionalBranchInstruction ssaConditionalBranchInstruction=(SSAConditionalBranchInstruction)ssaInstructions.get(0);
////				    			System.out.println(siInstanceof.getDef());
////				    			System.out.println(ssaConditionalBranchInstruction.getUse(0));
//				    			if(siInstanceof.getDef()==ssaConditionalBranchInstruction.getUse(0)) {
//				    				labelnum.add(label+2);
////				    		        num.add(siInstanceof.getDef());
////						    		labelnum.add(label);
//				    			}else {
//				    				break;
//				    			}		
//				    		}else {
//				    			break;
//				    		}
//				    		}
//				    	}
//				    }
//				    System.out.println(memorySSA);
//				    System.out.println(labelnum);
				    
				    
				    
				    
				    
				    
				    
				  //  System.out.println(ssais[1]); is null使用非空去判断instanceof前的指令
//				    if(num.size()>1 &&num.get(0)==num.get(1)-2) {
//				    	int x=2;
//				    	while(x<num.size()) {
//				    		if(num.get(x)-num.get(x-1)==1) {
//				    			x++;
//				    		}else {
//				    			num.clear();
//				    		}
//				    	}
//				    }else {
//				    	num.clear();
//				    }
				    
				    //这里不太对
//				    if(!num.isEmpty()) {
//		    		for(int inlabel=labelnum.get(labelnum.size()-1)+1;inlabel<ssais.length;inlabel++) {
//		    			SSAInstruction si=ssais[inlabel];
//		    			if(si!=null&&si.getDef()!=-1) {
//		    				if(si.getDef()==num.get(num.size()-1)+1) {
////			    				System.out.println(si.getDef());
////			    				num.add(si.getDef())
//		    					//排除SSAGotoInstruction
//		    				    num.add(si.getDef());
//		    				    labelnum.add(inlabel);
//		    				}
//		    			}
//		    		}
//				    }else {
//				    	break;
//				    }
				    
//				    if(!num.isEmpty()) {
//				    	for(int i=1;i<num.size();i++) {
//				    		
//				    	}
//				    }
//				    System.out.println(num);
//				    System.out.println(labelnum);



    		}
    		
    	}
   }}
    
    
	private String dealTypeName(String typeTemp) {
		char[] chars = typeTemp.toCharArray();
		int j = 3;
		for (int i = 0; i < chars.length; i++) {
			if (chars[i] == '/') {
				j--;
				if (j == 0) {
					j = i + 1;
					break;
				}
			}
		}
		if (chars.length >= 5) {
			return "L" + String.valueOf(chars, j, chars.length - j - 5);
		} else {
			return null;
		}
	}
}
