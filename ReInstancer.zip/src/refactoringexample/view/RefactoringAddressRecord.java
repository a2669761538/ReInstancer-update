package refactoringexample.view;

public class RefactoringAddressRecord {
 private String path;
 private String classname;
 private String methodname;
 private String location;
 private String dominationType;
 public RefactoringAddressRecord(String path,String classname,String methodname,String dominationtype, String location) {
	// TODO Auto-generated constructor stub
	 this.path=path;
	 this.classname=classname;
	 this.methodname=methodname;
	 this.dominationType=dominationtype;
	 this.location=location;
}
 public String getProjectname() {
	 return path;
 }
 
 public String getClassName() {
	 return classname;
 }
 
 public String getMethodName() {
	 return methodname;
 }
 
 public String getDominationType() {
	 return dominationType;
 }
 
 public String getLocation() {
	 return location;
 }
}
