package refactoringexample.refactoring;

import java.io.IOException;
import java.util.ArrayList;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.SwitchCase;
import org.eclipse.jdt.core.dom.SwitchStatement;
import org.eclipse.jdt.core.dom.TypeDeclaration;

public class SwitchExpressionRefactoring {

	@SuppressWarnings("unchecked")
	public void refactoringForSwitchExpression(TypeDeclaration types, AST ast, IJavaElement element, SwitchStatement switchStatement, Block mBlock, int k)
			throws IllegalArgumentException, IOException {

		SwitchRefactoring srf = new SwitchRefactoring(element);

		AST astTemp = AST.newAST(14, false);
		SwitchStatement copyStatement = (SwitchStatement) ASTNode.copySubtree(astTemp, switchStatement);
		Statement ssTemp = srf.checkFinalConditions(types, astTemp, copyStatement);

		ArrayList<Boolean> listSwitchCaseLabel = new ArrayList<Boolean>();
		findSwitchCaseLabel(ssTemp, listSwitchCaseLabel);
		Statement switchRefactored = (Statement) ASTNode.copySubtree(ast, ssTemp);
		ArrayList<SwitchCase> listSwitchCases = new ArrayList<SwitchCase>();
		findSwitchCases(switchRefactored, listSwitchCases);
		if (listSwitchCaseLabel.size() != listSwitchCases.size()) {
			System.out.println("SwitchExpression �ع����ڴ���");
		} else {
			for (int num = 0; num < listSwitchCaseLabel.size(); num++) {
				listSwitchCases.get(num).setSwitchLabeledRule(listSwitchCaseLabel.get(num));
			}
		}
		copyStatement.delete();
		switchStatement.delete();
//		mBlock.statements().add(k, switchStatement);
		mBlock.statements().add(k, switchRefactored);
//		mBlock.statements().add(k + 1, switchRefactored);
	}

	private void findSwitchCases(ASTNode node, ArrayList<SwitchCase> listSwitchCases) {
		node.accept(new ASTVisitor() {
			public boolean visit(SwitchCase sc) {
				listSwitchCases.add(sc);
				return true;
			}
		});
	}

	private void findSwitchCaseLabel(ASTNode node, ArrayList<Boolean> listSwitchCaseLabel) {
		node.accept(new ASTVisitor() {
			public boolean visit(SwitchCase sc) {
				listSwitchCaseLabel.add(sc.isSwitchLabeledRule());
				return true;
			}
		});
	}
}
