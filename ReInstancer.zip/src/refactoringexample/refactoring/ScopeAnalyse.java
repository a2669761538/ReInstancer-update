package refactoringexample.refactoring;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.CastExpression;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InstanceofExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.Modifier.ModifierKeyword;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.StringLiteral;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclarationStatement;
import org.eclipse.jdt.core.dom.VariableDeclarationExpression;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

import refactoringexample.view.RefactoringAddressRecord;

import org.eclipse.jdt.core.dom.Type;

public class ScopeAnalyse {
	public static List<RefactoringAddressRecord> ScopeStrings =new ArrayList<RefactoringAddressRecord>();
public void InstanceofScopeAnalyse(MethodDeclaration m,List<IfStatement> list, AST ast,TypeDeclaration types) {
	for (IfStatement ifTemp : list) {
		if(ifTemp.getExpression() instanceof InstanceofExpression) {
			InstanceofExpression instanceofExpression=(InstanceofExpression)ifTemp.getExpression();
			if(instanceofExpression.getPatternVariable()!=null) {
				SingleVariableDeclaration svd=instanceofExpression.getPatternVariable();
				Type type=svd.getType();
				Type copyType=(Type)ASTNode.copySubtree(ast, type);
				String svdnameString=svd.getName().toString();
				if(ifTemp.getElseStatement() instanceof Block) {
					Block block=(Block)ifTemp.getElseStatement();
					for(int i=0;i<block.statements().size();i++) {
						if(block.statements().get(i) instanceof ExpressionStatement) {
							ExpressionStatement expressionStatement=(ExpressionStatement)block.statements().get(i);
							Expression expression=expressionStatement.getExpression();
						    if(expression instanceof MethodInvocation) {
						    	MethodInvocation methodInvocation=(MethodInvocation)expression;
						    	if(methodInvocation.getExpression()!=null&&methodInvocation.getExpression().toString().equals("System.out")
						    			&&methodInvocation.getName().toString().equals("println")) {
						    		if(methodInvocation.arguments().toString().contains(svdnameString)) {
						    			List mList=methodInvocation.arguments();
						    			for(int l=0;l<mList.size();l++) {
						    				if(!(mList.get(l) instanceof StringLiteral)&&mList.get(l) instanceof MethodInvocation) {
						    					MethodInvocation intoInvocation=(MethodInvocation)mList.get(l);
						    					if(intoInvocation.getExpression().toString().equals(svdnameString)) {
						    		                SimpleName tName=types.getName();
						    		                String tString=tName.toString();
						    		                SimpleName mName=m.getName();
						    		                String mString=mName.toString();
						    		                String elementString=AnnotationRefactoring.elementString;
						    		                String explainString="The variable declares that"+" "+svdnameString+" "+"is not in scope";
//						    		                RefactoringAddressRecord rAddressRecord=new RefactoringAddressRecord(elementString,tString,mString,explainString);
//										    		ScopeStrings.add(rAddressRecord);
										    		if(types.bodyDeclarations().get(0).toString().contains("private"+" "+copyType.toString()+" "+svdnameString)) {
										    			continue;
										    		}else {
										    			VariableDeclarationFragment variableDeclarationFragment=ast.newVariableDeclarationFragment();
							    						variableDeclarationFragment.setName(ast.newSimpleName(svdnameString.toString()));						    						
							    						FieldDeclaration fDeclaration=ast.newFieldDeclaration(variableDeclarationFragment);
							    						fDeclaration.setType(copyType);
							    					    fDeclaration.modifiers().add(ast.newModifier(ModifierKeyword.PRIVATE_KEYWORD)); 
							    						types.bodyDeclarations().add(0,fDeclaration);
										    		}
						    						
						    					}
						    				}
						    			}
						    		}
						    	}else if(methodInvocation.getExpression()!=null
						    			&&methodInvocation.getExpression().toString().equals(svdnameString)) {
						    		 SimpleName tName=types.getName();
			    		                String tString=tName.toString();
			    		                SimpleName mName=m.getName();
			    		                String mString=mName.toString();
			    		                String elementString=AnnotationRefactoring.elementString;
			    		                String explainString="The variable declares that"+" "+svdnameString+" "+"is not in scope";
//			    		                RefactoringAddressRecord rAddressRecord=new RefactoringAddressRecord(elementString,tString,mString,explainString);
//							    		ScopeStrings.add(rAddressRecord);
							    		if(types.bodyDeclarations().get(0).toString().contains("private"+" "+copyType.toString()+" "+svdnameString)) {
							    			continue;
							    		}else {
							    			VariableDeclarationFragment variableDeclarationFragment=ast.newVariableDeclarationFragment();
				    						variableDeclarationFragment.setName(ast.newSimpleName(svdnameString.toString()));						    						
				    						FieldDeclaration fDeclaration=ast.newFieldDeclaration(variableDeclarationFragment);
				    						fDeclaration.setType(copyType);
				    					    fDeclaration.modifiers().add(ast.newModifier(ModifierKeyword.PRIVATE_KEYWORD)); 
				    						types.bodyDeclarations().add(0,fDeclaration);
							    		}
						    	}
						    }
						}
					}
				}
			}
		}
	}
}
}
