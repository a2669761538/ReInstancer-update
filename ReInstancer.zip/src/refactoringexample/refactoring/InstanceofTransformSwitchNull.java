package refactoringexample.refactoring;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.BreakStatement;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.InstanceofExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.ParenthesizedExpression;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.SwitchCase;
import org.eclipse.jdt.core.dom.SwitchStatement;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationExpression;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
public class InstanceofTransformSwitchNull {
public void InstanceofTransformNull(TypeDeclaration types, MethodDeclaration m, List<IfStatement> list, AST ast) {
	List<IfStatement> iflist=new ArrayList<IfStatement>();
	List<List<Statement>> statemetlist=new ArrayList<List<Statement>>();
	List<SingleVariableDeclaration> svdlist=new ArrayList<SingleVariableDeclaration>();
	List<Statement> defaultList=new ArrayList<Statement>();
	List<Statement> edefaultList=new ArrayList<Statement>();
		getifstatement(m, iflist);
		for(IfStatement ifTemp:iflist) {
			if(ifTemp.getExpression() instanceof InfixExpression&&ifTemp.getElseStatement()==null) {
				InfixExpression infixExpression=(InfixExpression)ifTemp.getExpression();
				String lString=infixExpression.getLeftOperand().toString();
				String rString=infixExpression.getRightOperand().toString();
				if(ifTemp.getParent() instanceof Block) {
					Block mBlock=(Block)ifTemp.getParent();
					 for(int k=0;k<mBlock.statements().size();k++) {
						 if(mBlock.statements().get(k).toString().equals(ifTemp.toString())) {
							 if(k!=mBlock.statements().size()-1&&mBlock.statements().get(k+1)instanceof IfStatement) {
								 IfStatement ifStatement=(IfStatement)mBlock.statements().get(k+1);
								 if(ifStatement.getExpression() instanceof InstanceofExpression) {
									 InstanceofExpression instanceofExpression=(InstanceofExpression)ifStatement.getExpression();
									 String instanceofLString=instanceofExpression.getLeftOperand().toString();
									 if(instanceofLString.equals(lString)&&rString.equals("null")&&instanceofExpression.getPatternVariable()!=null) {
										    System.out.println(ifTemp);
										    System.out.println(ifStatement);
										   if(ifTemp.getThenStatement() instanceof Block) {
											   Block block=(Block)ifTemp.getThenStatement();
											   List<Statement> statements=new ArrayList<Statement>();
											   for(int i=0;i<block.statements().size();i++) {
												   statements.add((Statement) block.statements().get(i));
											   }
											   if(!statements.isEmpty()) {
												   statemetlist.add(statements);
											   }
											 }else {
												 List<Statement> statements=new ArrayList<Statement>();
												 statements.add(ifTemp.getThenStatement());
												 if(!statements.isEmpty()) {
												   statemetlist.add(statements);
												 }
											 }
										  
										    SingleVariableDeclaration svd=instanceofExpression.getPatternVariable();
										    svdlist.add(svd);
										    if(ifStatement.getThenStatement()!=null&&ifStatement.getThenStatement() instanceof Block) {
										    	Block thenBlock=(Block)ifStatement.getThenStatement();
										    	List<Statement> statements=new ArrayList<Statement>();
										    	for(int x=0;x<thenBlock.statements().size();x++) {
										    		statements.add((Statement) thenBlock.statements().get(x));
										    	}
										    	if(!statements.isEmpty()) {
										    		statemetlist.add(statements);
										    	}
										    }else if(ifStatement.getThenStatement()!=null&&!(ifStatement.getThenStatement() instanceof Block)) {
										    	List<Statement> statements=new ArrayList<Statement>();
										    	statements.add(ifStatement.getThenStatement());
										    	if(!statements.isEmpty()) {
										    		statemetlist.add(statements);
										    	}
										    }
//										    System.out.println(svdlist);
//										    System.out.println(statemetlist);
										    if(ifStatement.getElseStatement()==null) {
										    	SwitchStatement switchStatement=ast.newSwitchStatement();
										    	Expression copyExpression=(Expression)ASTNode.copySubtree(ast, instanceofExpression.getLeftOperand());
										    	switchStatement.setExpression(copyExpression);
										    	SwitchCase switchCase=ast.newSwitchCase();
										    	Expression expression=ast.newNullLiteral();
										    	switchStatement.statements().add(switchCase);
										    	switchCase.expressions().add(expression);
										    	switchCase.setSwitchLabeledRule(true);
										    	List<Statement> statements=statemetlist.get(0);
										    	if(statements.size()==1) {
										    		if(statements.get(0) instanceof ExpressionStatement) {
										    			 Statement Statement=(Statement)statements.get(0);
			                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
			                    						 switchStatement.statements().add(copyStatement);			 
										    		}else{
										    			Block newblock=ast.newBlock();
										    			Statement Statement=(Statement)statements.get(0);
										    			 try {
				                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
				                    						 newblock.statements().add(copyStatement);
				                    				    	 }catch (Exception e) {
																// TODO: handle exception
				                    				    		 Statement.delete();
				                    				    		 newblock.statements().add(Statement);
				                    				    		 
														}
										    			 switchStatement.statements().add(newblock);
										    		}
										    	}else if(statements.size()>1) {
										    		Block newBlock=ast.newBlock();
										    		 for(int in=0;in<statements.size();in++) {
										    				if(statements.get(in) instanceof Statement) {
				                    							Statement statement=(Statement)statements.get(in);
				                    							try {
				                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
				                    							newBlock.statements().add(copyStatement);
				                    							}catch (Exception e) {
																	// TODO: handle exception
				                    								statement.delete();
				                    								newBlock.statements().add(statement);
																}
				                    						} 
										    		 }
										    		 switchStatement.statements().add(newBlock);
										    	}
										    	SwitchCase switchCases=ast.newSwitchCase();
										    	SingleVariableDeclaration resvd=(SingleVariableDeclaration)svdlist.get(0);
										    	VariableDeclarationFragment variableDeclarationFragment=ast.newVariableDeclarationFragment();
					    					    variableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(0).getName().toString()));
		                    				    Type type=svdlist.get(0).getType();
						    					Type copyType=(Type)ASTNode.copySubtree(ast, type);
						    					VariableDeclarationExpression variableDeclarationExpression=ast.newVariableDeclarationExpression(variableDeclarationFragment);
						    				    variableDeclarationExpression.setType(copyType);
						    				    Expression newvariableExpression=(Expression)variableDeclarationExpression;
			                    				List<Statement> statementss=statemetlist.get(1);
			                    				if(statementss.size()==1) {
										    		if(statementss.get(0) instanceof ExpressionStatement) {
								    				     switchStatement.statements().add(switchCases);
								    					 switchCases.expressions().add(newvariableExpression);
					                    				 switchCases.setSwitchLabeledRule(true);
										    			 Statement Statement=(Statement)statementss.get(0);
			                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
			                    						 switchStatement.statements().add(copyStatement);			 
										    		}else if(statementss.get(0) instanceof IfStatement) {
										    			 IfStatement judgeIfStatement=(IfStatement)statementss.get(0);
										    			 if(judgeIfStatement.getExpression() instanceof InfixExpression
			                    				    			 &&judgeIfStatement.getElseStatement()==null
			                    				    			 &&judgeIfStatement.getThenStatement() instanceof Block) {
										    				 InfixExpression judegExpression=(InfixExpression)judgeIfStatement.getExpression();
										    				 if(judegExpression.getLeftOperand() instanceof MethodInvocation) {
										    					 MethodInvocation methodInvocation=(MethodInvocation)judegExpression.getLeftOperand();
										    					 if(methodInvocation.getExpression().toString().equals(svdlist.get(0).getName().toString())) {
										    						 InfixExpression mergeif=ast.newInfixExpression();
										    						 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
										    						 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
										    						 parenthesizedExpression.setExpression(copyjudgExpression);
										    						 mergeif.setLeftOperand(newvariableExpression);
										    						 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
										    						 mergeif.setRightOperand(parenthesizedExpression);
										    						 switchStatement.statements().add(switchCases);
										    						 switchCases.expressions().add(mergeif);
										    						 switchCases.setSwitchLabeledRule(true);
										    						 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
			                    				    				 int judge=judgeBlock.statements().size();
			                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
			                    				    					 judgeBlock.statements().remove(judge-1);
			                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
				                    				    				 switchStatement.statements().add(newblock);
			                    				    				 }else {
			                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
				                    				    				 switchStatement.statements().add(newblock);
																	}	
										    					 }else {
										    						   switchStatement.statements().add(switchCases);
											    					   switchCases.expressions().add(newvariableExpression);
								                    				   switchCases.setSwitchLabeledRule(true);
														    			Block newblock=ast.newBlock();
														    			Statement Statement=(Statement)statementss.get(0);
														    			 try {
								                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
								                    						 newblock.statements().add(copyStatement);
								                    				    	 }catch (Exception e) {
																				// TODO: handle exception
								                    				    		 Statement.delete();
								                    				    		 newblock.statements().add(Statement);
								                    				    		 
																		}
														    			 switchStatement.statements().add(newblock);									    						 
										    					 }
										    				 }else if(judegExpression.getLeftOperand() instanceof QualifiedName){
										    					 QualifiedName qualifiedName=(QualifiedName)judegExpression.getLeftOperand();
										    					 if(qualifiedName.getQualifier().toString().equals(svdlist.get(0).getName().toString())) {
										    						 InfixExpression mergeif=ast.newInfixExpression();
										    						 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
										    						 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
										    						 parenthesizedExpression.setExpression(copyjudgExpression);
										    						 mergeif.setLeftOperand(newvariableExpression);
										    						 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
										    						 mergeif.setRightOperand(parenthesizedExpression);
										    						 switchStatement.statements().add(switchCases);
										    						 switchCases.expressions().add(mergeif);
										    						 switchCases.setSwitchLabeledRule(true);
										    						 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
			                    				    				 int judge=judgeBlock.statements().size();
			                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
			                    				    					 judgeBlock.statements().remove(judge-1);
			                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
				                    				    				 switchStatement.statements().add(newblock);
			                    				    				 }else {
			                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
				                    				    				 switchStatement.statements().add(newblock);
																	}
										    					 
										    					 }else {
											    					  switchStatement.statements().add(switchCases);
											    					  switchCases.expressions().add(newvariableExpression);
								                    				  switchCases.setSwitchLabeledRule(true);
														    			Block newblock=ast.newBlock();
														    			Statement Statement=(Statement)statementss.get(0);
														    			 try {
								                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
								                    						 newblock.statements().add(copyStatement);
								                    				    	 }catch (Exception e) {
																				// TODO: handle exception
								                    				    		 Statement.delete();
								                    				    		 newblock.statements().add(Statement);
								                    				    		 
																		}
														    			 switchStatement.statements().add(newblock);														    													    				 
										    					 }
										    				 }
										    				 else {
										    					  switchStatement.statements().add(switchCases);
										    					  switchCases.expressions().add(newvariableExpression);
							                    				  switchCases.setSwitchLabeledRule(true);
													    			Block newblock=ast.newBlock();
													    			Statement Statement=(Statement)statementss.get(0);
													    			 try {
							                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
							                    						 newblock.statements().add(copyStatement);
							                    				    	 }catch (Exception e) {
																			// TODO: handle exception
							                    				    		 Statement.delete();
							                    				    		 newblock.statements().add(Statement);
							                    				    		 
																	}
													    			 switchStatement.statements().add(newblock);
													    		 
										    				 }
										    			 }else if(judgeIfStatement.getExpression() instanceof InfixExpression
			                    				    			 &&judgeIfStatement.getElseStatement()!=null
			                    				    			 &&judgeIfStatement.getElseStatement() instanceof Block
			                    				    			 &&judgeIfStatement.getThenStatement() instanceof Block){
										    				 InfixExpression judegExpression=(InfixExpression)judgeIfStatement.getExpression();
										    				 if(judegExpression.getLeftOperand() instanceof MethodInvocation) {
										    					 MethodInvocation methodInvocation=(MethodInvocation)judegExpression.getLeftOperand();
										    					 if(methodInvocation.getExpression().toString().equals(svdlist.get(0).getName().toString())) {
										    						 InfixExpression mergeif=ast.newInfixExpression();
										    						 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
										    						 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
										    						 parenthesizedExpression.setExpression(copyjudgExpression);
										    						 mergeif.setLeftOperand(newvariableExpression);
										    						 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
										    						 mergeif.setRightOperand(parenthesizedExpression);
										    						 switchStatement.statements().add(switchCases);
										    						 switchCases.expressions().add(mergeif);
										    						 switchCases.setSwitchLabeledRule(true);
										    						 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
			                    				    				 int judge=judgeBlock.statements().size();
			                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
			                    				    					 judgeBlock.statements().remove(judge-1);
			                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
				                    				    				 switchStatement.statements().add(newblock);
			                    				    				 }else {
			                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
				                    				    				 switchStatement.statements().add(newblock);
																	}
			                    				    				 SwitchCase elseSwitchCase=ast.newSwitchCase();
			                    				    				 if(judgeIfStatement.getElseStatement() instanceof Block) {
			                    				    					 Block copyBlock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getElseStatement());
			                    				    					 switchStatement.statements().add(elseSwitchCase);
			                    				    					 Expression copyvar=(Expression)ASTNode.copySubtree(ast, newvariableExpression);
			                    				    					 elseSwitchCase.expressions().add(copyvar);
			                    				    					 elseSwitchCase.setSwitchLabeledRule(true);
			                    				    					 switchStatement.statements().add(copyBlock);
			                    				    					 
			                    				    				 }
										    					 }else {
										    						   switchStatement.statements().add(switchCases);
											    					   switchCases.expressions().add(newvariableExpression);
								                    				   switchCases.setSwitchLabeledRule(true);
														    			Block newblock=ast.newBlock();
														    			Statement Statement=(Statement)statementss.get(0);
														    			 try {
								                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
								                    						 newblock.statements().add(copyStatement);
								                    				    	 }catch (Exception e) {
																				// TODO: handle exception
								                    				    		 Statement.delete();
								                    				    		 newblock.statements().add(Statement);
								                    				    		 
																		}
														    			 switchStatement.statements().add(newblock);									    						 
										    					 }
										    				 }else if(judegExpression.getLeftOperand() instanceof QualifiedName){
										    					 QualifiedName qualifiedName=(QualifiedName)judegExpression.getLeftOperand();
										    					 if(qualifiedName.getQualifier().toString().equals(svdlist.get(0).getName().toString())) {
										    						 InfixExpression mergeif=ast.newInfixExpression();
										    						 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
										    						 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
										    						 parenthesizedExpression.setExpression(copyjudgExpression);
										    						 mergeif.setLeftOperand(newvariableExpression);
										    						 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
										    						 mergeif.setRightOperand(parenthesizedExpression);
										    						 switchStatement.statements().add(switchCases);
										    						 switchCases.expressions().add(mergeif);
										    						 switchCases.setSwitchLabeledRule(true);
										    						 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
			                    				    				 int judge=judgeBlock.statements().size();
			                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
			                    				    					 judgeBlock.statements().remove(judge-1);
			                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
				                    				    				 switchStatement.statements().add(newblock);
			                    				    				 }else {
			                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
				                    				    				 switchStatement.statements().add(newblock);
																	}
			                    				    				 SwitchCase elseSwitchCase=ast.newSwitchCase();
			                    				    				 if(judgeIfStatement.getElseStatement() instanceof Block) {
			                    				    					 Block copyBlock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getElseStatement());
			                    				    					 switchStatement.statements().add(elseSwitchCase);
			                    				    					 Expression copyvar=(Expression)ASTNode.copySubtree(ast, newvariableExpression);
			                    				    					 elseSwitchCase.expressions().add(copyvar);
			                    				    					 elseSwitchCase.setSwitchLabeledRule(true);
			                    				    					 switchStatement.statements().add(copyBlock);
			                    				    					 
			                    				    				 }
										    					 }else {
											    					  switchStatement.statements().add(switchCases);
											    					  switchCases.expressions().add(newvariableExpression);
								                    				  switchCases.setSwitchLabeledRule(true);
														    			Block newblock=ast.newBlock();
														    			Statement Statement=(Statement)statementss.get(0);
														    			 try {
								                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
								                    						 newblock.statements().add(copyStatement);
								                    				    	 }catch (Exception e) {
																				// TODO: handle exception
								                    				    		 Statement.delete();
								                    				    		 newblock.statements().add(Statement);
								                    				    		 
																		}
														    			 switchStatement.statements().add(newblock);														    													    				 
										    					 }
										    				 }
										    				 else {
										    					  switchStatement.statements().add(switchCases);
										    					  switchCases.expressions().add(newvariableExpression);
							                    				  switchCases.setSwitchLabeledRule(true);
													    			Block newblock=ast.newBlock();
													    			Statement Statement=(Statement)statementss.get(0);
													    			 try {
							                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
							                    						 newblock.statements().add(copyStatement);
							                    				    	 }catch (Exception e) {
																			// TODO: handle exception
							                    				    		 Statement.delete();
							                    				    		 newblock.statements().add(Statement);
							                    				    		 
																	}
													    			 switchStatement.statements().add(newblock);
													    		 
										    				 }
										    			 
										    			 }else {
										    				    switchStatement.statements().add(switchCases);
										    					switchCases.expressions().add(newvariableExpression);
							                    				switchCases.setSwitchLabeledRule(true);
												    			Block newblock=ast.newBlock();
												    			Statement Statement=(Statement)statementss.get(0);
												    			 try {
						                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						                    						 newblock.statements().add(copyStatement);
						                    				    	 }catch (Exception e) {
																		// TODO: handle exception
						                    				    		 Statement.delete();
						                    				    		 newblock.statements().add(Statement);
						                    				    		 
																}
												    			 switchStatement.statements().add(newblock);												    		 
										    			 }
										    		}
										    		else{
								    				    switchStatement.statements().add(switchCases);
								    					switchCases.expressions().add(newvariableExpression);
					                    				switchCases.setSwitchLabeledRule(true);
										    			Block newblock=ast.newBlock();
										    			Statement Statement=(Statement)statementss.get(0);
										    			 try {
				                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
				                    						 newblock.statements().add(copyStatement);
				                    				    	 }catch (Exception e) {
																// TODO: handle exception
				                    				    		 Statement.delete();
				                    				    		 newblock.statements().add(Statement);
				                    				    		 
														}
										    			 switchStatement.statements().add(newblock);
										    		}
										    	
			                    				}else if(statementss.size()>1) {
							    				    switchStatement.statements().add(switchCases);
							    					switchCases.expressions().add(newvariableExpression);
				                    				switchCases.setSwitchLabeledRule(true);
										    		Block newBlock=ast.newBlock();
										    		 for(int in=0;in<statementss.size();in++) {
										    				if(statementss.get(in) instanceof Statement) {
				                    							Statement statement=(Statement)statementss.get(in);
				                    							try {
				                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
				                    							newBlock.statements().add(copyStatement);
				                    							}catch (Exception e) {
																	// TODO: handle exception
				                    								statement.delete();
				                    								newBlock.statements().add(statement);
																}
				                    						} 
										    		 }
										    		 switchStatement.statements().add(newBlock);
										    	     
			                    				}
			                    				ifTemp.delete();
			                    				ifStatement.delete();
			                    				System.out.println(switchStatement);
			                    				mBlock.statements().add(k,switchStatement);
										    }else if(ifStatement.getElseStatement()!=null&&ifStatement.getElseStatement() instanceof IfStatement) {
										    	IfStatement elseIfStatement=(IfStatement)ifStatement.getElseStatement();
										    	while(elseIfStatement instanceof IfStatement) {
										    		if(elseIfStatement.getExpression() instanceof InstanceofExpression) {
										    			InstanceofExpression eInstanceofExpression=(InstanceofExpression)elseIfStatement.getExpression();
										    			String elString=eInstanceofExpression.getLeftOperand().toString();
										    			if(elString.toString().equals(lString)&&eInstanceofExpression.getPatternVariable()!=null) {
										    				SingleVariableDeclaration esvd=eInstanceofExpression.getPatternVariable();
										    				svdlist.add(esvd);
										    				if(elseIfStatement.getThenStatement()!=null&&elseIfStatement.getThenStatement() instanceof Block) {
										    					Block elBlock=(Block)elseIfStatement.getThenStatement();
										    					List<Statement> elList=new ArrayList<Statement>();
										    					for(int i=0;i<elBlock.statements().size();i++) {
										    						elList.add((Statement) elBlock.statements().get(i));
										    					}
										    					statemetlist.add(elList);
										    				}else if(elseIfStatement.getThenStatement()!=null&&!(elseIfStatement.getThenStatement() instanceof Block)) {
										    					List<Statement> elList=new ArrayList<Statement>();
										    					elList.add(elseIfStatement.getThenStatement());
										    					statemetlist.add(elList);
										    				}	
										    			}else if(elString.toString().equals(lString)&&eInstanceofExpression.getPatternVariable()==null) {
										    				SingleVariableDeclaration esvd=ast.newSingleVariableDeclaration();
										    				Type rType=eInstanceofExpression.getRightOperand();
										    				Type newType=ast.newSimpleType(ast.newName(rType.toString()));
										    				esvd.setType(newType);
										    				svdlist.add(esvd);
										    				if(elseIfStatement.getThenStatement()!=null&&elseIfStatement.getThenStatement() instanceof Block) {
										    					Block elBlock=(Block)elseIfStatement.getThenStatement();
										    					List<Statement> elList=new ArrayList<Statement>();
										    					for(int i=0;i<elBlock.statements().size();i++) {
										    						elList.add((Statement) elBlock.statements().get(i));
										    					}
										    					statemetlist.add(elList);
										    				}else if(elseIfStatement.getThenStatement()!=null&&!(elseIfStatement.getThenStatement() instanceof Block)) {
										    					List<Statement> elList=new ArrayList<Statement>();
										    					statemetlist.add(elList);
										    				}
										    			}
										    		}
										    		
										    		if(elseIfStatement.getElseStatement() instanceof IfStatement) {
										    		   elseIfStatement=(IfStatement)elseIfStatement.getElseStatement();
					   								}else if(elseIfStatement.getElseStatement() instanceof Block){
					   									Block defaultBlock=(Block)elseIfStatement.getElseStatement();
					   									for(int d=0;d<defaultBlock.statements().size();d++) {
					   										defaultList.add((Statement)defaultBlock.statements().get(d));
					   									}
												    	SwitchStatement switchStatement=ast.newSwitchStatement();
												    	Expression copyExpression=(Expression)ASTNode.copySubtree(ast, instanceofExpression.getLeftOperand());
												    	switchStatement.setExpression(copyExpression);
												    	SwitchCase switchCase=ast.newSwitchCase();
												    	Expression expression=ast.newNullLiteral();
												    	switchStatement.statements().add(switchCase);
												    	switchCase.expressions().add(expression);
												    	switchCase.setSwitchLabeledRule(true);
												    	List<Statement> statements=statemetlist.get(0);
												    	if(statements.size()==1) {
												    		if(statements.get(0) instanceof ExpressionStatement) {
												    			 Statement Statement=(Statement)statements.get(0);
					                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					                    						 switchStatement.statements().add(copyStatement);
												    		}
												    		else{
												    			Block newblock=ast.newBlock();
												    			Statement Statement=(Statement)statements.get(0);
												    			 try {
						                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						                    						 newblock.statements().add(copyStatement);
						                    				    	 }catch (Exception e) {
																		// TODO: handle exception
						                    				    		 Statement.delete();
						                    				    		 newblock.statements().add(Statement);
						                    				    		 
																}
												    			 switchStatement.statements().add(newblock);
												    		}
												    	}else if(statements.size()>1) {
												    		Block newBlock=ast.newBlock();
												    		 for(int in=0;in<statements.size();in++) {
												    				if(statements.get(in) instanceof Statement) {
						                    							Statement statement=(Statement)statements.get(in);
						                    							try {
						                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
						                    							newBlock.statements().add(copyStatement);
						                    							}catch (Exception e) {
																			// TODO: handle exception
						                    								statement.delete();
						                    								newBlock.statements().add(statement);
																		}
						                    						} 
												    		 }
												    		 switchStatement.statements().add(newBlock);
												    	}
												    	
												    	SwitchCase switchCases=ast.newSwitchCase();
												    	SingleVariableDeclaration resvd=(SingleVariableDeclaration)svdlist.get(0);
												    	VariableDeclarationFragment variableDeclarationFragment=ast.newVariableDeclarationFragment();
							    					    variableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(0).getName().toString()));
				                    				    Type type=svdlist.get(0).getType();
								    					Type copyType=(Type)ASTNode.copySubtree(ast, type);
								    					VariableDeclarationExpression variableDeclarationExpression=ast.newVariableDeclarationExpression(variableDeclarationFragment);
								    				    variableDeclarationExpression.setType(copyType);
								    				    Expression newvariableExpression=(Expression)variableDeclarationExpression;
								    				    switchStatement.statements().add(switchCases);
								    					switchCases.expressions().add(newvariableExpression);
					                    				switchCases.setSwitchLabeledRule(true);
					                    				List<Statement> statementss=statemetlist.get(1);
					                    				if(statementss.size()==1) {
												    		if(statementss.get(0) instanceof ExpressionStatement) {
												    			 Statement Statement=(Statement)statementss.get(0);
					                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					                    						 switchStatement.statements().add(copyStatement);
												    		}else{
												    			Block newblock=ast.newBlock();
												    			Statement Statement=(Statement)statementss.get(0);
												    			 try {
						                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						                    						 newblock.statements().add(copyStatement);
						                    				    	 }catch (Exception e) {
																		// TODO: handle exception
						                    				    		 Statement.delete();
						                    				    		 newblock.statements().add(Statement);
						                    				    		 
																}
												    			 switchStatement.statements().add(newblock);
												    		}
												    	
					                    				}else if(statementss.size()>1) {
												    		Block newBlock=ast.newBlock();
												    		 for(int in=0;in<statementss.size();in++) {
												    				if(statementss.get(in) instanceof Statement) {
						                    							Statement statement=(Statement)statementss.get(in);
						                    							try {
						                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
						                    							newBlock.statements().add(copyStatement);
						                    							}catch (Exception e) {
																			// TODO: handle exception
						                    								statement.delete();
						                    								newBlock.statements().add(statement);
																		}
						                    						} 
												    		 }
												    		 switchStatement.statements().add(newBlock);
												    	     
					                    				}
					                    				
					                    				               				
					                    				for(int w=1;w<svdlist.size();w++) {
					                    					SwitchCase inswitchCase=ast.newSwitchCase();
					                    					List<Statement> inStatements=statemetlist.get(w+1);
					                    					if(inStatements.size()==1) {
					                    						if(!svdlist.get(w).toString().contains("MISSING")) {
					                    							SingleVariableDeclaration bresvd=(SingleVariableDeclaration)svdlist.get(w);
					                    							VariableDeclarationFragment bvariableDeclarationFragment=ast.newVariableDeclarationFragment();
					                    							bvariableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(w).getName().toString()));
					                    							Type btype=svdlist.get(w).getType();
					                    							Type bcopyType=(Type)ASTNode.copySubtree(ast, btype);
					                    							VariableDeclarationExpression bvariableDeclarationExpression=ast.newVariableDeclarationExpression(bvariableDeclarationFragment);
					                    							bvariableDeclarationExpression.setType(bcopyType);
					                    							Expression bnewvariableExpression=(Expression)bvariableDeclarationExpression;
					                    							 if(inStatements.get(0)instanceof ExpressionStatement) {
					                    								 switchStatement.statements().add(inswitchCase);
					                    								 inswitchCase.expressions().add(bnewvariableExpression);
					                    								 inswitchCase.setSwitchLabeledRule(true);
					                    								 Statement Statement=(Statement)inStatements.get(0);
					                    								 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					                    								 switchStatement.statements().add(copyStatement);
					                    							 }else if(inStatements.get(0)instanceof IfStatement) {
					                    								 IfStatement judgeIfStatement=(IfStatement)inStatements.get(0);
					                    								 if(judgeIfStatement.getExpression() instanceof InfixExpression
							                    				    			 &&judgeIfStatement.getElseStatement()==null
							                    				    			 &&judgeIfStatement.getThenStatement() instanceof Block) {
							                    				    		 InfixExpression binfixExpression=(InfixExpression)judgeIfStatement.getExpression();
							                    				    		 if(binfixExpression.getLeftOperand() instanceof MethodInvocation) {
							                    				    			 MethodInvocation methodInvocation=(MethodInvocation)binfixExpression.getLeftOperand();
							                    				    			 if(methodInvocation.getExpression().toString().equals(svdlist.get(w).getName().toString())) {
//							                    				    				 switchStatement.statements().add(switchCase);
//							        			                    				 switchCase.setSwitchLabeledRule(true);
							                    				    				 InfixExpression mergeif=ast.newInfixExpression();
							                    				    				 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
							                    				    				 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
							                    				    				 parenthesizedExpression.setExpression(copyjudgExpression);
							                    				    				 mergeif.setLeftOperand(bnewvariableExpression);
							                    				    				 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
							                    				    				 mergeif.setRightOperand(parenthesizedExpression);
							                    				    				 switchStatement.statements().add(inswitchCase);
							                    				    				 inswitchCase.expressions().add(mergeif);
							                    				    				 inswitchCase.setSwitchLabeledRule(true);
							                    				    				 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
							                    				    				 int judge=judgeBlock.statements().size();
							                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
							                    				    					 judgeBlock.statements().remove(judge-1);
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
							                    				    				 }else {
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
																					}		                    				    			 
							                    				    			 }else {
									                    				    		 switchStatement.statements().add(inswitchCase);
															    					 inswitchCase.expressions().add(bnewvariableExpression);
												                    				 inswitchCase.setSwitchLabeledRule(true);
									                    				    		 Block newblock=ast.newBlock();
										                    				    	 Statement Statement=(Statement)inStatements.get(0);
										                    				    	 try {
										                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
										                    						 newblock.statements().add(copyStatement);
										                    				    	 }catch (Exception e) {
																						// TODO: handle exception
										                    				    		 Statement.delete();
										                    				    		 newblock.statements().add(Statement);
										                    				    		 
																					}
										                    						 switchStatement.statements().add(newblock);																				
								                    				    		 
							                    				    			 }
							                    				    		 }else if(binfixExpression.getLeftOperand() instanceof QualifiedName){
							                    				    			 QualifiedName qualifiedName=(QualifiedName)binfixExpression.getLeftOperand();
							                    				    			 if(qualifiedName.getQualifier().toString().equals(svdlist.get(w).getName().toString())) {
//							                    				    				 switchStatement.statements().add(switchCase);
//							        			                    				 switchCase.setSwitchLabeledRule(true);
							                    				    				 InfixExpression mergeif=ast.newInfixExpression();
							                    				    				 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
							                    				    				 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
							                    				    				 parenthesizedExpression.setExpression(copyjudgExpression);
							                    				    				 mergeif.setLeftOperand(bnewvariableExpression);
							                    				    				 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
							                    				    				 mergeif.setRightOperand(parenthesizedExpression);
							                    				    				 switchStatement.statements().add(inswitchCase);
							                    				    				 inswitchCase.expressions().add(mergeif);
							                    				    				 inswitchCase.setSwitchLabeledRule(true);
							                    				    				 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
							                    				    				 int judge=judgeBlock.statements().size();
							                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
							                    				    					 judgeBlock.statements().remove(judge-1);
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
							                    				    				 }else {
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
																					}		                    				    			 
							                    				    			 
							                    				    			 }else {
									                    				    		 switchStatement.statements().add(inswitchCase);
															    					 inswitchCase.expressions().add(bnewvariableExpression);
												                    				 inswitchCase.setSwitchLabeledRule(true);
									                    				    		 Block newblock=ast.newBlock();
										                    				    	 Statement Statement=(Statement)inStatements.get(0);
										                    				    	 try {
										                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
										                    						 newblock.statements().add(copyStatement);
										                    				    	 }catch (Exception e) {
																						// TODO: handle exception
										                    				    		 Statement.delete();
										                    				    		 newblock.statements().add(Statement);
										                    				    		 
																					}
										                    						 switchStatement.statements().add(newblock);
																				
								                    				    		  
							                    				    			 }
							                    				    		 }else {
								                    				    		 switchStatement.statements().add(inswitchCase);
														    					 inswitchCase.expressions().add(bnewvariableExpression);
											                    				 inswitchCase.setSwitchLabeledRule(true);
								                    				    		 Block newblock=ast.newBlock();
									                    				    	 Statement Statement=(Statement)inStatements.get(0);
									                    				    	 try {
									                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
									                    						 newblock.statements().add(copyStatement);
									                    				    	 }catch (Exception e) {
																					// TODO: handle exception
									                    				    		 Statement.delete();
									                    				    		 newblock.statements().add(Statement);
									                    				    		 
																				}
									                    						 switchStatement.statements().add(newblock);
																			
							                    				    		 }
							                    				    	 
					                    								 }else if(judgeIfStatement.getExpression() instanceof InfixExpression
							                    				    			 &&judgeIfStatement.getElseStatement()!=null
							                    				    			 &&judgeIfStatement.getThenStatement() instanceof Block) {
							                    				    		 InfixExpression binfixExpression=(InfixExpression)judgeIfStatement.getExpression();
							                    				    		 if(binfixExpression.getLeftOperand() instanceof MethodInvocation) {
							                    				    			 MethodInvocation methodInvocation=(MethodInvocation)binfixExpression.getLeftOperand();
							                    				    			 if(methodInvocation.getExpression().toString().equals(svdlist.get(w).getName().toString())) {
//							                    				    				 switchStatement.statements().add(switchCase);
//							        			                    				 switchCase.setSwitchLabeledRule(true);
							                    				    				 InfixExpression mergeif=ast.newInfixExpression();
							                    				    				 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
							                    				    				 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
							                    				    				 parenthesizedExpression.setExpression(copyjudgExpression);
							                    				    				 mergeif.setLeftOperand(bnewvariableExpression);
							                    				    				 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
							                    				    				 mergeif.setRightOperand(parenthesizedExpression);
							                    				    				 switchStatement.statements().add(inswitchCase);
							                    				    				 inswitchCase.expressions().add(mergeif);
							                    				    				 inswitchCase.setSwitchLabeledRule(true);
							                    				    				 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
							                    				    				 int judge=judgeBlock.statements().size();
							                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
							                    				    					 judgeBlock.statements().remove(judge-1);
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
							                    				    				 }else {
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
																					}		 
							                    				    				 SwitchCase elseSwitchCase=ast.newSwitchCase();
							                    				    				 if(judgeIfStatement.getElseStatement() instanceof Block) {
							                    				    					 Block copyBlock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getElseStatement());
							                    				    					 switchStatement.statements().add(elseSwitchCase);
							                    				    					 Expression copyvar=(Expression)ASTNode.copySubtree(ast, bnewvariableExpression);
							                    				    					 elseSwitchCase.expressions().add(copyvar);
							                    				    					 elseSwitchCase.setSwitchLabeledRule(true);
							                    				    					 switchStatement.statements().add(copyBlock);
							                    				    					 
							                    				    				 }
							                    				    			 }else {
									                    				    		 switchStatement.statements().add(inswitchCase);
															    					 inswitchCase.expressions().add(bnewvariableExpression);
												                    				 inswitchCase.setSwitchLabeledRule(true);
									                    				    		 Block newblock=ast.newBlock();
										                    				    	 Statement Statement=(Statement)inStatements.get(0);
										                    				    	 try {
										                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
										                    						 newblock.statements().add(copyStatement);
										                    				    	 }catch (Exception e) {
																						// TODO: handle exception
										                    				    		 Statement.delete();
										                    				    		 newblock.statements().add(Statement);
										                    				    		 
																					}
										                    						 switchStatement.statements().add(newblock);																				
								                    				    		 
							                    				    			 }
							                    				    		 }else if(binfixExpression.getLeftOperand() instanceof QualifiedName){
							                    				    			 QualifiedName qualifiedName=(QualifiedName)binfixExpression.getLeftOperand();
							                    				    			 if(qualifiedName.getQualifier().toString().equals(svdlist.get(w).getName().toString())) {
//							                    				    				 switchStatement.statements().add(switchCase);
//							        			                    				 switchCase.setSwitchLabeledRule(true);
							                    				    				 InfixExpression mergeif=ast.newInfixExpression();
							                    				    				 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
							                    				    				 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
							                    				    				 parenthesizedExpression.setExpression(copyjudgExpression);
							                    				    				 mergeif.setLeftOperand(bnewvariableExpression);
							                    				    				 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
							                    				    				 mergeif.setRightOperand(parenthesizedExpression);
							                    				    				 switchStatement.statements().add(inswitchCase);
							                    				    				 inswitchCase.expressions().add(mergeif);
							                    				    				 inswitchCase.setSwitchLabeledRule(true);
							                    				    				 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
							                    				    				 int judge=judgeBlock.statements().size();
							                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
							                    				    					 judgeBlock.statements().remove(judge-1);
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
							                    				    				 }else {
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
																					}
							                    				    				 SwitchCase elseSwitchCase=ast.newSwitchCase();
							                    				    				 if(judgeIfStatement.getElseStatement() instanceof Block) {
							                    				    					 Block copyBlock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getElseStatement());
							                    				    					 switchStatement.statements().add(elseSwitchCase);
							                    				    					 Expression copyvar=(Expression)ASTNode.copySubtree(ast, bnewvariableExpression);
							                    				    					 elseSwitchCase.expressions().add(copyvar);
							                    				    					 elseSwitchCase.setSwitchLabeledRule(true);
							                    				    					 switchStatement.statements().add(copyBlock);
							                    				    					 
							                    				    				 }						                    				    			 
							                    				    			 }else {
									                    				    		 switchStatement.statements().add(inswitchCase);
															    					 inswitchCase.expressions().add(bnewvariableExpression);
												                    				 inswitchCase.setSwitchLabeledRule(true);
									                    				    		 Block newblock=ast.newBlock();
										                    				    	 Statement Statement=(Statement)inStatements.get(0);
										                    				    	 try {
										                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
										                    						 newblock.statements().add(copyStatement);
										                    				    	 }catch (Exception e) {
																						// TODO: handle exception
										                    				    		 Statement.delete();
										                    				    		 newblock.statements().add(Statement);
										                    				    		 
																					}
										                    						 switchStatement.statements().add(newblock);
																				
								                    				    		  
							                    				    			 }
							                    				    		 }else {
								                    				    		 switchStatement.statements().add(inswitchCase);
														    					 inswitchCase.expressions().add(bnewvariableExpression);
											                    				 inswitchCase.setSwitchLabeledRule(true);
								                    				    		 Block newblock=ast.newBlock();
									                    				    	 Statement Statement=(Statement)inStatements.get(0);
									                    				    	 try {
									                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
									                    						 newblock.statements().add(copyStatement);
									                    				    	 }catch (Exception e) {
																					// TODO: handle exception
									                    				    		 Statement.delete();
									                    				    		 newblock.statements().add(Statement);
									                    				    		 
																				}
									                    						 switchStatement.statements().add(newblock);
																			
							                    				    		 }
							                    				    	 
					                    								 
					                    								 }else {
						                    								 switchStatement.statements().add(inswitchCase);
						                    								 inswitchCase.expressions().add(bnewvariableExpression);
						                    								 inswitchCase.setSwitchLabeledRule(true);
						                    								 Block newblock=ast.newBlock();
						                    								 Statement Statement=(Statement)inStatements.get(0);
						                    								 try {
						    		                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						    		                    						 newblock.statements().add(copyStatement);
						    		                    				    	 }catch (Exception e) {
						    														// TODO: handle exception
						    		                    				    		 Statement.delete();
						    		                    				    		 newblock.statements().add(Statement);
						    		                    				    		 
						    													}
						                    								 switchStatement.statements().add(newblock);
						                    							 
					                    								 }
					                    							 }else {
					                    								 switchStatement.statements().add(inswitchCase);
					                    								 inswitchCase.expressions().add(bnewvariableExpression);
					                    								 inswitchCase.setSwitchLabeledRule(true);
					                    								 Block newblock=ast.newBlock();
					                    								 Statement Statement=(Statement)inStatements.get(0);
					                    								 try {
					    		                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					    		                    						 newblock.statements().add(copyStatement);
					    		                    				    	 }catch (Exception e) {
					    														// TODO: handle exception
					    		                    				    		 Statement.delete();
					    		                    				    		 newblock.statements().add(Statement);
					    		                    				    		 
					    													}
					                    								 switchStatement.statements().add(newblock);
					                    							 }
					                    						}else if(svdlist.get(w).toString().contains("MISSING")) {
					                    							SingleVariableDeclaration singleVariableDeclaration=svdlist.get(w);
																	Type bcopyType=(Type)ASTNode.copySubtree(ast, singleVariableDeclaration.getType());
																	Expression newType=ast.newName(bcopyType.toString());
																	switchStatement.statements().add(inswitchCase);
							   									    inswitchCase.expressions().add(newType);
							   									    inswitchCase.setSwitchLabeledRule(true);
							   									 if(inStatements.get(0)instanceof ExpressionStatement) {
						                    						 Statement Statement=(Statement)inStatements.get(0);
						                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						                    						 switchStatement.statements().add(copyStatement);			 
						                    				      }else {
							   									    	 Block newblock=ast.newBlock();
							                    					     Statement Statement=(Statement)inStatements.get(0);
							                    					     try {
							                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
							                    						 newblock.statements().add(copyStatement);
							                    					     }catch (Exception e) {
																			// TODO: handle exception
							                    					    	 Statement.delete();
							                    					    	 newblock.statements().add(Statement);
																		}
							                    						switchStatement.statements().add(newblock); 
						                    				      }
					                    						}
					                    					}else if(inStatements.size()>1) {
					                    						if(!svdlist.get(w).toString().contains("MISSING") ){
					                    							SingleVariableDeclaration bresvd=(SingleVariableDeclaration)svdlist.get(w);
					                    							VariableDeclarationFragment bvariableDeclarationFragment=ast.newVariableDeclarationFragment();
					                    							bvariableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(w).getName().toString()));
					                    							Type btype=svdlist.get(w).getType();
					                    							Type bcopyType=(Type)ASTNode.copySubtree(ast, btype);
					                    							VariableDeclarationExpression bvariableDeclarationExpression=ast.newVariableDeclarationExpression(bvariableDeclarationFragment);
					                    							bvariableDeclarationExpression.setType(bcopyType);
					                    							Expression bnewvariableExpression=(Expression)bvariableDeclarationExpression;
					                    							switchStatement.statements().add(inswitchCase);
											    					inswitchCase.expressions().add(bnewvariableExpression);
								                    				inswitchCase.setSwitchLabeledRule(true);
								                    				 Block newBlock=ast.newBlock();
								                    				for(int in=0;in<inStatements.size();in++) {
							                    						if(inStatements.get(in) instanceof Statement) {
							                    							Statement statement=(Statement)inStatements.get(in);
							                    							try {
							                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
							                    							newBlock.statements().add(copyStatement);
							                    							}catch (Exception e) {
																				// TODO: handle exception
							                    								statement.delete();
							                    								newBlock.statements().add(statement);
																			}
							                    						} 		                    						 
							                    					}
								                    				switchStatement.statements().add(newBlock);
					                    						}else if(svdlist.get(w).toString().contains("MISSING")) {
					                    							SingleVariableDeclaration singleVariableDeclaration=svdlist.get(w);
																	Type bcopyType=(Type)ASTNode.copySubtree(ast, singleVariableDeclaration.getType());
																	Expression newType=ast.newName(bcopyType.toString());
																	switchStatement.statements().add(inswitchCase);
							   									    inswitchCase.expressions().add(newType);
							   									    inswitchCase.setSwitchLabeledRule(true);
							   									    Block newBlock=ast.newBlock();
							   									    for(int in=0;in<inStatements.size();in++) {
							                    						if(inStatements.get(in) instanceof Statement) {
							                    							Statement statement=(Statement)inStatements.get(in);
							                    							try {
							                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
							                    							newBlock.statements().add(copyStatement);
							                    							}catch (Exception e) {
																				// TODO: handle exception
							                    								statement.delete();
							                    								newBlock.statements().add(statement);
																			}
							                    						} 		                    						 
							                    					}
								                    				switchStatement.statements().add(newBlock);
					                    						}
					                    					}
					                    					
					                    				}
					                    				ifTemp.delete();
					                    				ifStatement.delete();
					                    				
					                    				if(defaultList.isEmpty()) {
					                    					SwitchCase defaultCase=ast.newSwitchCase();
					                    					Block newBlock=ast.newBlock();
					                    					defaultCase.isDefault();
						   									defaultCase.setSwitchLabeledRule(true);
						   									switchStatement.statements().add(defaultCase);
					   										switchStatement.statements().add(newBlock);
					                    				}else if(defaultList.size()==1) {
					                    					SwitchCase defaultCase=ast.newSwitchCase();
						   									defaultCase.isDefault();
						   									defaultCase.setSwitchLabeledRule(true);
						   									switchStatement.statements().add(defaultCase);
						   									if(defaultList.get(0) instanceof ExpressionStatement) {
					   											 Statement statement=(Statement)defaultList.get(0);
					   											 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
					   											 switchStatement.statements().add(copyStatement);
					   										 }else {
					   											 Block newblock=ast.newBlock();
					   											 Statement statement=(Statement)defaultList.get(0);
					   											 try {
					   											 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
					   											 newblock.statements().add(copyStatement);
					   											 }catch (Exception e) {
																	// TODO: handle exception
					   												 statement.delete();
					   												 newblock.statements().add(statement);
																}
					   											 switchStatement.statements().add(newblock);
					   										 }
					                    					
					                    				}else if(defaultList.size()>1) {
					                    					SwitchCase defaultCase=ast.newSwitchCase();
						   									defaultCase.isDefault();
						   									defaultCase.setSwitchLabeledRule(true);
						   									switchStatement.statements().add(defaultCase);
					   										 Block newBlock=ast.newBlock();
					   										 for(int in=0;in<defaultList.size();in++) {
					   											Statement statement=(Statement)defaultList.get(in);
					   											try {
					   												Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
					   												newBlock.statements().add(copyStatement);
					   											}catch (Exception e) {
																	// TODO: handle exception
					   												statement.delete();
					   												newBlock.statements().add(statement);
					   												}
//					   											System.out.println(copyStatement);
					   											
					   										 }
					   										switchStatement.statements().add(newBlock);
					                    				}
					                    				System.out.println(switchStatement);
					                    				mBlock.statements().add(k,switchStatement);
					                    				
					                    				break;
					   								}else {
					   									if(elseIfStatement.getElseStatement()==null) {
												    	SwitchStatement switchStatement=ast.newSwitchStatement();
												    	Expression copyExpression=(Expression)ASTNode.copySubtree(ast, instanceofExpression.getLeftOperand());
												    	switchStatement.setExpression(copyExpression);
												    	SwitchCase switchCase=ast.newSwitchCase();
												    	Expression expression=ast.newNullLiteral();
												    	switchStatement.statements().add(switchCase);
												    	switchCase.expressions().add(expression);
												    	switchCase.setSwitchLabeledRule(true);
												    	List<Statement> statements=statemetlist.get(0);
												    	if(statements.size()==1) {
												    		if(statements.get(0) instanceof ExpressionStatement) {
												    			 Statement Statement=(Statement)statements.get(0);
					                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					                    						 switchStatement.statements().add(copyStatement);
												    		}else{
												    			Block newblock=ast.newBlock();
												    			Statement Statement=(Statement)statements.get(0);
												    			 try {
						                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						                    						 newblock.statements().add(copyStatement);
						                    				    	 }catch (Exception e) {
																		// TODO: handle exception
						                    				    		 Statement.delete();
						                    				    		 newblock.statements().add(Statement);
						                    				    		 
																}
												    			 switchStatement.statements().add(newblock);
												    		}
												    	}else if(statements.size()>1) {
												    		Block newBlock=ast.newBlock();
												    		 for(int in=0;in<statements.size();in++) {
												    				if(statements.get(in) instanceof Statement) {
						                    							Statement statement=(Statement)statements.get(in);
						                    							try {
						                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
						                    							newBlock.statements().add(copyStatement);
						                    							}catch (Exception e) {
																			// TODO: handle exception
						                    								statement.delete();
						                    								newBlock.statements().add(statement);
																		}
						                    						} 
												    		 }
												    		 switchStatement.statements().add(newBlock);
												    	}
												    	
												    	SwitchCase switchCases=ast.newSwitchCase();
												    	SingleVariableDeclaration resvd=(SingleVariableDeclaration)svdlist.get(0);
												    	VariableDeclarationFragment variableDeclarationFragment=ast.newVariableDeclarationFragment();
							    					    variableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(0).getName().toString()));
				                    				    Type type=svdlist.get(0).getType();
								    					Type copyType=(Type)ASTNode.copySubtree(ast, type);
								    					VariableDeclarationExpression variableDeclarationExpression=ast.newVariableDeclarationExpression(variableDeclarationFragment);
								    				    variableDeclarationExpression.setType(copyType);
								    				    Expression newvariableExpression=(Expression)variableDeclarationExpression;
								    				    switchStatement.statements().add(switchCases);
								    					switchCases.expressions().add(newvariableExpression);
					                    				switchCases.setSwitchLabeledRule(true);
					                    				List<Statement> statementss=statemetlist.get(1);
					                    				if(statementss.size()==1) {
												    		if(statementss.get(0) instanceof ExpressionStatement) {
												    			 Statement Statement=(Statement)statementss.get(0);
					                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					                    						 switchStatement.statements().add(copyStatement);
												    		}else{
												    			Block newblock=ast.newBlock();
												    			Statement Statement=(Statement)statementss.get(0);
												    			 try {
						                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						                    						 newblock.statements().add(copyStatement);
						                    				    	 }catch (Exception e) {
																		// TODO: handle exception
						                    				    		 Statement.delete();
						                    				    		 newblock.statements().add(Statement);
						                    				    		 
																}
												    			 switchStatement.statements().add(newblock);
												    		}
												    	
					                    				}else if(statementss.size()>1) {
												    		Block newBlock=ast.newBlock();
												    		 for(int in=0;in<statementss.size();in++) {
												    				if(statementss.get(in) instanceof Statement) {
						                    							Statement statement=(Statement)statementss.get(in);
						                    							try {
						                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
						                    							newBlock.statements().add(copyStatement);
						                    							}catch (Exception e) {
																			// TODO: handle exception
						                    								statement.delete();
						                    								newBlock.statements().add(statement);
																		}
						                    						} 
												    		 }
												    		 switchStatement.statements().add(newBlock);
												    	     
					                    				}
//					                    	            System.out.println(switchStatement);
					                    				for(int w=1;w<svdlist.size();w++) {
					                    					SwitchCase inswitchCase=ast.newSwitchCase();
					                    					List<Statement> inStatements=statemetlist.get(w+1);
					                    					if(inStatements.size()==1) {
					                    						if(!svdlist.get(w).toString().contains("MISSING")) {
					                    							SingleVariableDeclaration bresvd=(SingleVariableDeclaration)svdlist.get(w);
					                    							VariableDeclarationFragment bvariableDeclarationFragment=ast.newVariableDeclarationFragment();
					                    							bvariableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(w).getName().toString()));
					                    							Type btype=svdlist.get(w).getType();
					                    							Type bcopyType=(Type)ASTNode.copySubtree(ast, btype);
					                    							VariableDeclarationExpression bvariableDeclarationExpression=ast.newVariableDeclarationExpression(bvariableDeclarationFragment);
					                    							bvariableDeclarationExpression.setType(bcopyType);
					                    							Expression bnewvariableExpression=(Expression)bvariableDeclarationExpression;
					                    							 if(inStatements.get(0)instanceof ExpressionStatement) {
					                    								 switchStatement.statements().add(inswitchCase);
					                    								 inswitchCase.expressions().add(bnewvariableExpression);
					                    								 inswitchCase.setSwitchLabeledRule(true);
					                    								 Statement Statement=(Statement)inStatements.get(0);
					                    								 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					                    								 switchStatement.statements().add(copyStatement);
					                    							 }else if(inStatements.get(0)instanceof IfStatement){

					                    								 IfStatement judgeIfStatement=(IfStatement)inStatements.get(0);
					                    								 if(judgeIfStatement.getExpression() instanceof InfixExpression
							                    				    			 &&judgeIfStatement.getElseStatement()==null
							                    				    			 &&judgeIfStatement.getThenStatement() instanceof Block) {
							                    				    		 InfixExpression binfixExpression=(InfixExpression)judgeIfStatement.getExpression();
							                    				    		 if(binfixExpression.getLeftOperand() instanceof MethodInvocation) {
							                    				    			 MethodInvocation methodInvocation=(MethodInvocation)binfixExpression.getLeftOperand();
							                    				    			 if(methodInvocation.getExpression().toString().equals(svdlist.get(w).getName().toString())) {
//							                    				    				 switchStatement.statements().add(switchCase);
//							        			                    				 switchCase.setSwitchLabeledRule(true);
							                    				    				 InfixExpression mergeif=ast.newInfixExpression();
							                    				    				 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
							                    				    				 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
							                    				    				 parenthesizedExpression.setExpression(copyjudgExpression);
							                    				    				 mergeif.setLeftOperand(bnewvariableExpression);
							                    				    				 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
							                    				    				 mergeif.setRightOperand(parenthesizedExpression);
							                    				    				 switchStatement.statements().add(inswitchCase);
							                    				    				 inswitchCase.expressions().add(mergeif);
							                    				    				 inswitchCase.setSwitchLabeledRule(true);
							                    				    				 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
							                    				    				 int judge=judgeBlock.statements().size();
							                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
							                    				    					 judgeBlock.statements().remove(judge-1);
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
							                    				    				 }else {
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
																					}		                    				    			 
							                    				    			 }else {
									                    				    		 switchStatement.statements().add(inswitchCase);
															    					 inswitchCase.expressions().add(bnewvariableExpression);
												                    				 inswitchCase.setSwitchLabeledRule(true);
									                    				    		 Block newblock=ast.newBlock();
										                    				    	 Statement Statement=(Statement)inStatements.get(0);
										                    				    	 try {
										                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
										                    						 newblock.statements().add(copyStatement);
										                    				    	 }catch (Exception e) {
																						// TODO: handle exception
										                    				    		 Statement.delete();
										                    				    		 newblock.statements().add(Statement);
										                    				    		 
																					}
										                    						 switchStatement.statements().add(newblock);																				
								                    				    		 
							                    				    			 }
							                    				    		 }else if(binfixExpression.getLeftOperand() instanceof QualifiedName){
							                    				    			 QualifiedName qualifiedName=(QualifiedName)binfixExpression.getLeftOperand();
							                    				    			 if(qualifiedName.getQualifier().toString().equals(svdlist.get(w).getName().toString())) {
//							                    				    				 switchStatement.statements().add(switchCase);
//							        			                    				 switchCase.setSwitchLabeledRule(true);
							                    				    				 InfixExpression mergeif=ast.newInfixExpression();
							                    				    				 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
							                    				    				 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
							                    				    				 parenthesizedExpression.setExpression(copyjudgExpression);
							                    				    				 mergeif.setLeftOperand(bnewvariableExpression);
							                    				    				 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
							                    				    				 mergeif.setRightOperand(parenthesizedExpression);
							                    				    				 switchStatement.statements().add(inswitchCase);
							                    				    				 inswitchCase.expressions().add(mergeif);
							                    				    				 inswitchCase.setSwitchLabeledRule(true);
							                    				    				 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
							                    				    				 int judge=judgeBlock.statements().size();
							                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
							                    				    					 judgeBlock.statements().remove(judge-1);
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
							                    				    				 }else {
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
																					}		                    				    			 
							                    				    			 
							                    				    			 }else {
									                    				    		 switchStatement.statements().add(inswitchCase);
															    					 inswitchCase.expressions().add(bnewvariableExpression);
												                    				 inswitchCase.setSwitchLabeledRule(true);
									                    				    		 Block newblock=ast.newBlock();
										                    				    	 Statement Statement=(Statement)inStatements.get(0);
										                    				    	 try {
										                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
										                    						 newblock.statements().add(copyStatement);
										                    				    	 }catch (Exception e) {
																						// TODO: handle exception
										                    				    		 Statement.delete();
										                    				    		 newblock.statements().add(Statement);
										                    				    		 
																					}
										                    						 switchStatement.statements().add(newblock);
																				
								                    				    		  
							                    				    			 }
							                    				    		 }else {
								                    				    		 switchStatement.statements().add(inswitchCase);
														    					 inswitchCase.expressions().add(bnewvariableExpression);
											                    				 inswitchCase.setSwitchLabeledRule(true);
								                    				    		 Block newblock=ast.newBlock();
									                    				    	 Statement Statement=(Statement)inStatements.get(0);
									                    				    	 try {
									                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
									                    						 newblock.statements().add(copyStatement);
									                    				    	 }catch (Exception e) {
																					// TODO: handle exception
									                    				    		 Statement.delete();
									                    				    		 newblock.statements().add(Statement);
									                    				    		 
																				}
									                    						 switchStatement.statements().add(newblock);
																			
							                    				    		 }
							                    				    	 
					                    								 }else if(judgeIfStatement.getExpression() instanceof InfixExpression
							                    				    			 &&judgeIfStatement.getElseStatement()!=null
							                    				    			 &&judgeIfStatement.getThenStatement() instanceof Block) {
							                    				    		 InfixExpression binfixExpression=(InfixExpression)judgeIfStatement.getExpression();
							                    				    		 if(binfixExpression.getLeftOperand() instanceof MethodInvocation) {
							                    				    			 MethodInvocation methodInvocation=(MethodInvocation)binfixExpression.getLeftOperand();
							                    				    			 if(methodInvocation.getExpression().toString().equals(svdlist.get(w).getName().toString())) {
//							                    				    				 switchStatement.statements().add(switchCase);
//							        			                    				 switchCase.setSwitchLabeledRule(true);
							                    				    				 InfixExpression mergeif=ast.newInfixExpression();
							                    				    				 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
							                    				    				 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
							                    				    				 parenthesizedExpression.setExpression(copyjudgExpression);
							                    				    				 mergeif.setLeftOperand(bnewvariableExpression);
							                    				    				 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
							                    				    				 mergeif.setRightOperand(parenthesizedExpression);
							                    				    				 switchStatement.statements().add(inswitchCase);
							                    				    				 inswitchCase.expressions().add(mergeif);
							                    				    				 inswitchCase.setSwitchLabeledRule(true);
							                    				    				 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
							                    				    				 int judge=judgeBlock.statements().size();
							                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
							                    				    					 judgeBlock.statements().remove(judge-1);
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
							                    				    				 }else {
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
																					}		 
							                    				    				 SwitchCase elseSwitchCase=ast.newSwitchCase();
							                    				    				 if(judgeIfStatement.getElseStatement() instanceof Block) {
							                    				    					 Block copyBlock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getElseStatement());
							                    				    					 switchStatement.statements().add(elseSwitchCase);
							                    				    					 Expression copyvar=(Expression)ASTNode.copySubtree(ast, bnewvariableExpression);
							                    				    					 elseSwitchCase.expressions().add(copyvar);
							                    				    					 elseSwitchCase.setSwitchLabeledRule(true);
							                    				    					 switchStatement.statements().add(copyBlock);
							                    				    					 
							                    				    				 }
							                    				    			 }else {
									                    				    		 switchStatement.statements().add(inswitchCase);
															    					 inswitchCase.expressions().add(bnewvariableExpression);
												                    				 inswitchCase.setSwitchLabeledRule(true);
									                    				    		 Block newblock=ast.newBlock();
										                    				    	 Statement Statement=(Statement)inStatements.get(0);
										                    				    	 try {
										                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
										                    						 newblock.statements().add(copyStatement);
										                    				    	 }catch (Exception e) {
																						// TODO: handle exception
										                    				    		 Statement.delete();
										                    				    		 newblock.statements().add(Statement);
										                    				    		 
																					}
										                    						 switchStatement.statements().add(newblock);																				
								                    				    		 
							                    				    			 }
							                    				    		 }else if(binfixExpression.getLeftOperand() instanceof QualifiedName){
							                    				    			 QualifiedName qualifiedName=(QualifiedName)binfixExpression.getLeftOperand();
							                    				    			 if(qualifiedName.getQualifier().toString().equals(svdlist.get(w).getName().toString())) {
//							                    				    				 switchStatement.statements().add(switchCase);
//							        			                    				 switchCase.setSwitchLabeledRule(true);
							                    				    				 InfixExpression mergeif=ast.newInfixExpression();
							                    				    				 Expression copyjudgExpression=(Expression)ASTNode.copySubtree(ast, judgeIfStatement.getExpression());
							                    				    				 ParenthesizedExpression parenthesizedExpression=ast.newParenthesizedExpression();
							                    				    				 parenthesizedExpression.setExpression(copyjudgExpression);
							                    				    				 mergeif.setLeftOperand(bnewvariableExpression);
							                    				    				 mergeif.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
							                    				    				 mergeif.setRightOperand(parenthesizedExpression);
							                    				    				 switchStatement.statements().add(inswitchCase);
							                    				    				 inswitchCase.expressions().add(mergeif);
							                    				    				 inswitchCase.setSwitchLabeledRule(true);
							                    				    				 Block judgeBlock=(Block)judgeIfStatement.getThenStatement();
							                    				    				 int judge=judgeBlock.statements().size();
							                    				    				 if(judgeBlock.statements().get(judge-1) instanceof BreakStatement) {
							                    				    					 judgeBlock.statements().remove(judge-1);
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
							                    				    				 }else {
							                    				    					 Block newblock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getThenStatement());
								                    				    				 switchStatement.statements().add(newblock);
																					}
							                    				    				 SwitchCase elseSwitchCase=ast.newSwitchCase();
							                    				    				 if(judgeIfStatement.getElseStatement() instanceof Block) {
							                    				    					 Block copyBlock=(Block)ASTNode.copySubtree(ast, judgeIfStatement.getElseStatement());
							                    				    					 switchStatement.statements().add(elseSwitchCase);
							                    				    					 Expression copyvar=(Expression)ASTNode.copySubtree(ast, bnewvariableExpression);
							                    				    					 elseSwitchCase.expressions().add(copyvar);
							                    				    					 elseSwitchCase.setSwitchLabeledRule(true);
							                    				    					 switchStatement.statements().add(copyBlock);
							                    				    					 
							                    				    				 }						                    				    			 
							                    				    			 }else {
									                    				    		 switchStatement.statements().add(inswitchCase);
															    					 inswitchCase.expressions().add(bnewvariableExpression);
												                    				 inswitchCase.setSwitchLabeledRule(true);
									                    				    		 Block newblock=ast.newBlock();
										                    				    	 Statement Statement=(Statement)inStatements.get(0);
										                    				    	 try {
										                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
										                    						 newblock.statements().add(copyStatement);
										                    				    	 }catch (Exception e) {
																						// TODO: handle exception
										                    				    		 Statement.delete();
										                    				    		 newblock.statements().add(Statement);
										                    				    		 
																					}
										                    						 switchStatement.statements().add(newblock);
																				
								                    				    		  
							                    				    			 }
							                    				    		 }else {
								                    				    		 switchStatement.statements().add(inswitchCase);
														    					 inswitchCase.expressions().add(bnewvariableExpression);
											                    				 inswitchCase.setSwitchLabeledRule(true);
								                    				    		 Block newblock=ast.newBlock();
									                    				    	 Statement Statement=(Statement)inStatements.get(0);
									                    				    	 try {
									                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
									                    						 newblock.statements().add(copyStatement);
									                    				    	 }catch (Exception e) {
																					// TODO: handle exception
									                    				    		 Statement.delete();
									                    				    		 newblock.statements().add(Statement);
									                    				    		 
																				}
									                    						 switchStatement.statements().add(newblock);
																			
							                    				    		 }
							                    				    	 
					                    								 
					                    								 }else {
						                    								 switchStatement.statements().add(inswitchCase);
						                    								 inswitchCase.expressions().add(bnewvariableExpression);
						                    								 inswitchCase.setSwitchLabeledRule(true);
						                    								 Block newblock=ast.newBlock();
						                    								 Statement Statement=(Statement)inStatements.get(0);
						                    								 try {
						    		                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						    		                    						 newblock.statements().add(copyStatement);
						    		                    				    	 }catch (Exception e) {
						    														// TODO: handle exception
						    		                    				    		 Statement.delete();
						    		                    				    		 newblock.statements().add(Statement);
						    		                    				    		 
						    													}
						                    								 switchStatement.statements().add(newblock);
						                    							 
					                    								 }
					                    							 
					                    								 
					                    							 }
					                    							 else {
					                    								 switchStatement.statements().add(inswitchCase);
					                    								 inswitchCase.expressions().add(bnewvariableExpression);
					                    								 inswitchCase.setSwitchLabeledRule(true);
					                    								 Block newblock=ast.newBlock();
					                    								 Statement Statement=(Statement)inStatements.get(0);
					                    								 try {
					    		                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					    		                    						 newblock.statements().add(copyStatement);
					    		                    				    	 }catch (Exception e) {
					    														// TODO: handle exception
					    		                    				    		 Statement.delete();
					    		                    				    		 newblock.statements().add(Statement);
					    		                    				    		 
					    													}
					                    								 switchStatement.statements().add(newblock);
					                    							 }
					                    						}else if(svdlist.get(w).toString().contains("MISSING")) {
					                    							SingleVariableDeclaration singleVariableDeclaration=svdlist.get(w);
																	Type bcopyType=(Type)ASTNode.copySubtree(ast, singleVariableDeclaration.getType());
																	Expression newType=ast.newName(bcopyType.toString());
																	switchStatement.statements().add(inswitchCase);
							   									    inswitchCase.expressions().add(newType);
							   									    inswitchCase.setSwitchLabeledRule(true);
							   									 if(inStatements.get(0)instanceof ExpressionStatement) {
						                    						 Statement Statement=(Statement)inStatements.get(0);
						                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						                    						 switchStatement.statements().add(copyStatement);			 
						                    				      }else {
							   									    	 Block newblock=ast.newBlock();
							                    					     Statement Statement=(Statement)inStatements.get(0);
							                    					     try {
							                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
							                    						 newblock.statements().add(copyStatement);
							                    					     }catch (Exception e) {
																			// TODO: handle exception
							                    					    	 Statement.delete();
							                    					    	 newblock.statements().add(Statement);
																		}
							                    						switchStatement.statements().add(newblock); 
						                    				      }
					                    						}
					                    					}else if(inStatements.size()>1) {
					                    						if(!svdlist.get(w).toString().contains("MISSING") ){
					                    							SingleVariableDeclaration bresvd=(SingleVariableDeclaration)svdlist.get(w);
					                    							VariableDeclarationFragment bvariableDeclarationFragment=ast.newVariableDeclarationFragment();
					                    							bvariableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(w).getName().toString()));
					                    							Type btype=svdlist.get(w).getType();
					                    							Type bcopyType=(Type)ASTNode.copySubtree(ast, btype);
					                    							VariableDeclarationExpression bvariableDeclarationExpression=ast.newVariableDeclarationExpression(bvariableDeclarationFragment);
					                    							bvariableDeclarationExpression.setType(bcopyType);
					                    							Expression bnewvariableExpression=(Expression)bvariableDeclarationExpression;
					                    							switchStatement.statements().add(inswitchCase);
											    					inswitchCase.expressions().add(bnewvariableExpression);
								                    				inswitchCase.setSwitchLabeledRule(true);
								                    				 Block newBlock=ast.newBlock();
								                    				for(int in=0;in<inStatements.size();in++) {
							                    						if(inStatements.get(in) instanceof Statement) {
							                    							Statement statement=(Statement)inStatements.get(in);
							                    							try {
							                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
							                    							newBlock.statements().add(copyStatement);
							                    							}catch (Exception e) {
																				// TODO: handle exception
							                    								statement.delete();
							                    								newBlock.statements().add(statement);
																			}
							                    						} 		                    						 
							                    					}
								                    				switchStatement.statements().add(newBlock);
					                    						}else if(svdlist.get(w).toString().contains("MISSING")) {
					                    							SingleVariableDeclaration singleVariableDeclaration=svdlist.get(w);
																	Type bcopyType=(Type)ASTNode.copySubtree(ast, singleVariableDeclaration.getType());
																	Expression newType=ast.newName(bcopyType.toString());
																	switchStatement.statements().add(inswitchCase);
							   									    inswitchCase.expressions().add(newType);
							   									    inswitchCase.setSwitchLabeledRule(true);
							   									    Block newBlock=ast.newBlock();
							   									    for(int in=0;in<inStatements.size();in++) {
							                    						if(inStatements.get(in) instanceof Statement) {
							                    							Statement statement=(Statement)inStatements.get(in);
							                    							try {
							                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
							                    							newBlock.statements().add(copyStatement);
							                    							}catch (Exception e) {
																				// TODO: handle exception
							                    								statement.delete();
							                    								newBlock.statements().add(statement);
																			}
							                    						} 		                    						 
							                    					}
								                    				switchStatement.statements().add(newBlock);
					                    						}
					                    					}
					                    					
					                    				}
					                    				ifTemp.delete();
					                    				ifStatement.delete();
					                    				mBlock.statements().add(k,switchStatement);
					                    				System.out.println(switchStatement);
					                    				break;
					   								}else {

												    	SwitchStatement switchStatement=ast.newSwitchStatement();
												    	Expression copyExpression=(Expression)ASTNode.copySubtree(ast, instanceofExpression.getLeftOperand());
												    	switchStatement.setExpression(copyExpression);
												    	SwitchCase switchCase=ast.newSwitchCase();
												    	Expression expression=ast.newNullLiteral();
												    	switchStatement.statements().add(switchCase);
												    	switchCase.expressions().add(expression);
												    	switchCase.setSwitchLabeledRule(true);
												    	List<Statement> statements=statemetlist.get(0);
												    	if(statements.size()==1) {
												    		if(statements.get(0) instanceof ExpressionStatement) {
												    			 Statement Statement=(Statement)statements.get(0);
					                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					                    						 switchStatement.statements().add(copyStatement);
												    		}else{
												    			Block newblock=ast.newBlock();
												    			Statement Statement=(Statement)statements.get(0);
												    			 try {
						                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						                    						 newblock.statements().add(copyStatement);
						                    				    	 }catch (Exception e) {
																		// TODO: handle exception
						                    				    		 Statement.delete();
						                    				    		 newblock.statements().add(Statement);
						                    				    		 
																}
												    			 switchStatement.statements().add(newblock);
												    		}
												    	}else if(statements.size()>1) {
												    		Block newBlock=ast.newBlock();
												    		 for(int in=0;in<statements.size();in++) {
												    				if(statements.get(in) instanceof Statement) {
						                    							Statement statement=(Statement)statements.get(in);
						                    							try {
						                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
						                    							newBlock.statements().add(copyStatement);
						                    							}catch (Exception e) {
																			// TODO: handle exception
						                    								statement.delete();
						                    								newBlock.statements().add(statement);
																		}
						                    						} 
												    		 }
												    		 switchStatement.statements().add(newBlock);
												    	}
												    	
												    	SwitchCase switchCases=ast.newSwitchCase();
												    	SingleVariableDeclaration resvd=(SingleVariableDeclaration)svdlist.get(0);
												    	VariableDeclarationFragment variableDeclarationFragment=ast.newVariableDeclarationFragment();
							    					    variableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(0).getName().toString()));
				                    				    Type type=svdlist.get(0).getType();
								    					Type copyType=(Type)ASTNode.copySubtree(ast, type);
								    					VariableDeclarationExpression variableDeclarationExpression=ast.newVariableDeclarationExpression(variableDeclarationFragment);
								    				    variableDeclarationExpression.setType(copyType);
								    				    Expression newvariableExpression=(Expression)variableDeclarationExpression;
								    				    switchStatement.statements().add(switchCases);
								    					switchCases.expressions().add(newvariableExpression);
					                    				switchCases.setSwitchLabeledRule(true);
					                    				List<Statement> statementss=statemetlist.get(1);
					                    				if(statementss.size()==1) {
												    		if(statementss.get(0) instanceof ExpressionStatement) {
												    			 Statement Statement=(Statement)statementss.get(0);
					                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					                    						 switchStatement.statements().add(copyStatement);
												    		}else{
												    			Block newblock=ast.newBlock();
												    			Statement Statement=(Statement)statementss.get(0);
												    			 try {
						                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						                    						 newblock.statements().add(copyStatement);
						                    				    	 }catch (Exception e) {
																		// TODO: handle exception
						                    				    		 Statement.delete();
						                    				    		 newblock.statements().add(Statement);
						                    				    		 
																}
												    			 switchStatement.statements().add(newblock);
												    		}
												    	
					                    				}else if(statementss.size()>1) {
												    		Block newBlock=ast.newBlock();
												    		 for(int in=0;in<statementss.size();in++) {
												    				if(statementss.get(in) instanceof Statement) {
						                    							Statement statement=(Statement)statementss.get(in);
						                    							try {
						                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
						                    							newBlock.statements().add(copyStatement);
						                    							}catch (Exception e) {
																			// TODO: handle exception
						                    								statement.delete();
						                    								newBlock.statements().add(statement);
																		}
						                    						} 
												    		 }
												    		 switchStatement.statements().add(newBlock);
												    	     
					                    				}
//					                    	            System.out.println(switchStatement);
					                    				for(int w=1;w<svdlist.size();w++) {
					                    					SwitchCase inswitchCase=ast.newSwitchCase();
					                    					List<Statement> inStatements=statemetlist.get(w+1);
					                    					if(inStatements.size()==1) {
					                    						if(!svdlist.get(w).toString().contains("MISSING")) {
					                    							SingleVariableDeclaration bresvd=(SingleVariableDeclaration)svdlist.get(w);
					                    							VariableDeclarationFragment bvariableDeclarationFragment=ast.newVariableDeclarationFragment();
					                    							bvariableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(w).getName().toString()));
					                    							Type btype=svdlist.get(w).getType();
					                    							Type bcopyType=(Type)ASTNode.copySubtree(ast, btype);
					                    							VariableDeclarationExpression bvariableDeclarationExpression=ast.newVariableDeclarationExpression(bvariableDeclarationFragment);
					                    							bvariableDeclarationExpression.setType(bcopyType);
					                    							Expression bnewvariableExpression=(Expression)bvariableDeclarationExpression;
					                    							 if(inStatements.get(0)instanceof ExpressionStatement) {
					                    								 switchStatement.statements().add(inswitchCase);
					                    								 inswitchCase.expressions().add(bnewvariableExpression);
					                    								 inswitchCase.setSwitchLabeledRule(true);
					                    								 Statement Statement=(Statement)inStatements.get(0);
					                    								 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					                    								 switchStatement.statements().add(copyStatement);
					                    							 }else {
					                    								 switchStatement.statements().add(inswitchCase);
					                    								 inswitchCase.expressions().add(bnewvariableExpression);
					                    								 inswitchCase.setSwitchLabeledRule(true);
					                    								 Block newblock=ast.newBlock();
					                    								 Statement Statement=(Statement)inStatements.get(0);
					                    								 try {
					    		                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
					    		                    						 newblock.statements().add(copyStatement);
					    		                    				    	 }catch (Exception e) {
					    														// TODO: handle exception
					    		                    				    		 Statement.delete();
					    		                    				    		 newblock.statements().add(Statement);
					    		                    				    		 
					    													}
					                    								 switchStatement.statements().add(newblock);
					                    							 }
					                    						}else if(svdlist.get(w).toString().contains("MISSING")) {
					                    							SingleVariableDeclaration singleVariableDeclaration=svdlist.get(w);
																	Type bcopyType=(Type)ASTNode.copySubtree(ast, singleVariableDeclaration.getType());
																	Expression newType=ast.newName(bcopyType.toString());
																	switchStatement.statements().add(inswitchCase);
							   									    inswitchCase.expressions().add(newType);
							   									    inswitchCase.setSwitchLabeledRule(true);
							   									 if(inStatements.get(0)instanceof ExpressionStatement) {
						                    						 Statement Statement=(Statement)inStatements.get(0);
						                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
						                    						 switchStatement.statements().add(copyStatement);			 
						                    				      }else {
							   									    	 Block newblock=ast.newBlock();
							                    					     Statement Statement=(Statement)inStatements.get(0);
							                    					     try {
							                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
							                    						 newblock.statements().add(copyStatement);
							                    					     }catch (Exception e) {
																			// TODO: handle exception
							                    					    	 Statement.delete();
							                    					    	 newblock.statements().add(Statement);
																		}
							                    						switchStatement.statements().add(newblock); 
						                    				      }
					                    						}
					                    					}else if(inStatements.size()>1) {
					                    						if(!svdlist.get(w).toString().contains("MISSING") ){
					                    							SingleVariableDeclaration bresvd=(SingleVariableDeclaration)svdlist.get(w);
					                    							VariableDeclarationFragment bvariableDeclarationFragment=ast.newVariableDeclarationFragment();
					                    							bvariableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(w).getName().toString()));
					                    							Type btype=svdlist.get(w).getType();
					                    							Type bcopyType=(Type)ASTNode.copySubtree(ast, btype);
					                    							VariableDeclarationExpression bvariableDeclarationExpression=ast.newVariableDeclarationExpression(bvariableDeclarationFragment);
					                    							bvariableDeclarationExpression.setType(bcopyType);
					                    							Expression bnewvariableExpression=(Expression)bvariableDeclarationExpression;
					                    							switchStatement.statements().add(inswitchCase);
											    					inswitchCase.expressions().add(bnewvariableExpression);
								                    				inswitchCase.setSwitchLabeledRule(true);
								                    				 Block newBlock=ast.newBlock();
								                    				for(int in=0;in<inStatements.size();in++) {
							                    						if(inStatements.get(in) instanceof Statement) {
							                    							Statement statement=(Statement)inStatements.get(in);
							                    							try {
							                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
							                    							newBlock.statements().add(copyStatement);
							                    							}catch (Exception e) {
																				// TODO: handle exception
							                    								statement.delete();
							                    								newBlock.statements().add(statement);
																			}
							                    						} 		                    						 
							                    					}
								                    				switchStatement.statements().add(newBlock);
					                    						}else if(svdlist.get(w).toString().contains("MISSING")) {
					                    							SingleVariableDeclaration singleVariableDeclaration=svdlist.get(w);
																	Type bcopyType=(Type)ASTNode.copySubtree(ast, singleVariableDeclaration.getType());
																	Expression newType=ast.newName(bcopyType.toString());
																	switchStatement.statements().add(inswitchCase);
							   									    inswitchCase.expressions().add(newType);
							   									    inswitchCase.setSwitchLabeledRule(true);
							   									    Block newBlock=ast.newBlock();
							   									    for(int in=0;in<inStatements.size();in++) {
							                    						if(inStatements.get(in) instanceof Statement) {
							                    							Statement statement=(Statement)inStatements.get(in);
							                    							try {
							                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
							                    							newBlock.statements().add(copyStatement);
							                    							}catch (Exception e) {
																				// TODO: handle exception
							                    								statement.delete();
							                    								newBlock.statements().add(statement);
																			}
							                    						} 		                    						 
							                    					}
								                    				switchStatement.statements().add(newBlock);
					                    						}
					                    					}
					                    					
					                    				}
					                    				ifTemp.delete();
					                    				ifStatement.delete();
					                    				SwitchCase defaultCase=ast.newSwitchCase();
					                    				defaultCase.isDefault();
					                    				defaultCase.setSwitchLabeledRule(true);
					                    				switchStatement.statements().add(defaultCase);
					                    				Statement copyStatement=(Statement)ASTNode.copySubtree(ast, elseIfStatement.getElseStatement());
					                    				switchStatement.statements().add(copyStatement);
					                    				mBlock.statements().add(k,switchStatement);
					                    				System.out.println(switchStatement);
					                    				break;
					   								
					   								}
					   								}
										    	}
										    }else if(ifStatement.getElseStatement()!=null&&ifStatement.getElseStatement() instanceof Block) {
										    	Block defaultBlock=(Block)ifStatement.getElseStatement();
			   									for(int d=0;d<defaultBlock.statements().size();d++) {
			   										edefaultList.add((Statement)defaultBlock.statements().get(d));
			   									}
										    	SwitchStatement switchStatement=ast.newSwitchStatement();
										    	Expression copyExpression=(Expression)ASTNode.copySubtree(ast, instanceofExpression.getLeftOperand());
										    	switchStatement.setExpression(copyExpression);
										    	SwitchCase switchCase=ast.newSwitchCase();
										    	Expression expression=ast.newNullLiteral();
										    	switchStatement.statements().add(switchCase);
										    	switchCase.expressions().add(expression);
										    	switchCase.setSwitchLabeledRule(true);
										    	List<Statement> statements=statemetlist.get(0);
										    	if(statements.size()==1) {
										    		if(statements.get(0) instanceof ExpressionStatement) {
										    			 Statement Statement=(Statement)statements.get(0);
			                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
			                    						 switchStatement.statements().add(copyStatement);			 
										    		}else{
										    			Block newblock=ast.newBlock();
										    			Statement Statement=(Statement)statements.get(0);
										    			 try {
				                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
				                    						 newblock.statements().add(copyStatement);
				                    				    	 }catch (Exception e) {
																// TODO: handle exception
				                    				    		 Statement.delete();
				                    				    		 newblock.statements().add(Statement);
				                    				    		 
														}
										    			 switchStatement.statements().add(newblock);
										    		}
										    	}else if(statements.size()>1) {
										    		Block newBlock=ast.newBlock();
										    		 for(int in=0;in<statements.size();in++) {
										    				if(statements.get(in) instanceof Statement) {
				                    							Statement statement=(Statement)statements.get(in);
				                    							try {
				                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
				                    							newBlock.statements().add(copyStatement);
				                    							}catch (Exception e) {
																	// TODO: handle exception
				                    								statement.delete();
				                    								newBlock.statements().add(statement);
																}
				                    						} 
										    		 }
										    		 switchStatement.statements().add(newBlock);
										    	}
										    	SwitchCase switchCases=ast.newSwitchCase();
										    	SingleVariableDeclaration resvd=(SingleVariableDeclaration)svdlist.get(0);
										    	VariableDeclarationFragment variableDeclarationFragment=ast.newVariableDeclarationFragment();
					    					    variableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(0).getName().toString()));
		                    				    Type type=svdlist.get(0).getType();
						    					Type copyType=(Type)ASTNode.copySubtree(ast, type);
						    					VariableDeclarationExpression variableDeclarationExpression=ast.newVariableDeclarationExpression(variableDeclarationFragment);
						    				    variableDeclarationExpression.setType(copyType);
						    				    Expression newvariableExpression=(Expression)variableDeclarationExpression;
						    				    switchStatement.statements().add(switchCases);
						    					switchCases.expressions().add(newvariableExpression);
			                    				switchCases.setSwitchLabeledRule(true);
			                    				List<Statement> statementss=statemetlist.get(1);
			                    				if(statementss.size()==1) {
										    		if(statementss.get(0) instanceof ExpressionStatement) {
										    			 Statement Statement=(Statement)statementss.get(0);
			                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
			                    						 switchStatement.statements().add(copyStatement);			 
										    		}else{
										    			Block newblock=ast.newBlock();
										    			Statement Statement=(Statement)statementss.get(0);
										    			 try {
				                    						 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, Statement);
				                    						 newblock.statements().add(copyStatement);
				                    				    	 }catch (Exception e) {
																// TODO: handle exception
				                    				    		 Statement.delete();
				                    				    		 newblock.statements().add(Statement);
				                    				    		 
														}
										    			 switchStatement.statements().add(newblock);
										    		}
										    	
			                    				}else if(statementss.size()>1) {
										    		Block newBlock=ast.newBlock();
										    		 for(int in=0;in<statementss.size();in++) {
										    				if(statementss.get(in) instanceof Statement) {
				                    							Statement statement=(Statement)statementss.get(in);
				                    							try {
				                    							Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
				                    							newBlock.statements().add(copyStatement);
				                    							}catch (Exception e) {
																	// TODO: handle exception
				                    								statement.delete();
				                    								newBlock.statements().add(statement);
																}
				                    						} 
										    		 }
										    		 switchStatement.statements().add(newBlock);
										    	     
			                    				}
			                    				ifTemp.delete();
			                    				ifStatement.delete();
			                    				if(edefaultList.isEmpty()) {
			                    					SwitchCase defaultCase=ast.newSwitchCase();
			   										Block newBlock=ast.newBlock();
			   										defaultCase.isDefault();
				   									defaultCase.setSwitchLabeledRule(true);
				   									switchStatement.statements().add(defaultCase);
			   										switchStatement.statements().add(newBlock);
			                    				}else if(edefaultList.size()==1) {
			                    					SwitchCase defaultCase=ast.newSwitchCase();
				   									defaultCase.isDefault();
				   									defaultCase.setSwitchLabeledRule(true);
				   									switchStatement.statements().add(defaultCase);
				   									if(edefaultList.get(0) instanceof ExpressionStatement) {
			   											 Statement statement=(Statement)edefaultList.get(0);
			   											 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
			   											 switchStatement.statements().add(copyStatement);
			   										 }else {
			   											 Block newblock=ast.newBlock();
			   											 Statement statement=(Statement)defaultList.get(0);
			   											 try {
			   											 Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
			   											 newblock.statements().add(copyStatement);
			   											 }catch (Exception e) {
															// TODO: handle exception
			   												 statement.delete();
			   												 newblock.statements().add(statement);
														}
			   											 switchStatement.statements().add(newblock);
			   										 }
			                    					
			                    				}else if(edefaultList.size()>1) {
			                    					SwitchCase defaultCase=ast.newSwitchCase();
				   									defaultCase.isDefault();
				   									defaultCase.setSwitchLabeledRule(true);
				   									switchStatement.statements().add(defaultCase);
			   										 Block newBlock=ast.newBlock();
			   										 for(int in=0;in<edefaultList.size();in++) {
			   											Statement statement=(Statement)edefaultList.get(in);
			   											try {
			   												Statement copyStatement=(Statement)ASTNode.copySubtree(ast, statement);
			   												newBlock.statements().add(copyStatement);
			   											}catch (Exception e) {
															// TODO: handle exception
			   												statement.delete();
			   												newBlock.statements().add(statement);
			   												}
//			   											System.out.println(copyStatement);
			   											
			   										 }
			   										switchStatement.statements().add(newBlock);
			                    				}
			                    				System.out.println(switchStatement);
			                    				mBlock.statements().add(k,switchStatement);
										    
										    }
//										    System.out.println(svdlist);
//										    System.out.println(statemetlist);
									 }else {
										 break;
									 }
								 }else {
									 break;
								 }
							 }else {
								 break;
							 }
						 }else {
							 break;
						 }
					 }
				}
			}
		}
}
private static void getifstatement(ASTNode cuu, List<IfStatement> ifStatements) {
	cuu.accept(new ASTVisitor() {
		@SuppressWarnings("unchecked")
		public boolean visit(IfStatement node) {
			ifStatements.add(node);
			return false;
		}
	});
}
}
