package refactoringexample.refactoring;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.InstanceofExpression;
import org.eclipse.jdt.core.dom.MarkerAnnotation;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.PrefixExpression;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

import refactoringexample.view.RefactoringAddressRecord;
public class AnalyseInstanceof {
 public static	List<RefactoringAddressRecord> PoisoneList=new ArrayList<RefactoringAddressRecord>();
public void AnalyseRefactoring(MethodDeclaration m,List<IfStatement> list, AST ast,TypeDeclaration types) {
	for (IfStatement ifTemp : list) {
		if(ifTemp.getExpression() instanceof InstanceofExpression) {
			InstanceofExpression instanceofExpression=(InstanceofExpression)ifTemp.getExpression();
			Statement statement = ifTemp.getThenStatement();
			if (statement instanceof Block) {
			       Block block=(Block)statement;
			       if(instanceofExpression.getPatternVariable()!=null) {
			    	   SingleVariableDeclaration svd=instanceofExpression.getPatternVariable();
			    	   String nameString=svd.getName().toString();
			    		  Block mBlock=m.getBody();
			    		 for(int i=0;i<mBlock.statements().size();i++) {
			    			 if(mBlock.statements().get(i).toString().equals(ifTemp.toString())) {
			    				for(int j=i+1;j<mBlock.statements().size();j++) {
//			    					System.out.println(mBlock.statements().get(j));
			    					if(mBlock.statements().get(j) instanceof IfStatement) {
			    						IfStatement mIfStatement=(IfStatement)mBlock.statements().get(j);
			    						if(mIfStatement.getExpression() instanceof InstanceofExpression) {
			    							InstanceofExpression mInstanceofExpression=(InstanceofExpression)mIfStatement.getExpression();
			    							if(mInstanceofExpression.getPatternVariable()!=null
			    								&&mInstanceofExpression.getPatternVariable().toString().equals(svd.toString())) {
			    								 String expressionString=mInstanceofExpression.toString();
			    								if(!mInstanceofExpression.toString().contains("replace")) {
			    								 SingleVariableDeclaration msvd=mInstanceofExpression.getPatternVariable();
			    								 String msvdnameString=msvd.getName().toString();
			    								 Statement mStatement=(Statement)mIfStatement.getThenStatement();
			    								 if(mStatement instanceof Block) {
			    									Block elseBlock=(Block)mStatement;
			    									msvd.setName(ast.newSimpleName("replace123456"));
			    									for(int k=0;k<elseBlock.statements().size();k++) {
			    										if(elseBlock.statements().get(k) instanceof IfStatement) {
			    											IfStatement intoIfStatement=(IfStatement)elseBlock.statements().get(k);
			    											if(intoIfStatement.getExpression().toString().contains(msvdnameString)) {
			    												if(intoIfStatement.getExpression() instanceof InfixExpression) {
			    													InfixExpression infixExpression=(InfixExpression)intoIfStatement.getExpression();
			    													if(infixExpression.getLeftOperand().toString().contains(msvdnameString)) {
			    					    	        					Expression leftExpression=infixExpression.getLeftOperand();
			    					    	        					if(leftExpression instanceof QualifiedName) {
			    					    	        						QualifiedName qName=(QualifiedName)leftExpression;
			    					    	        						if(qName.getQualifier().toString().equals(msvdnameString)) {
			    					    	        							qName.setQualifier(ast.newSimpleName("replace123456"));
			    					    	        						}
			    					    	        					}else if(leftExpression instanceof PrefixExpression) {
			    					    	        						PrefixExpression prefixExpression=(PrefixExpression)leftExpression;
			    					    	        						Expression pExpression=prefixExpression.getOperand();
			    					    	        						if(pExpression instanceof QualifiedName) {
			    					    	        							QualifiedName qName=(QualifiedName)pExpression;
			    					    	        							if(qName.getQualifier().toString().equals(msvdnameString)) {
			    					    	        							qName.setQualifier(ast.newSimpleName("replace123456"));
			    					    	        							}
			    					    	        						}
			    					    	        					}
			    													}
			    													if(infixExpression.getRightOperand().toString().contains(msvdnameString)) {
			    				    	        						Expression rightExpression=infixExpression.getRightOperand();
			    				    	        						if(rightExpression instanceof PrefixExpression) {
			    				    	        						  PrefixExpression prefixExpression=(PrefixExpression)rightExpression;
			    				    	        						  Expression pExpression=prefixExpression.getOperand();
			    				    	        						  if(pExpression instanceof QualifiedName) {
			    				    	        							  QualifiedName qName=(QualifiedName)pExpression;
			    				    	        							  if(qName.getQualifier().toString().equals(msvdnameString)) {
			    				    	        								  qName.setQualifier(ast.newSimpleName("replace123456"));
			    				    	        							  }
			    				    	        						  }
			    				    	        						}else if(rightExpression instanceof MethodInvocation) {
			    				    	        							MethodInvocation methodInvocation=(MethodInvocation)rightExpression;
			    				    	        							if(methodInvocation.getExpression().toString().contains(msvdnameString)) {
			    				    	        								if(methodInvocation.getExpression().toString().equals(msvdnameString)) {
			    				    	        									methodInvocation.setExpression(ast.newSimpleName("replace123456"));
			    				    	        								}
			    				    	        							}
			    				    	        						}
			    				    	        					}
			    												
			    											}else if(intoIfStatement.getExpression() instanceof QualifiedName) {
			    			    	        					QualifiedName qName=(QualifiedName)intoIfStatement.getExpression();
			    			    	        					if(qName.getQualifier().toString().equals(msvdnameString)) {
			    			    	        					qName.setQualifier(ast.newSimpleName("replace123456"));}
			    			    	        			}else if(intoIfStatement.getExpression() instanceof MethodInvocation) {
			    			    	        					MethodInvocation methodInvocation=(MethodInvocation)intoIfStatement.getExpression();
			    			    	        					if(methodInvocation.getExpression().toString().contains(msvdnameString)) {
			    			    	        					   	if(methodInvocation.getExpression().toString().equals(msvdnameString)) {
			    			    	        					   		methodInvocation.setExpression(ast.newSimpleName("replace123456"));
			    			    	        					   	}else if(methodInvocation.getExpression() instanceof MethodInvocation) {
			    			    	        					   		  MethodInvocation intoInvocation=(MethodInvocation)methodInvocation.getExpression();
			    			    	        					   		  if(intoInvocation.getExpression().toString().contains(msvdnameString)) {
			    			    	        					   			  if(intoInvocation.getExpression().toString().equals(msvdnameString)) {
			    			    	        					   				  intoInvocation.setExpression(ast.newSimpleName("replace123456"));
			    			    	        					   			  }
			    			    	        					   		  }
			    			    	        					   	}
			    			    	        					}
			    			    	        					
			    			    	        					
			    			    	        					
			    			    	        					
			    			    	        					
			    			    	        				}
			    			    	        			}
			    											Statement intoStatement=(Statement)intoIfStatement.getThenStatement();
			    											Block intoBlock=(Block)intoStatement;
			    											for(int b=0;b<intoBlock.statements().size();b++) {
			    												if(intoBlock.statements().get(b).toString().contains(msvdnameString)) {
			    													if(intoBlock.statements().get(b) instanceof ExpressionStatement) {
			    														ExpressionStatement expressionStatement=(ExpressionStatement)intoBlock.statements().get(b);
			    				    	        						Expression expression=expressionStatement.getExpression();
			    				    	        						if(expression instanceof MethodInvocation) {
			    				    	        							MethodInvocation methodInvocation=(MethodInvocation)expression;
			    				    	        							   if(methodInvocation.arguments().toString().contains(msvdnameString)) {
			    				    	        								   List listm=methodInvocation.arguments();
			    					    	        						    	for(int l=0;l<listm.size();l++) {
			    					    	        						    		if(listm.get(l).toString().contains(msvdnameString)) {
			    					    	        						    			if(listm.get(l)instanceof InfixExpression) {
			    					    	        						    				InfixExpression infixExpression=(InfixExpression)listm.get(l);
			    					    	        						    				if(infixExpression.getLeftOperand().toString().contains(msvdnameString)) {
			    					    	        						    					Expression leftExpression=infixExpression.getLeftOperand();
			    					    	        						    					if(leftExpression instanceof QualifiedName) {
			    					    	        						    						QualifiedName qName=(QualifiedName)leftExpression;
			    					    	        						    						if(qName.getQualifier().toString().equals(msvdnameString)) {
			    					    	        						    						qName.setQualifier(ast.newSimpleName("replace123456"));
			    					    	        						    						}
			    					    	        						    					}
			    					    	        						    				}
			    					    	        						    			}
			    					    	        						    		}
			    					    	        						    	}
			    				    	        							   }else if(methodInvocation.getExpression().toString().contains(msvdnameString)) {	
			    					    	        						    	if(methodInvocation.getExpression().toString().equals(msvdnameString)) {
			    					    	        						    		methodInvocation.setExpression(ast.newSimpleName("replace123456"));
			    					    	        						    	}
			    					    	        						    }
			    				    	        						}else if(intoBlock.statements().get(b) instanceof ReturnStatement) {
			    					    	        						ReturnStatement returnStatement=(ReturnStatement)intoBlock.statements().get(b);
			    					    	        						if(returnStatement.getExpression().toString().contains(msvdnameString)) {
			    					    	        							if(returnStatement.getExpression().toString().equals(msvdnameString)) {
			    					    	        								returnStatement.setExpression(ast.newSimpleName("replace123456"));
			    					    	        							}
			    					    	        						}
			    					    	        					}
			    													}
			    												}
			    											}
			    										} else if(elseBlock.statements().get(k).toString().contains(msvdnameString)
			    				    	        				&&!(elseBlock.statements().get(k) instanceof IfStatement)) {
			    											 if(elseBlock.statements().get(k) instanceof ExpressionStatement) {
			    												  ExpressionStatement expressionStatement=(ExpressionStatement)elseBlock.statements().get(k);
			    												  Expression expression=expressionStatement.getExpression();
			    												  if(expression instanceof MethodInvocation) {
			    													  MethodInvocation methodInvocation=(MethodInvocation)expression;
			    													  if(methodInvocation.arguments().toString().contains(msvdnameString)) {
			    														 List listm=methodInvocation.arguments();
			    														 for(int l=0;l<listm.size();l++) {
			    															 if(listm.get(l).toString().contains(msvdnameString)) {
			    																 if(listm.get(l) instanceof MethodInvocation) {
			    																	MethodInvocation intoInvocation=(MethodInvocation)listm.get(l);
			    															         if(intoInvocation.getExpression().toString().equals(msvdnameString)) {
			    															        	 intoInvocation.setExpression(ast.newSimpleName("replace123456"));
			    															         }
			    																	}
			    															 }
			    														 }
			    													 }else if(methodInvocation.getExpression().toString().equals(msvdnameString)) {
			    														 methodInvocation.setExpression(ast.newSimpleName("replace123456"));
			    													 }
			    										}else if(expression instanceof Assignment) {
															   Assignment assignment=(Assignment)expression;
															   if(assignment.getRightHandSide().toString().contains(msvdnameString)) {
															   if(assignment.getRightHandSide().toString().equals(msvdnameString)) {
																  assignment.setRightHandSide(ast.newSimpleName("replace123456"));
															   }else if(assignment.getRightHandSide() instanceof MethodInvocation) {
																   MethodInvocation methodInvocation=(MethodInvocation)assignment.getRightHandSide();
																   if(methodInvocation.getExpression().toString().contains(msvdnameString)) {
																	   if(methodInvocation.getExpression().toString().equals(msvdnameString)) {
																		   methodInvocation.setExpression(ast.newSimpleName("replace123456"));
																	   }
																   }
															   }
															   }
														  }
													  }else if(elseBlock.statements().get(k) instanceof VariableDeclarationStatement) {
														  VariableDeclarationStatement vdstatement = (VariableDeclarationStatement) elseBlock.statements().get(k);								
														  VariableDeclaration vDeclarationExpression = (VariableDeclaration) (vdstatement.fragments().get(0));
														  Expression expression=vDeclarationExpression.getInitializer();
														  if(expression instanceof ClassInstanceCreation) {
															  ClassInstanceCreation classInstanceCreation=(ClassInstanceCreation)expression;
															  if(classInstanceCreation.arguments().toString().contains(msvdnameString)) {
																  List listm=classInstanceCreation.arguments();
																  for(int l=0;l<listm.size();l++) {
																	  if(listm.get(l).toString().contains(msvdnameString)) {
																		  if(listm.get(l).toString().equals(msvdnameString)) {
																			  listm.remove(l);
																			  listm.add(l,ast.newSimpleName("replace123456"));
																		  }else if(listm.get(l) instanceof MethodInvocation) {
																			  MethodInvocation methodInvocation=(MethodInvocation)listm.get(l);
																			  if(methodInvocation.getExpression().toString().equals(msvdnameString)) {
																				  methodInvocation.setExpression(ast.newSimpleName("replace123465"));
																			  }
																		  }
																	  }
																  }
															  }
														  }else if(expression instanceof MethodInvocation) {
															  MethodInvocation methodInvocation=(MethodInvocation)expression;
															  if(methodInvocation.getExpression().toString().equals(msvdnameString)) {
																  methodInvocation.setExpression(ast.newSimpleName("replace123456"));
															  }
														  }
													  }
													  }
			    										}
//			    									 MarkerAnnotation ma=ast.newMarkerAnnotation();
//			    				    	    	     ma.setTypeName(ast.newSimpleName("inscope"));
//			    					    	    	 ExpressionStatement maExpression=ast.newExpressionStatement(ma);
//			    					    	    	 List elseList =elseBlock.statements();
//			    					    		     elseList.add(0,maExpression);
			    					    		     SimpleName tname=types.getName();
			    							    	 String tString=tname.toString();
			    							    	 SimpleName mname=m.getName();
			    							    	 String mString=mname.toString();
			    							    	 String elementString=AnnotationRefactoring.elementString;
//			    					    		     RefactoringAddressRecord rAddressRecord=new RefactoringAddressRecord(elementString,tString,mString,expressionString);
//			    					    		     PoisoneList.add(rAddressRecord);
			    					    		     continue;
			    									}
			    								}
			    							}
			    						}
			    					}
			    						
			    					}
			    				}
			    			 }
			    		 }
			    	   }
			    	   }
	
			}
	}
}

