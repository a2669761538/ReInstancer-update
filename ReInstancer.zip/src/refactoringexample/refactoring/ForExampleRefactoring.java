package refactoringexample.refactoring;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ArrayAccess;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CastExpression;
import org.eclipse.jdt.core.dom.ContinueStatement;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InstanceofExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.ThrowStatement;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.VariableDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

public class ForExampleRefactoring {
  public static void forExample(MethodDeclaration m,int i,AST ast) {

		ForStatement Fs=(ForStatement)m.getBody().statements().get(i);
		org.eclipse.jdt.core.dom.Statement statement=Fs.getBody();
//		System.out.println(Fs);
		  Block block=(Block)statement;
		for(int k=0;k<block.statements().size();k++) {
			if(block.statements().get(k).toString().contains("if")&&block.statements().get(k)instanceof IfStatement) {
				IfStatement Is=(IfStatement)block.statements().get(k);
				if(Is.getExpression() instanceof InstanceofExpression) {
			    InstanceofExpression ioExpression=(InstanceofExpression)Is.getExpression();
			if(ioExpression.getRightOperand().toString()!=null&&ioExpression.getLeftOperand().toString()!=null) {
				String ST=ioExpression.getRightOperand().toString();
				String ST2=ioExpression.getLeftOperand().toString();
				Expression sTlExpression=ioExpression.getLeftOperand();
				InstanceofExpression IOE0=ast.newInstanceofExpression();
				SingleVariableDeclaration svd = ast.newSingleVariableDeclaration();
//				if(ioExpression.getLeftOperand() instanceof ArrayAccess) {
//					IOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast, sTlExpression));
//				}
//				else {
//				IOE0.setLeftOperand(ast.newName(ioExpression.getLeftOperand().toString())); 
//				}
				IOE0.setPatternVariable(svd);
				org.eclipse.jdt.core.dom.Statement Fstatement=Is.getThenStatement();
				
//				System.out.println(Fstatement instanceof ExpressionStatement);
				
				if(!(Fstatement instanceof ExpressionStatement)&&!(Fstatement instanceof ReturnStatement)&&!(Fstatement instanceof ContinueStatement)&&!(Fstatement instanceof ThrowStatement)) {
			    Block Forblock=(Block)Fstatement;
				Assignment as=ast.newAssignment();
				for(int T=0;T<Forblock.statements().size();T++) {
				if(Forblock.statements().get(T).toString().contains("("+ST+")")&&Forblock.statements().get(T)instanceof VariableDeclarationStatement&&!Forblock.statements().get(T).toString().contains("new")&&!Forblock.statements().get(T).toString().contains("("+"("+ST+")")) {
					VariableDeclarationStatement vdstatement=(VariableDeclarationStatement)Forblock.statements().get(T);
					VariableDeclaration vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
					CastExpression castExpression=(CastExpression)vDeclarationExpression.getInitializer();
				    String tempName = vDeclarationExpression.getName().toString();
				    String type3=castExpression.getExpression().toString();
	                Type type4=castExpression.getType();
	                if(type4.isArrayType()) {
	                	Type type2=(Type)ASTNode.copySubtree(ast, type4);
	                	svd.setType(type2);
	                }else {
	                	Type type2 = ast.newSimpleType(ast.newName(ST));
                     	svd.setType(type2);
	                }
	                
	                 //װ��instanceof ���   
	                IOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast, sTlExpression));
//	                IOE0.setLeftOperand(ast.newName(ioExpression.getLeftOperand().toString()));
	                svd.setName(ast.newSimpleName(tempName));
                 	Is.setExpression((Expression)IOE0);	
                 	Forblock.statements().remove(T);
//                 	System.out.println("for variable num"+T);
				}else if(Forblock.statements().get(T).toString().contains("("+ST+")")&&Forblock.statements().get(T)instanceof ExpressionStatement&&!Forblock.statements().get(T).toString().contains("new")&&!Forblock.statements().get(T).toString().contains("("+"("+ST+")")) {
					Assignment fas=ast.newAssignment();
					ExpressionStatement expressionStatement=(ExpressionStatement)Forblock.statements().get(T);
					Expression expression=expressionStatement.getExpression();
					if(!(expression instanceof MethodInvocation)) {
			        fas=(Assignment)expression;
//			        System.out.println(fas);
			        if(fas.getLeftHandSide()!=null&&!(fas.getLeftHandSide() instanceof QualifiedName)) {
					Expression asEleftExpression=fas.getLeftHandSide();
				    String lString=asEleftExpression.toString();
				    Expression asErightExpression=fas.getRightHandSide();
					String rString=asErightExpression.toString();
					Type type=ioExpression.getRightOperand();
					if(type.isArrayType()) {
						Type type2=(Type)ASTNode.copySubtree(ast, type);
						svd.setType(type2);
					}else {
						Type type2 = ast.newSimpleType(ast.newName(ST));
						svd.setType(type2);
					}
					
				//װ��instanceof���
					IOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast,sTlExpression));
//			        IOE0.setLeftOperand(ast.newName(ioExpression.getLeftOperand().toString()));
					
					
//					svd.setName(ast.newSimpleName(lString));
					if(asEleftExpression instanceof ArrayAccess) {
//						svd.setName( (SimpleName) ASTNode.copySubtree(ast, asEleftExpression));
//						svd.setName( ast.newSimpleName("hello"));
				        ArrayAccess access=(ArrayAccess)asEleftExpression;
				        Expression aExpression=access.getArray();
				        Expression aExpressionindex=access.getIndex();
//				        System.out.println(aExpression);
//					    System.out.println(aExpressionindex);
//					    SimpleName aName=(SimpleName)asEleftExpression;   ����ǿת
//					    SimpleName aName=(SimpleName)ASTNode.copySubtree(ast, asEleftExpression);  ����ǿת
//					    SimpleName aSimpleName=(SimpleName) ASTNode.copySubtree(ast, asEleftExpression);
//					    svd.setName( aSimpleName);
					    
									        
					}else {
						svd.setName(ast.newSimpleName(lString));
					}
//					svd.setName((SimpleName) ASTNode.copySubtree(ast, asEleftExpression));
					Is.setExpression(IOE0);
                  Forblock.statements().remove(T);
//                  System.out.println("for expression num"+T);
					}
				}
				}	
			}
			}
			}
			//��forѭ����else if�����ع�
			if(Is.getElseStatement()!=null&&Is.getElseStatement() instanceof IfStatement) {
				IfStatement foreIfStatement=(IfStatement)Is.getElseStatement();
				 while(foreIfStatement instanceof IfStatement) {
					 if(foreIfStatement.getExpression() instanceof InstanceofExpression) {
						InstanceofExpression forExpression=(InstanceofExpression)foreIfStatement.getExpression();
						if(forExpression.getLeftOperand().toString()!=null&&forExpression.getRightOperand().toString()!=null) {
							String forleftString=forExpression.getLeftOperand().toString();
							String forrightString=forExpression.getRightOperand().toString();
							InstanceofExpression forInstanceofExpression=ast.newInstanceofExpression();
							SingleVariableDeclaration fordeclaration = ast.newSingleVariableDeclaration();
//							System.out.println(forInstanceofExpression.getLeftOperand() instanceof ArrayAccess); 
//							if(forInstanceofExpression.getLeftOperand() instanceof ArrayAccess) {
//								
//							}else {
//							forInstanceofExpression.setLeftOperand(ast.newName(forExpression.getLeftOperand().toString()));
//							}
							Expression forleftExpression=forExpression.getLeftOperand();
//							forInstanceofExpression.setLeftOperand(ast.newName(forExpression.getLeftOperand().toString()));
							forInstanceofExpression.setPatternVariable(fordeclaration);
							org.eclipse.jdt.core.dom.Statement forstatement=foreIfStatement.getThenStatement(); 
							if(!(forstatement instanceof ExpressionStatement)&&!(forstatement instanceof ContinueStatement)&&!(forstatement instanceof ReturnStatement)&&!(forstatement instanceof ThrowStatement)) {
							Block forblock=(Block)forstatement;
							for(int f=0;f<forblock.statements().size();f++) {
								if(forblock.statements().get(f).toString().contains("(" + forrightString+")")&&forblock.statements().get(f)instanceof VariableDeclarationStatement&&!forblock.statements().get(f).toString().contains("("+"("+forrightString+")")&&!forblock.statements().get(f).toString().contains("new")) {
									VariableDeclarationStatement vdstatement=(VariableDeclarationStatement)forblock.statements().get(f);
				                   	VariableDeclaration vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
				                   	String tempName = vDeclarationExpression.getName().toString();
				                    CastExpression castExpression=(CastExpression)vDeclarationExpression.getInitializer();
				                    String type3=castExpression.getType().toString();
				                    Type type4=castExpression.getType();
				                    if(type4.isArrayType()) {
				                    	Type type2=(Type)ASTNode.copySubtree(ast, type4);
				                    	fordeclaration.setType(type2);
				                    }else {
				                    	Type type2 = ast.newSimpleType(ast.newName(forrightString));
				                        fordeclaration.setType(type2);
				                    }
				                    
				                    forInstanceofExpression.setLeftOperand((Expression) ASTNode.copySubtree(ast, forleftExpression));
//			                        forInstanceofExpression.setLeftOperand(ast.newName(forExpression.getLeftOperand().toString()));
			                        fordeclaration.setName(ast.newSimpleName(tempName));
			                        foreIfStatement.setExpression(forInstanceofExpression);
			                        forblock.statements().remove(f);
//			                        System.out.println("for else variable num"+f);
									
									
						}else if(forblock.statements().get(f).toString().contains("(" + forrightString+")")&&forblock.statements().get(f)instanceof ExpressionStatement&&!forblock.statements().get(f).toString().contains("("+"("+forrightString+")")&&!forblock.statements().get(f).toString().contains("new")) {
							Assignment fas=ast.newAssignment();
							ExpressionStatement expressionStatement=(ExpressionStatement)forblock.statements().get(f);
							Expression expression=expressionStatement.getExpression();
							if(!(expression instanceof MethodInvocation)) {
					        fas=(Assignment)expression;
					        if(fas.getLeftHandSide()!=null&&!(fas.getLeftHandSide() instanceof QualifiedName)) {
							Expression asEleftExpression=fas.getLeftHandSide();
							String lString=asEleftExpression.toString();
							Expression asErightExpression=fas.getRightHandSide();
							String rString=asErightExpression.toString();
							Type type=forExpression.getRightOperand();
							if(type.isArrayType()) {
								Type type2=(Type)ASTNode.copySubtree(ast, type);
								fordeclaration.setType(type2);
							}else {
								Type type2 = ast.newSimpleType(ast.newName(forrightString));
								fordeclaration.setType(type2);
							}
							forInstanceofExpression.setLeftOperand((Expression) ASTNode.copySubtree(ast, forleftExpression));
//							forInstanceofExpression.setLeftOperand(ast.newName(forExpression.getLeftOperand().toString()));
							fordeclaration.setName(ast.newSimpleName(lString));
							foreIfStatement.setExpression(forInstanceofExpression);	
		                    forblock.statements().remove(f);
//		                    System.out.println("for else expression num"+f);
						}
					 }
						}
							}
							}
						
						}
					 
					 }
					 if(foreIfStatement.getElseStatement() instanceof IfStatement) {
						 foreIfStatement=(IfStatement) foreIfStatement.getElseStatement();
					 }else {
						 break;
					 }
//					 foreIfStatement=(IfStatement) foreIfStatement.getElseStatement();
					 
				 }
				
			}
			}
			}
		}
		    
		    
	    
	
  }
}
