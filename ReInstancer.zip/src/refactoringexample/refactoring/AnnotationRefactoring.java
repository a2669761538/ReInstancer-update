package refactoringexample.refactoring;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.ArrayAccess;
import org.eclipse.jdt.core.dom.CastExpression;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.FieldAccess;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.InstanceofExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.ParenthesizedExpression;
import org.eclipse.jdt.core.dom.PrefixExpression;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SuperMethodInvocation;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jface.text.Document;
import org.eclipse.ltk.core.refactoring.Change;
import org.eclipse.ltk.core.refactoring.CompositeChange;
import org.eclipse.ltk.core.refactoring.Refactoring;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;
import org.eclipse.ltk.core.refactoring.TextFileChange;
import org.eclipse.text.edits.TextEdit;

import com.ibm.wala.ipa.callgraph.CallGraph;
import com.ibm.wala.ipa.callgraph.CallGraphBuilderCancelException;
import com.ibm.wala.ipa.cha.ClassHierarchy;
import com.ibm.wala.ipa.cha.ClassHierarchyException;
import com.ibm.wala.ipa.slicer.Statement;
import com.ibm.wala.util.graph.Graph;

import refactoringexample.analysis.MakeCallGraph;
import refactoringexample.analysis.PatternAnalysis;
import refactoringexample.view.RefactoringAliasView;
import refactoringexample.view.RefactoringDominationView;
import refactoringexample.view.RefactoringPoisoneView;
import refactoringexample.view.RefactoringScopeView;

public class AnnotationRefactoring extends Refactoring {

	public static IPath filename = null;
	public static CallGraph cg = null;
	public static ClassHierarchy cha = null;
	public static Graph<Statement> sdg = null;
	public static MakeCallGraph mcg = null;
	public static ClassHierarchyAnalysisForInstance chaforinstance = null;
    public static PatternAnalysis patternAnalysis=null;
	public static int sumTemp = 0;
	public static int castemp = 0;
	public static int codeTemp = 0;
	public static int nametemp = 0;
	public static int refactorTemp = 0;
	private static final Object PrimitiveType = null;
	public static String elementString = null;
	public static ASTRewrite rewrite;
	private IJavaElement element;
	// List<Change> changeManager = new ArrayList<Change>();
	List<Change> changeManager = new ArrayList<Change>();
	// private TextChangeManager changeManager;
	private List<ICompilationUnit> compilationUnits;

	public AnnotationRefactoring(IJavaElement select) {
		element = select;
		filename = select.getJavaProject().getProject().getLocation();
		// changeManager = new TextChangeManager();
		compilationUnits = findAllCompilationUnits(element);
	}

	@Override
	public RefactoringStatus checkFinalConditions(IProgressMonitor arg0)
			throws CoreException, OperationCanceledException {
		collectChanges();
		// update
//		RefactoringAliasView.updateTableViewer();
//		RefactoringScopeView.updateTableViewer();
//		RefactoringPoisoneView.updateTableViewer();
		RefactoringDominationView.updateTableViewer();

		if (changeManager.size() == 0)
			return RefactoringStatus.createFatalErrorStatus("No  found!");
		else {
//			System.out.println( "模式匹配：" + sumTemp);
			System.out.println("重构的instanceof的数量" + refactorTemp);
//			System.out.println("real模式匹配："+castemp);
			System.out.println("代码缩减：" + codeTemp);
			System.out.println("给出模式变量：" + nametemp);
			return RefactoringStatus.createInfoStatus("Final condition has been checked");
		}

	}

	@Override
	public RefactoringStatus checkInitialConditions(IProgressMonitor arg0)
			throws CoreException, OperationCanceledException {
		return RefactoringStatus.createInfoStatus("Initial Condition is OK!");
	}

	@Override
	public Change createChange(IProgressMonitor arg0) throws CoreException, OperationCanceledException {
		Change[] changes = new Change[changeManager.size()];
		// TextChange[] changes = changeManager.getAllChanges();
		System.arraycopy(changeManager.toArray(), 0, changes, 0, changeManager.size());
		CompositeChange change = new CompositeChange(element.getJavaProject().getElementName(), changes);
		return change;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Add @Test annotation";
	}

	private void collectChanges() throws JavaModelException {
		int sumInstance = 0;
		int sumnegateInstance = 0;
		int nompsum = 0;
		int instanceofsum = 0;
		int ifparentsum = 0;
		for (IJavaElement element : compilationUnits) {
			elementString = element.getPath().toString();
//			System.out.println(element);
			// 创建一个document(jface)
			ICompilationUnit cu = (ICompilationUnit) element;
			String source = cu.getSource();
			Document document = new Document(source);
			// 创建AST
			ASTParser parser = ASTParser.newParser(AST.JLS14);
			parser.setSource(cu);
			CompilationUnit astRoot = (CompilationUnit) parser.createAST(null);

			rewrite = ASTRewrite.create(astRoot.getAST());
			// 记录更改
			astRoot.recordModifications();
			List<TypeDeclaration> types = new ArrayList<TypeDeclaration>();
			getTypes(astRoot.getRoot(), types);
			List<IfStatement> list = new ArrayList<IfStatement>();
			getIf(astRoot.getRoot(), list);
			for (IfStatement ifTemp : list) {
				if (ifTemp.getExpression() instanceof InstanceofExpression) {
					InstanceofExpression instanceofExpression = (InstanceofExpression) ifTemp.getExpression();
//					System.out.println(ifTemp);
					sumInstance++;
					String lString = instanceofExpression.getLeftOperand().toString();
					String rString = instanceofExpression.getRightOperand().toString();
//					System.out.println(ifTemp);
					if (!ifTemp.toString().contains("(" + rString + ")" + lString)) {
						nompsum++;
					}
				}
			}

			for (IfStatement ifTemp : list) {
				if (ifTemp.getExpression() instanceof PrefixExpression
						&& !(ifTemp.getExpression() instanceof InfixExpression)) {
					PrefixExpression prefixExpression = (PrefixExpression) ifTemp.getExpression();
					Expression pfExpression = prefixExpression.getOperand();
					if (pfExpression instanceof ParenthesizedExpression) {
						ParenthesizedExpression parenthesizedExpression = (ParenthesizedExpression) pfExpression;
						Expression pthExpression = parenthesizedExpression.getExpression();
						if (pthExpression instanceof InstanceofExpression) {
							InstanceofExpression instanceofExpression = (InstanceofExpression) pthExpression;
							sumnegateInstance++;
							String lString = instanceofExpression.getLeftOperand().toString();
							String rString = instanceofExpression.getRightOperand().toString();
							if (!ifTemp.toString().contains("(" + rString + ")" + lString)) {
								nompsum++;
							}
						}
					}
				}

			}

			List<InstanceofExpression> inlist = new ArrayList<InstanceofExpression>();
			getInstanceof(astRoot, inlist);
			for (InstanceofExpression instanceoftemp : inlist) {
				instanceofsum++;
//				if(instanceoftemp.getParent() instanceof IfStatement) {
//					ifparentsum++;
//				}
//				if(instanceoftemp.getParent() instanceof InfixExpression) {
//					ifparentsum++;
//				}

			}

			for (TypeDeclaration ty : types) {
				collectChanges(astRoot, ty, element);
			}

//			TextEdit edits = rewrite.rewriteAST(document, cu.getJavaProject().getOptions(true));
			TextEdit edits = astRoot.rewrite(document, cu.getJavaProject().getOptions(true));
			TextFileChange change = new TextFileChange("", (IFile) cu.getResource());
			change.setEdit(edits);

			changeManager.add(change);

		}
		System.out.println("instanceof全部" + instanceofsum);
//		System.out.println("instanceof parent"+ifparentsum);
//		System.out.println("Instance数量：" +sumInstance);
//		System.out.println("!Instanceof数量"+sumnegateInstance);
		int sum = 0;
		sum = sumInstance + sumnegateInstance;
//		System.out.println("总数量:"+sum);
//		System.out.println("无法重构的数量："+nompsum);
	}

	private void collectChanges(ICompilationUnit cu) throws JavaModelException {
		// create a document
		String source = "";
		try {
			source = cu.getSource();
		} catch (JavaModelException e) {
			e.printStackTrace();
		}
		Document document = new Document(source);

		// creation of DOM/AST from a ICompilationUnit
		ASTParser parser = ASTParser.newParser(AST.JLS14);
		parser.setSource(cu);
		parser.setResolveBindings(true);
		CompilationUnit astRoot = (CompilationUnit) parser.createAST(null);

		// creation of ASTRewrite
		final ASTRewrite rewrite = ASTRewrite.create(astRoot.getAST());
		astRoot.recordModifications();
		List<TypeDeclaration> types = new ArrayList<TypeDeclaration>();
		getTypes(astRoot.getRoot(), types);
		for (TypeDeclaration ty : types) {
			collectChanges(astRoot, ty, element);
		}

//		TextEdit edits = astRoot.rewrite(document, cu.getJavaProject().getOptions(true));
//		TextFileChange change = new TextFileChange("", (IFile) cu.getResource());
//		change.setEdit(edits);
//		changeManager.add(change);

		TextEdit edits = rewrite.rewriteAST(document, cu.getJavaProject().getOptions(true));
		TextFileChange change = new TextFileChange("", (IFile) cu.getResource());
		change.setEdit(edits);
		// changeManager.manage(cu, change);
	}

	private void getTypes(ASTNode cuu, final List types) {
		cuu.accept(new ASTVisitor() {
			@SuppressWarnings("unchecked")
			public boolean visit(TypeDeclaration node) {
				types.add(node);
				return true;
			}
		});
	}

	private void getIf(ASTNode cuu, List<IfStatement> types) {
		cuu.accept(new ASTVisitor() {
			@SuppressWarnings("unchecked")
			public boolean visit(IfStatement node) {
				types.add(node);
				return true;
			}
		});
	}

	private void getInstanceof(ASTNode cuu, List<InstanceofExpression> types) {
		cuu.accept(new ASTVisitor() {
			@SuppressWarnings("unchecked")
			public boolean visit(InstanceofExpression node) {
				types.add(node);
				return true;
			}
		});
	}

	private void getEquals(ASTNode cuu, final List types) {
		cuu.accept(new ASTVisitor() {
			@SuppressWarnings("unchecked")
			public boolean visit(MethodDeclaration node) {
				types.add(node);
				return true;
			}
		});
	}

	private boolean collectChanges(CompilationUnit root, TypeDeclaration types, IJavaElement element)
			throws IllegalArgumentException {
		AST ast = types.getAST();
		// 获取类中所有方法
//		FieldDeclaration[] fields = types.getFields();
		MethodDeclaration[] methods = types.getMethods();
//		System.out.println(methods);
		for (int j = 0; j < methods.length; j++) {
			MethodDeclaration m = methods[j];
			if (m.getBody() != null && !methods[j].getName().getFullyQualifiedName().startsWith("equals")) {
//				System.out.println(element.getPath().toString());
				chaforinstance.BranchInstance(element.getPath().toString(), m, root, element);
				patternAnalysis.patternAnalysis(element.getPath().toString(), m, root, element);
				List<IfStatement> list = new ArrayList<IfStatement>();
				getIf(m, list);
				SolveInstanceofRefactoring refactoring = new SolveInstanceofRefactoring();
				refactoring.instanceofRefactoring(types, m, list, ast);

				mergeif mergeif=new mergeif();
				mergeif.mergeifRefactoring(types, m, list, ast);				
				InstanceofTransformSwitchNull instanceofTransformSwitchNull = new InstanceofTransformSwitchNull();
				instanceofTransformSwitchNull.InstanceofTransformNull(types, m, list, ast);
				InstanceofTransformSwitch instanceofTransformSwitch = new InstanceofTransformSwitch();
				instanceofTransformSwitch.instanceoftoswitch(types, m, list, ast);

				MarkRefactoring markRefactoring = new MarkRefactoring();
				markRefactoring.MackAnalyseRefactoring(m, list, ast, types);

			} 
			else if (m.getBody() != null && methods[j].getName().getFullyQualifiedName().startsWith("equals")) {
				chaforinstance.BranchInstance(element.getPath().toString(), m, root, element);
				patternAnalysis.patternAnalysis(element.getPath().toString(), m, root, element);
				EqualsExampleRefactoring refactoring = new EqualsExampleRefactoring();
				refactoring.EqualsRefactoring(m, ast);
			}
		}

		return true;
	}

	private List<ICompilationUnit> findAllCompilationUnits(IJavaElement project) {

		List<ICompilationUnit> cus = new ArrayList<ICompilationUnit>();

		try {
			mcg = new MakeCallGraph(filename);
		} catch (ClassHierarchyException | IOException | IllegalArgumentException
				| CallGraphBuilderCancelException e1) {
			e1.printStackTrace();
		}
		AnnotationRefactoring.cg = mcg.cg;
		AnnotationRefactoring.cha = mcg.cha;
		AnnotationRefactoring.sdg = mcg.sdg;
		chaforinstance = new ClassHierarchyAnalysisForInstance(cg, mcg.getCHAMap());
		patternAnalysis=new PatternAnalysis(cg);
//		PatternAnalysis patternAnalysis=new PatternAnalysis();
//		patternAnalysis.patternAnalysis(cg);

		try {
			if (project instanceof IJavaProject) {
				IJavaProject iJ = (IJavaProject) project;
				for (IJavaElement element : iJ.getChildren()) { // IPackageFragmentRoot
					IPackageFragmentRoot root = (IPackageFragmentRoot) element;
					for (IJavaElement ele : root.getChildren()) {
						if (ele instanceof IPackageFragment) {
							IPackageFragment fragment = (IPackageFragment) ele;
							for (ICompilationUnit unit : fragment.getCompilationUnits()) {
								cus.add(unit);
							}
						}
					}
				}
			} else if (project instanceof IPackageFragmentRoot) {
				IPackageFragmentRoot root = (IPackageFragmentRoot) project;
				for (IJavaElement ele : root.getChildren()) {
					if (ele instanceof IPackageFragment) {
						IPackageFragment fragment = (IPackageFragment) ele;
						for (ICompilationUnit unit : fragment.getCompilationUnits()) {
							cus.add(unit);
						}
					}
				}

			} else if (project instanceof IPackageFragment) {
				IPackageFragment fragment = (IPackageFragment) project;
				for (ICompilationUnit unit : fragment.getCompilationUnits()) {
					cus.add(unit);
				}
			} else if (project instanceof ICompilationUnit) {
				ICompilationUnit unit = (ICompilationUnit) project;
				cus.add(unit);
			}
		} catch (JavaModelException e) {
			e.printStackTrace();
		}
		return cus;
	}
}

/*
 * for(int i=0;i<m.getBody().statements().size();i++) {
 * if(m.getBody().statements().get(i) instanceof Statement) { SearchRefactoring
 * sRefactoring=new SearchRefactoring(m,i,ast); Statement
 * testStatement=(Statement)m.getBody().statements().get(i); if(testStatement
 * instanceof IfStatement) { IfStatement IS=(IfStatement)testStatement;
 * sRefactoring.searchIfstatement(IS); }else if(testStatement instanceof
 * TryStatement) { TryStatement TS=(TryStatement)testStatement;
 * sRefactoring.searchTrystatement(TS); }else if(testStatement instanceof
 * ForStatement) { ForStatement FS=(ForStatement)testStatement;
 * sRefactoring.searchForstatement(FS); }else if(testStatement instanceof Block)
 * { Block BL=(Block)testStatement; sRefactoring.searchblock(BL); }else
 * if(testStatement instanceof DoStatement) { DoStatement
 * DS=(DoStatement)testStatement; sRefactoring.searchDostatement(DS); }else
 * if(testStatement instanceof WhileStatement) { WhileStatement
 * WS=(WhileStatement)testStatement; sRefactoring.searchWhilestatement(WS);
 * 
 * }
 * 
 * }
 * 
 * }
 * 
 */

/*
 * //标准模式的重构 //for(IfStatement ifTemp : list) { //if(ifTemp.getExpression()
 * instanceof InstanceofExpression) { // InstanceofExpression
 * IOE=(InstanceofExpression)ifTemp.getExpression(); //
 * if(IOE.getLeftOperand()!=null&&IOE.getRightOperand()!=null) { // Expression
 * iOExpression=IOE.getLeftOperand(); // String
 * IOElString=IOE.getLeftOperand().toString(); // String
 * IOErString=IOE.getRightOperand().toString(); // InstanceofExpression
 * newIOE=ast.newInstanceofExpression(); // SingleVariableDeclaration
 * svd=ast.newSingleVariableDeclaration(); // newIOE.setPatternVariable(svd); //
 * Statement statement=ifTemp.getThenStatement(); // if(!(statement instanceof
 * ExpressionStatement)&&!(statement instanceof ReturnStatement)&&!(statement
 * instanceof ContinueStatement)&&!(statement instanceof
 * ThrowStatement)&&!(statement instanceof BreakStatement)&&!(statement
 * instanceof IfStatement)&&!(statement instanceof EmptyStatement)) { // Block
 * block=(Block)statement; // Assignment as=ast.newAssignment(); // for(int
 * i=0;i<block.statements().size();i++) { //
 * if(block.statements().get(i).toString().contains("("+IOErString+")")&&block.
 * statements().get(i) instanceof
 * VariableDeclarationStatement&&!block.statements().get(i).toString().contains(
 * "("+"("+IOErString+")")&&!block.statements().get(i).toString().contains("new"
 * )) { // VariableDeclarationStatement
 * vdstatement=(VariableDeclarationStatement)block.statements().get(i); //
 * VariableDeclaration
 * vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
 * // CastExpression
 * castExpression=(CastExpression)vDeclarationExpression.getInitializer(); //
 * String tempName = vDeclarationExpression.getName().toString(); // String
 * caString=castExpression.getExpression().toString(); // Type
 * ctype=castExpression.getType(); // Type type=(Type)ASTNode.copySubtree(ast,
 * ctype); // svd.setType(type); // newIOE.setLeftOperand((Expression)
 * ASTNode.copySubtree(ast, iOExpression)); //
 * svd.setName(ast.newSimpleName(tempName)); //
 * ifTemp.setExpression((Expression)newIOE); // block.statements().remove(i); //
 * System.out.println("variable"); // }else
 * if(block.statements().get(i).toString().contains("("+IOErString+")")&&block.
 * statements().get(i) instanceof
 * ExpressionStatement&&!block.statements().get(i).toString().contains("("+"("+
 * IOErString+")")&&!block.statements().get(i).toString().contains("new")) { //
 * ExpressionStatement
 * expressionStatement=(ExpressionStatement)block.statements().get(i); //
 * Expression expression=expressionStatement.getExpression(); // if(!(expression
 * instanceof MethodInvocation)) { // as=(Assignment)expression; //
 * if(as.getLeftHandSide()!=null&&!(as.getLeftHandSide() instanceof
 * QualifiedName)&&!as.getLeftHandSide().toString().contains("this.")) { //
 * Expression asEleftExpression=as.getLeftHandSide(); // String
 * lString=asEleftExpression.toString(); // Expression
 * asErightExpression=as.getRightHandSide(); // String
 * rString=asErightExpression.toString(); // Type type=IOE.getRightOperand(); //
 * Type type2=(Type)ASTNode.copySubtree(ast, type); // svd.setType(type2); //
 * newIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast,iOExpression)); //
 * if(asEleftExpression instanceof ArrayAccess) { // // // } // else { //
 * svd.setName(ast.newSimpleName(lString)); // block.statements().remove(i); //
 * } // ifTemp.setExpression((Expression)newIOE); //
 * System.out.println("Expression"); // // // } // // } // // } // } // } // }
 * //} }
 */

//递归遍历(淘汰)
//for(int i=0;i<m.getBody().statements().size();i++) {
//if(m.getBody().statements().get(i) instanceof Statement) {
//	SearchRefactoring sRefactoring=new SearchRefactoring(m,i,ast);
//	Statement testStatement=(Statement)m.getBody().statements().get(i);
//	if(testStatement instanceof IfStatement) {
//		IfStatement IS=(IfStatement)testStatement;
//		sRefactoring.searchIfstatement(IS);
//	}else if(testStatement instanceof TryStatement) {
//		TryStatement TS=(TryStatement)testStatement;
//		sRefactoring.searchTrystatement(TS);
//	}else if(testStatement instanceof ForStatement) {
//		ForStatement FS=(ForStatement)testStatement;
//		sRefactoring.searchForstatement(FS);
//	}else if(testStatement instanceof Block) {
//		Block BL=(Block)testStatement;
//		sRefactoring.searchblock(BL);
//	}else if(testStatement instanceof DoStatement) {
//		DoStatement DS=(DoStatement)testStatement;
//		sRefactoring.searchDostatement(DS);
//	}else if(testStatement instanceof WhileStatement) {
//		WhileStatement WS=(WhileStatement)testStatement;
//		sRefactoring.searchWhilestatement(WS);
//		
//	}
//
//}
//
//}

/*
 * 语法错误 else if(testStatement instanceof
 * VariableDeclarationStatement&&testStatement.toString().contains("new")) {
 * VariableDeclarationStatement
 * Vdestatement=(VariableDeclarationStatement)m.getBody().statements().get(i);
 * VariableDeclaration
 * vDeclarationExpression=(VariableDeclaration)(Vdestatement.fragments().get(0))
 * ; // System.out.println(vDeclarationExpression); Type
 * vType=Vdestatement.getType(); System.out.println(vType.getStartPosition());
 * // System.out.println(vType); String
 * vString=vDeclarationExpression.getName().toString(); //
 * System.out.println(vString); if(testStatement instanceof IfStatement) {
 * IfStatement iStatement=(IfStatement)testStatement; Expression
 * iSExpression=iStatement.getExpression(); if(iSExpression instanceof
 * InstanceofExpression) { InstanceofExpression
 * newIEO=(InstanceofExpression)iSExpression; Expression
 * newIEOL=newIEO.getLeftOperand(); String
 * stringL=newIEO.getLeftOperand().toString(); String
 * stringR=newIEO.getRightOperand().toString();
 * 
 * }
 * 
 * 
 * 
 * // sRefactoring.searchIfstatement(iStatement); } }
 */

////				System.out.println(m.getBody());
//				Block mBlock=(Block)m.getBody();
////				System.out.println(mBlock);
//				InfixExpression IE=ast.newInfixExpression();
//				ReturnStatement returnStatement=ast.newReturnStatement();
//				for(int i=0;i<mBlock.statements().size();i++) {
//					if(mBlock.statements().get(i) instanceof IfStatement) {
//						IfStatement IS=(IfStatement)m.getBody().statements().get(i);
////						System.out.println(IS);
//						if(IS.getExpression() instanceof InstanceofExpression) {
//							InstanceofExpression IOE=(InstanceofExpression)IS.getExpression();
//							if(IOE.getRightOperand()!=null&&IOE.getLeftOperand()!=null) {
//								String STL=IOE.getLeftOperand().toString();
//								String STR=IOE.getRightOperand().toString();
//								Expression iExpression=IOE.getLeftOperand();
////								System.out.println(IOE);
//								InstanceofExpression IOEnew=ast.newInstanceofExpression();
//								SingleVariableDeclaration svd = ast.newSingleVariableDeclaration();
//								IOEnew.setPatternVariable(svd);
//								Statement statement=IS.getThenStatement();
//								if(!(statement instanceof ReturnStatement)) {
//								Block block=(Block)statement;
//								for(int k=0;k<block.statements().size();k++) {
//									if(block.statements().get(k).toString().contains("("+STR+")")&&block.statements().get(k)instanceof VariableDeclarationStatement&&!block.statements().get(k).toString().contains("("+"("+STR+")")&&!block.statements().get(k).toString().contains("new")) {
//										    VariableDeclarationStatement  vdstatement=(VariableDeclarationStatement)block.statements().get(k);
//										 	VariableDeclaration vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
//										 	CastExpression castExpression=(CastExpression)vDeclarationExpression.getInitializer();
//									        String tempName = vDeclarationExpression.getName().toString();
//										    String type3=castExpression.getExpression().toString();
//					                        Type type4=castExpression.getType();
//					                        Type type=(Type) ASTNode.copySubtree(ast, type4);
//					                        svd.setType(type);
//					                        IOEnew.setLeftOperand((Expression) ASTNode.copySubtree(ast, iExpression));
//					                        svd.setName(ast.newSimpleName(tempName));
//					                        IS.setExpression((Expression)IOEnew);
//					                        block.statements().remove(k);
////					                        System.out.println(block);
//					                        //获取Return后的内容
////					                        System.out.println(IOEnew);
//					                        Expression ReIOEnew=(Expression)IOEnew;
//					                        Expression copyIOEnew=(Expression)ASTNode.copySubtree(ast, ReIOEnew);
////					                        System.out.println(ReIOEnew);
//					                        if(block.statements().get(k) instanceof ReturnStatement) {
//					                        	if(IS.getElseStatement()==null) {
//					                        		System.out.println("equals");
//					                        	ReturnStatement RS=(ReturnStatement)block.statements().get(k);
//					                        	Expression rsExpression=RS.getExpression();
//					                        	Expression rExpression=(Expression)ASTNode.copySubtree(ast, rsExpression);
////					                        	System.out.println(rExpression);
//					                        	RS.delete();
//					                        	IE.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
//					                        	IE.setLeftOperand(copyIOEnew);
//					                        	IE.setRightOperand(rExpression); 
//					                        	Expression iEeExpression=(Expression)IE;
//					                            returnStatement.setExpression(iEeExpression);
//					                            block.statements().add(returnStatement);
//					                            IS.delete();
//					                            if(mBlock.statements().get(i).toString().contains("return true")||mBlock.statements().get(i).toString().contains("return false")) {
//					                            	mBlock.statements().remove(i);
//					                            	}
//					                            ReturnStatement NewRS=(ReturnStatement)ASTNode.copySubtree(ast, returnStatement);
//				                            	Expression NewRSExpression=(Expression)IE;
//				                            	mBlock.statements().add(i,NewRS);
//					                        	}else {
////					                        		System.out.println(IS);
//					                        	}
//					                            }else if(block.statements().get(k) instanceof IfStatement) {
//					                            	IfStatement Equalsif=(IfStatement)block.statements().get(k);
//					                            	if(Equalsif.getElseStatement()==null) {
//					                            		System.out.println("equals");
//					                            	Statement thStatement=Equalsif.getThenStatement();
//					                            	Block iBlock=(Block)thStatement;
//					                            	if(iBlock.statements().toString().contains("return false")||iBlock.statements().toString().contains("return true")) {
////					                            		System.out.println("yes");
//					                            	Expression eifExpression=Equalsif.getExpression();
//					                            	Expression reifExpression=(Expression)ASTNode.copySubtree(ast,eifExpression);
//					                            	IE.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
//					                            	IE.setLeftOperand(copyIOEnew);
//					                            	IE.setRightOperand(reifExpression);
//					                            	Expression iEeExpression=(Expression)IE;
////					                            	System.out.println(iEeExpression);
//					                            	returnStatement.setExpression(iEeExpression);
//						                            block.statements().add(returnStatement);
//						                            IS.delete();
//						                            if(mBlock.statements().get(i).toString().contains("return true")||mBlock.statements().get(i).toString().contains("return false")) {
//						                            	mBlock.statements().remove(i);
//						                            	}
//						                            ReturnStatement NewRS=(ReturnStatement)ASTNode.copySubtree(ast, returnStatement);
//					                            	Expression NewRSExpression=(Expression)IE;
////					                            	System.out.println(NewRSExpression);
////					                            	System.out.println(returnStatement);
////					                            	NewRS.setExpression(NewRSExpression);
//					                            	mBlock.statements().add(NewRS);
//
//					                            	}
//					                            	else {
////					                            		System.out.println(Equalsif);
//					                            	}
//					                            	}
//					                            }
//					                        
//									}
//									
//								}
//							}
//							}
//							
//						}
//						 if(IS.getExpression().toString().contains("!"+"(")&&IS.getExpression().toString().contains("instanceof")) {
////								System.out.println(IS);
//								if(!(IS.getExpression() instanceof InfixExpression)) {
//							    PrefixExpression prefixExpression=(PrefixExpression)IS.getExpression();
////							    System.out.println(prefixExpression.getOperand());  //ParenthesizedExpression
//							    Expression pfExpression=prefixExpression.getOperand(); 
//							    ParenthesizedExpression  parenthesizedExpression=(ParenthesizedExpression)pfExpression;
//							    Expression pthExpression=parenthesizedExpression.getExpression();
////							    System.out.println(pthExpression);
//							    if(pthExpression instanceof InstanceofExpression) {
//							    	InstanceofExpression IOE=(InstanceofExpression)pthExpression;
//							    	if(IOE.getLeftOperand()!=null&&IOE.getRightOperand()!=null) {
//							    		String preIOER=IOE.getRightOperand().toString();
//							    		String preIOEL=IOE.getLeftOperand().toString();
////							    		System.out.println(preIOEL);
////							    		System.out.println(preIOER);
//							    		Expression preExpression=IOE.getLeftOperand();
//							    		InstanceofExpression IOEnew=ast.newInstanceofExpression();
//							    		SingleVariableDeclaration prosvd=ast.newSingleVariableDeclaration();
//							    		IOEnew.setPatternVariable(prosvd);
//							    		for(int k=0;k<mBlock.statements().size();k++) {
//							    			if(mBlock.statements().get(k).toString().contains("("+preIOER+")")&&mBlock.statements().get(k)instanceof VariableDeclarationStatement&&!mBlock.statements().get(k).toString().contains("("+"("+preIOER+")")&&!mBlock.statements().get(k).toString().contains("new")&&mBlock.statements().get(k+1) instanceof ReturnStatement) {
//							    				 VariableDeclarationStatement  vdstatement=(VariableDeclarationStatement)mBlock.statements().get(k);
//												 VariableDeclaration vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
//												 CastExpression castExpression=(CastExpression)vDeclarationExpression.getInitializer();
//											     String tempName = vDeclarationExpression.getName().toString();
////											     System.out.println(tempName);
//												 String type3=castExpression.getExpression().toString();
//							                     Type type4=castExpression.getType();
//							                     Type type=(Type) ASTNode.copySubtree(ast, type4);
//							                     prosvd.setType(type);
//							                     IOEnew.setLeftOperand((Expression) ASTNode.copySubtree(ast, preExpression));
//							                     prosvd.setName(ast.newSimpleName(tempName));
//							                     mBlock.statements().remove(k);
//							                     Expression ReIOEnew=(Expression)IOEnew;
//							                     Expression copyIOEnew=(Expression)ASTNode.copySubtree(ast, ReIOEnew);
//							                     ParenthesizedExpression newptExpression=ast.newParenthesizedExpression();
//							                     newptExpression.setExpression(IOEnew);
////							                     System.out.println(newptExpression);
//							                     Expression setptExpression=(Expression)newptExpression;
//							                     PrefixExpression newpfExpression=ast.newPrefixExpression();
//							                     newpfExpression.setOperand(setptExpression);
//							                     newpfExpression.setOperator(PrefixExpression.Operator.NOT);
//							                     Expression expression=(Expression)newpfExpression;	
//							                     IS.setExpression((Expression)expression);
//							                     if(mBlock.statements().get(k) instanceof ReturnStatement) {
//							                    	 if(IS.getElseStatement()==null) {
////							                    	 System.out.println("!equals");
//							                    	 ReturnStatement RS=(ReturnStatement)mBlock.statements().get(k);
////							                    	 System.out.println(RS);
//							                         Expression rsExpression=RS.getExpression();
//							                         Expression rExpression=(Expression)ASTNode.copySubtree(ast, rsExpression);
////							                         System.out.println(RS);
//							                         RS.delete();
//							                         IE.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
//							                         IE.setLeftOperand(copyIOEnew);
//							                         IE.setRightOperand(rExpression); 
//							                         Expression iEeExpression=(Expression)IE;
//							                         returnStatement.setExpression(iEeExpression);
//							                         mBlock.statements().add(returnStatement);
//							                         IS.delete();
//							                    	 }else {
//							                    		 System.out.println(IS);
//							                    	 }
//							                     } 
//							                     }
//							    			
//							                   }
//							    			
//							    		}
//							    	}
//							    	
//							    }
//							}
//						}
//					}
//				
//				

//if(m.getBody().statements().get(i) instanceof IfStatement){
//IfExampleRefactoring.ifExample(m, i, ast);
/*
 * IfStatement iS=(IfStatement)m.getBody().statements().get(i);
 * if(iS.getExpression() instanceof InstanceofExpression) { //记录if内容 IfStatement
 * Is=(IfStatement) m.getBody().statements().get(i); //获取if的内容
 * org.eclipse.jdt.core.dom getExpression() InstanceofExpression
 * IOE=(InstanceofExpression)Is.getExpression(); //对insatanceof右侧变量类型进行获取
 * if(IOE.getRightOperand().toString()!=null&&IOE.getLeftOperand().toString()!=
 * null) { String ST = IOE.getRightOperand().toString(); // String ST="Hello";
 * String ST2=IOE.getLeftOperand().toString();
 * //新建一个InstanceofExpression进行修改再装入Is中 InstanceofExpression
 * IOE0=ast.newInstanceofExpression(); //String stringType =
 * IOE.getRightOperand().toString();
 * 
 * //* Type type = ast.newSimpleType(ast.newName(ST));
 * //System.out.println(IOE);
 * 
 * //对if判断条件进行修改 //Assignment as=ast.newAssignment(); //SimpleName
 * type3=ast.newSimpleName(ST2); SingleVariableDeclaration svd =
 * ast.newSingleVariableDeclaration(); //* 直接装入改进后不可行
 * //svd.setName(ast.newSimpleName("str")); //* Type type2 =
 * ast.newSimpleType(ast.newName(ST)); //将type2的类型转为String //*
 * svd.setType(type2); //*试试simplyname
 * //ast.newName(IOE.getLeftOperand().toString())
 * //IOE0.setLeftOperand(ast.newName(IOE.getLeftOperand().toString())); //
 * IOE0.setRightOperand(ast.newSimpleType(ast.newName("String")));
 * //IOE0.setRightOperand(ast.newSimpleType(ast.newName(ST)));
 * IOE0.setPatternVariable(svd); //将svd中设置的name装入IOE0
 * //Is.setExpression((Expression)IOE0);
 * 
 * 
 * //对if当中的内容进行修改 //Is.setThenStatement(statement);
 * 
 * org.eclipse.jdt.core.dom.Statement statement=Is.getThenStatement();
 * if(!(statement instanceof ExpressionStatement)&& !(statement instanceof
 * ReturnStatement)&&!(statement instanceof ContinueStatement)&&!(statement
 * instanceof ThrowStatement) ) { Block block=(Block)statement; Assignment
 * as=ast.newAssignment(); for(int k=0;k<block.statements().size();k++) {
 * if(block.statements().get(k).toString().contains("("+ST+")")&&block.
 * statements().get(k)instanceof
 * VariableDeclarationStatement&&!block.statements().get(k).toString().contains(
 * "("+"("+ST+")")&&!block.statements().get(k).toString().contains("new")) {
 * VariableDeclarationStatement
 * vdstatement=(VariableDeclarationStatement)block.statements().get(k);
 * VariableDeclaration
 * vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
 * // System.out.println(vDeclarationExpression); CastExpression
 * castExpression=(CastExpression)vDeclarationExpression.getInitializer();
 * String tempName = vDeclarationExpression.getName().toString(); String
 * type3=castExpression.getExpression().toString(); Type
 * type4=castExpression.getType(); //
 * IOE0.setRightOperand(ast.newSimpleType(ast.newName(type3))); // Type type2 =
 * ast.newSimpleType(ast.newName(type3)); // svd.setType(type2); // 废弃重构数组类型 //
 * if(arratString.isPrimitiveType()) // { // // System.out.println(arratString);
 * // System.out.println(arratString instanceof PrimitiveType); // PrimitiveType
 * pT=(PrimitiveType)arratString; // Type
 * pType=ast.newPrimitiveType(pT.getPrimitiveTypeCode()); //
 * System.out.println(pType.toString()); // svd.setType(pType); //
 * System.out.println(arratString.toString()+type.getDimensions()); // List
 * aList=ASTNode.copySubtree(ast,type.getDimensions() ); // Type
 * aType=ast.newArrayType(arratString, type.getDimensions()); // // Type
 * aType=(Type) ASTNode.copySubtree(ast, type4); // svd.setType(aType); // //
 * }else { // Type type2=(Type) ASTNode.copySubtree(ast, type4); //
 * svd.setType(type2); // } // String aString=arratString.toString(); // Type
 * type2=ast.newSimpleType(ast.newName(aString)); // svd.setType(type2); //
 * System.out.println(arratString); // System.out.println(type); //
 * System.out.println(type3); // System.out.println(castExpression); //
 * System.out.println(tempName); // System.out.println(type4); //数组类型重构
 * if(type4.isArrayType()) { ArrayType type=(ArrayType)
 * castExpression.getType(); Type arratString=type.getElementType(); String
 * aString=arratString.toString(); Type type2=(Type) ASTNode.copySubtree(ast,
 * type4); svd.setType(type2); } else { Type type2 =
 * ast.newSimpleType(ast.newName(ST)); svd.setType(type2); //
 * IOE0.setRightOperand(ast.newSimpleType(ast.newName(ST))); } //*
 * Is.setExpression((Expression)IOE0); // System.out.println(type3); //
 * System.out.println(castExpression); // System.out.println(tempName); //
 * System.out.println(type4); //* svd.setName(ast.newSimpleName(tempName));
 * //as.setLeftHandSide(castExpression);
 * //svd.setName(ast.newSimpleName(as.getLeftHandSide().toString())); Expression
 * IOEL=IOE.getLeftOperand(); IOE0.setLeftOperand((Expression)
 * ASTNode.copySubtree(ast, IOEL));
 * //IOE0.setLeftOperand(ast.newName(IOE.getLeftOperand().toString()));
 * svd.setName(ast.newSimpleName(tempName)); Is.setExpression((Expression)IOE0);
 * System.out.println("variable num"+k); block.statements().remove(k);
 * 
 * 
 * }
 * 
 * else if(block.statements().get(k).toString().contains("("+ST+")")&&block.
 * statements().get(k)instanceof
 * ExpressionStatement&&!block.statements().get(k).toString().contains("new")&&!
 * block.statements().get(k).toString().contains("("+"("+ST+")")) {
 * ExpressionStatement
 * expressionStatement=(ExpressionStatement)block.statements().get(k); //
 * System.out.println(expressionStatement); Expression
 * expression=expressionStatement.getExpression(); if(!(expression instanceof
 * MethodInvocation)) { as=(Assignment)expression;
 * if(as.getLeftHandSide()!=null&&!(as.getLeftHandSide() instanceof
 * QualifiedName)) { //可以普遍修改 Expression asEleftExpression=as.getLeftHandSide();
 * String lString=asEleftExpression.toString(); // System.out.println(lString);
 * Expression asErightExpression=as.getRightHandSide(); String
 * rString=asErightExpression.toString(); // System.out.println(rString); Type
 * type=IOE.getRightOperand(); if(type.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type); // System.out.println(type2);
 * svd.setType(type2); }else { Type type2 = ast.newSimpleType(ast.newName(ST));
 * svd.setType(type2); } Expression IOEL=IOE.getLeftOperand();
 * IOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast, IOEL)); //
 * IOE0.setLeftOperand(ast.newName(IOE.getLeftOperand().toString()));
 * svd.setName(ast.newSimpleName(lString)); Is.setExpression((Expression)IOE0);
 * block.statements().remove(k); System.out.println("expression num"+k); } else
 * if(as.getLeftHandSide() instanceof QualifiedName) { //
 * System.out.println(iS); 有待解决
 * 
 * } } } else
 * if(block.statements().get(k).toString().contains("("+ST+")")&&block.
 * statements().get(k)instanceof
 * FieldDeclaration&&!block.statements().get(k).toString().contains("new")&&!
 * block.statements().get(k).toString().contains("("+"("+ST+")")) {
 * System.out.println(block); } // if内部嵌套重构的部分 else
 * if(block.statements().get(k).toString().contains("if")&&block.statements().
 * get(k)instanceof IfStatement) { IfStatement
 * thIf=(IfStatement)block.statements().get(k); if(thIf.getExpression()
 * instanceof InstanceofExpression) { InstanceofExpression
 * thIOE=(InstanceofExpression)thIf.getExpression();
 * if(thIOE.getRightOperand().toString()!=null&&thIOE.getRightOperand().toString
 * ()!=null) { String thrString=thIOE.getRightOperand().toString(); String
 * thlString=thIOE.getLeftOperand().toString(); InstanceofExpression
 * thIOE0=ast.newInstanceofExpression(); SingleVariableDeclaration
 * thsvd=ast.newSingleVariableDeclaration(); //
 * thIOE0.setLeftOperand(ast.newName(thIOE.getLeftOperand().toString()));
 * thIOE0.setPatternVariable(thsvd); org.eclipse.jdt.core.dom.Statement
 * thenstatement=thIf.getThenStatement(); Block thblock=(Block)thenstatement;
 * for(int th=0;th<thblock.statements().size();th++) {
 * if(thblock.statements().get(th).toString().contains("("+thrString+")")&&
 * thblock.statements().get(th)instanceof
 * VariableDeclarationStatement&&!thblock.statements().get(th).toString().
 * contains("("+"("+thrString+")")) { VariableDeclarationStatement
 * vdstatement=(VariableDeclarationStatement)thblock.statements().get(th);
 * VariableDeclaration
 * vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
 * CastExpression
 * castExpression=(CastExpression)vDeclarationExpression.getInitializer();
 * String tempName = vDeclarationExpression.getName().toString(); String
 * type3=castExpression.getExpression().toString(); Type
 * type4=castExpression.getType(); if(type4.isArrayType()) { Type type2=(Type)
 * ASTNode.copySubtree(ast, type4); thsvd.setType(type2); }else { Type type2 =
 * ast.newSimpleType(ast.newName(thlString)); thsvd.setType(type2); }
 * 
 * Expression thIOEl=thIOE.getLeftOperand(); thIOE0.setLeftOperand((Expression)
 * ASTNode.copySubtree(ast, thIOEl)); //
 * thIOE0.setLeftOperand(ast.newName(thIOE.getLeftOperand().toString()));
 * thsvd.setName(ast.newSimpleName(tempName));
 * thIf.setExpression((Expression)thIOE0); thblock.statements().remove(th);
 * System.out.println("if variable num"+th);
 * 
 * }else
 * if(thblock.statements().get(th).toString().contains("("+thrString+")")&&
 * thblock.statements().get(th)instanceof
 * ExpressionStatement&&!thblock.statements().get(th).toString().contains("("+
 * "("+thrString+")")) { Assignment thas=ast.newAssignment();
 * ExpressionStatement
 * expressionStatement=(ExpressionStatement)thblock.statements().get(th);
 * Expression expression=expressionStatement.getExpression(); if(!(expression
 * instanceof MethodInvocation)) { thas=(Assignment)expression;
 * if(thas.getLeftHandSide()!=null&&!(thas.getLeftHandSide() instanceof
 * QualifiedName)) { Expression asEleftExpression=thas.getLeftHandSide(); String
 * lString=asEleftExpression.toString(); Expression
 * asErightExpression=thas.getRightHandSide(); String
 * rString=asErightExpression.toString(); Type type=thIOE.getRightOperand();
 * if(type.isArrayType()) { Type type2=(Type)ASTNode.copySubtree(ast, type);
 * thsvd.setType(type2); }else { Type type2 =
 * ast.newSimpleType(ast.newName(thrString)); thsvd.setType(type2); } Expression
 * thIOEl=thIOE.getLeftOperand(); thIOE0.setLeftOperand((Expression)
 * ASTNode.copySubtree(ast, thIOEl)); //
 * thIOE0.setLeftOperand(ast.newName(thIOE.getLeftOperand().toString()));
 * thsvd.setName(ast.newSimpleName(lString)); thIf.setExpression((thIOE0));
 * thblock.statements().remove(th); System.out.println("if expression num"+th);
 * } } } }
 * 
 * 
 * } if(thIf.getElseStatement()!=null&&thIf.getElseStatement() instanceof
 * IfStatement) { IfStatement
 * theIfStatement=(IfStatement)thIf.getElseStatement(); while(theIfStatement
 * instanceof IfStatement) { if(theIfStatement.getExpression() instanceof
 * InstanceofExpression) { InstanceofExpression
 * thelsExpression=(InstanceofExpression)theIfStatement.getExpression();
 * if(thelsExpression.getRightOperand().toString()!=null&&thelsExpression.
 * getLeftOperand().toString()!=null) { String
 * thelselString=thelsExpression.getLeftOperand().toString(); String
 * thelserString=thelsExpression.getRightOperand().toString();
 * InstanceofExpression thelseIOE=ast.newInstanceofExpression();
 * SingleVariableDeclaration
 * thelseifDeclaration=ast.newSingleVariableDeclaration(); //
 * thelseIOE.setLeftOperand(ast.newSimpleName(thelsExpression.getLeftOperand().
 * toString())); thelseIOE.setPatternVariable(thelseifDeclaration);
 * org.eclipse.jdt.core.dom.Statement
 * thelsestatement=theIfStatement.getThenStatement(); Block
 * thelseblock=(Block)thelsestatement; for(int
 * te=0;te<thelseblock.statements().size();te++) {
 * if(thelseblock.statements().get(te).toString().contains("(" +
 * thelserString+")")&&thelseblock.statements().get(te)instanceof
 * VariableDeclarationStatement&&!thelseblock.statements().get(te).toString().
 * contains("("+"("+thelserString+")")&&!thelseblock.statements().get(te).
 * toString().contains("new")) { VariableDeclarationStatement
 * vdstatement=(VariableDeclarationStatement)thelseblock.statements().get(te);
 * VariableDeclaration
 * vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
 * String tempName = vDeclarationExpression.getName().toString(); CastExpression
 * castExpression=(CastExpression)vDeclarationExpression.getInitializer();
 * String type3=castExpression.getType().toString(); Type
 * type4=castExpression.getType(); if(type4.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type4);
 * thelseifDeclaration.setType(type2); }else { Type type2 =
 * ast.newSimpleType(ast.newName(thelserString));
 * thelseifDeclaration.setType(type2); } Expression
 * thelseIOEl=thelsExpression.getLeftOperand();
 * thelseIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast, thelseIOEl));
 * //
 * thelseIOE.setLeftOperand(ast.newSimpleName(thelsExpression.getLeftOperand().
 * toString())); thelseifDeclaration.setName(ast.newSimpleName(tempName));
 * theIfStatement.setExpression(thelseIOE); thelseblock.statements().remove(te);
 * System.out.println("ife variable num"+te); }else
 * if(thelseblock.statements().get(te).toString().contains("(" +
 * thelserString+")")&&thelseblock.statements().get(te)instanceof
 * ExpressionStatement&&!thelseblock.statements().get(te).toString().contains(
 * "("+"("+thelserString+")")&&!thelseblock.statements().get(te).toString().
 * contains("new")) { Assignment thas=ast.newAssignment(); ExpressionStatement
 * expressionStatement=(ExpressionStatement)thelseblock.statements().get(te);
 * Expression expression=expressionStatement.getExpression(); if(!(expression
 * instanceof MethodInvocation)) { thas=(Assignment)expression;
 * if(thas.getLeftHandSide()!=null&&!(thas.getLeftHandSide() instanceof
 * QualifiedName)) { Expression asEleftExpression=thas.getLeftHandSide(); String
 * lString=asEleftExpression.toString(); Expression
 * asErightExpression=thas.getRightHandSide(); String
 * rString=asErightExpression.toString(); Type
 * type=thelsExpression.getRightOperand(); if(type.isArrayType()) { Type type2
 * =(Type)ASTNode.copySubtree(ast, type); thelseifDeclaration.setType(type2);
 * }else { Type type2 = ast.newSimpleType(ast.newName(thelserString));
 * thelseifDeclaration.setType(type2); } Expression
 * thelseIOEl=thelsExpression.getLeftOperand();
 * thelseIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast, thelseIOEl));
 * //
 * thelseIOE.setLeftOperand(ast.newSimpleName(thelsExpression.getLeftOperand().
 * toString())); thelseifDeclaration.setName(ast.newSimpleName(lString));
 * theIfStatement.setExpression((thelseIOE));
 * thelseblock.statements().remove(te);
 * System.out.println("ife expression num"+te); } } } } } }
 * 
 * if(theIfStatement.getElseStatement() instanceof IfStatement) {
 * theIfStatement=(IfStatement)theIfStatement.getElseStatement(); }else { break;
 * } // theIfStatement=(IfStatement)theIfStatement.getElseStatement(); } } } } }
 * } } } //对else if部分进行重构 if(iS.getElseStatement()!=null&&iS.getElseStatement()
 * instanceof IfStatement) { IfStatement
 * eIfStatement=(IfStatement)iS.getElseStatement(); while(eIfStatement
 * instanceof IfStatement) { if(eIfStatement.getExpression() instanceof
 * InstanceofExpression) { // System.out.println("elseif is ok");
 * InstanceofExpression
 * elseifexpression=(InstanceofExpression)eIfStatement.getExpression();
 * if(elseifexpression.getLeftOperand().toString()!=null&&elseifexpression.
 * getRightOperand().toString()!=null) { String
 * LelString=elseifexpression.getLeftOperand().toString(); String
 * RelString=elseifexpression.getRightOperand().toString(); //
 * System.out.println(LelString); // System.out.println(RelString);
 * InstanceofExpression elseifIOE=ast.newInstanceofExpression();
 * SingleVariableDeclaration declaration = ast.newSingleVariableDeclaration();
 * //
 * elseifIOE.setLeftOperand(ast.newSimpleName(elseifexpression.getLeftOperand().
 * toString())); elseifIOE.setPatternVariable(declaration);
 * org.eclipse.jdt.core.dom.Statement statement=eIfStatement.getThenStatement();
 * 
 * if(!(statement instanceof ExpressionStatement)&&!(statement instanceof
 * ReturnStatement)&&!(statement instanceof ContinueStatement)&&!(statement
 * instanceof ThrowStatement)) { Block block=(Block)statement; for(int
 * k=0;k<block.statements().size();k++) {
 * if(block.statements().get(k).toString().contains("(" +
 * RelString+")")&&block.statements().get(k)instanceof
 * VariableDeclarationStatement&&!block.statements().get(k).toString().contains(
 * "("+"("+RelString+")")&&!block.statements().get(k).toString().contains("new")
 * ) { VariableDeclarationStatement
 * vdstatement=(VariableDeclarationStatement)block.statements().get(k);
 * VariableDeclaration
 * vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
 * String tempName = vDeclarationExpression.getName().toString(); CastExpression
 * castExpression=(CastExpression)vDeclarationExpression.getInitializer();
 * String type3=castExpression.getType().toString(); Type
 * type4=castExpression.getType(); if(type4.isArrayType()) { ArrayType
 * type=(ArrayType) castExpression.getType(); Type
 * arratString=type.getElementType(); String aString=arratString.toString();
 * Type type2=(Type)ASTNode.copySubtree(ast, type4); declaration.setType(type2);
 * 
 * // if(aString.equals("String")) { // Type
 * type2=ast.newSimpleType(ast.newName(aString)); // declaration.setType(type2);
 * // } // declaration.setName(ast.newSimpleName(tempName)); //
 * eIfStatement.setExpression(elseifIOE); // }else { Type type2 =
 * ast.newSimpleType(ast.newName(RelString)); declaration.setType(type2); //
 * IOE0.setRightOperand(ast.newSimpleType(ast.newName(ST))); } //
 * System.out.println(eIfStatement); Expression
 * elseifl=elseifexpression.getLeftOperand();
 * elseifIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast, elseifl)); //
 * elseifIOE.setLeftOperand(ast.newSimpleName(elseifexpression.getLeftOperand().
 * toString())); declaration.setName(ast.newSimpleName(tempName));
 * eIfStatement.setExpression(elseifIOE); block.statements().remove(k);
 * System.out.println("varialbe elseif num"+k);
 * 
 * }else if
 * (block.statements().get(k).toString().contains("("+RelString+")")&&block.
 * statements().get(k)instanceof
 * ExpressionStatement&&!block.statements().get(k).toString().contains("new")&&!
 * block.statements().get(k).toString().contains("("+"("+RelString+")")) {
 * Assignment as=ast.newAssignment(); ExpressionStatement
 * expressionStatement=(ExpressionStatement)block.statements().get(k);
 * Expression expression=expressionStatement.getExpression(); if(!(expression
 * instanceof MethodInvocation)) { as=(Assignment)expression;
 * if(as.getLeftHandSide()!=null&&!(as.getLeftHandSide() instanceof
 * QualifiedName)) { Expression asEleftExpression=as.getLeftHandSide(); String
 * lString=asEleftExpression.toString(); Expression
 * asErightExpression=as.getRightHandSide(); String
 * rString=asErightExpression.toString(); Type
 * type=elseifexpression.getRightOperand(); if(type.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type); declaration.setType(type2); }else
 * { Type type2 = ast.newSimpleType(ast.newName(RelString));
 * declaration.setType(type2); } Expression
 * elseifl=elseifexpression.getLeftOperand();
 * elseifIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast, elseifl)); //
 * elseifIOE.setLeftOperand(ast.newSimpleName(elseifexpression.getLeftOperand().
 * toString())); declaration.setName(ast.newSimpleName(lString));
 * eIfStatement.setExpression(elseifIOE); block.statements().remove(k);
 * System.out.println("expression elseif num"+k); } } } } } } }
 * if(eIfStatement.getElseStatement() instanceof IfStatement) {
 * eIfStatement=(IfStatement)eIfStatement.getElseStatement(); }else { break; }
 * 
 * // eIfStatement=(IfStatement)eIfStatement.getElseStatement();
 * 
 * 
 * }
 * 
 * 
 * }
 * 
 */
//对if外嵌套for循环的模式进行重构
//if(m.getBody().statements().get(i) instanceof ForStatement&&m.getBody().statements().get(i).toString().contains("if")&&m.getBody().statements().get(i).toString().contains("instanceof")) {
//	  ForExampleRefactoring.forExample(m, i, ast);
/*
 * ForStatement Fs=(ForStatement)m.getBody().statements().get(i);
 * org.eclipse.jdt.core.dom.Statement statement=Fs.getBody();
 * //System.out.println(Fs); Block block=(Block)statement; for(int
 * k=0;k<block.statements().size();k++) {
 * if(block.statements().get(k).toString().contains("if")&&block.statements().
 * get(k)instanceof IfStatement) { IfStatement
 * Is=(IfStatement)block.statements().get(k); if(Is.getExpression() instanceof
 * InstanceofExpression) { InstanceofExpression
 * ioExpression=(InstanceofExpression)Is.getExpression();
 * if(ioExpression.getRightOperand().toString()!=null&&ioExpression.
 * getLeftOperand().toString()!=null) { String
 * ST=ioExpression.getRightOperand().toString(); String
 * ST2=ioExpression.getLeftOperand().toString(); Expression
 * sTlExpression=ioExpression.getLeftOperand(); InstanceofExpression
 * IOE0=ast.newInstanceofExpression(); SingleVariableDeclaration svd =
 * ast.newSingleVariableDeclaration(); // if(ioExpression.getLeftOperand()
 * instanceof ArrayAccess) { // IOE0.setLeftOperand((Expression)
 * ASTNode.copySubtree(ast, sTlExpression)); // } // else { //
 * IOE0.setLeftOperand(ast.newName(ioExpression.getLeftOperand().toString()));
 * // } IOE0.setPatternVariable(svd); org.eclipse.jdt.core.dom.Statement
 * Fstatement=Is.getThenStatement();
 * 
 * // System.out.println(Fstatement instanceof ExpressionStatement);
 * 
 * if(!(Fstatement instanceof ExpressionStatement)&&!(Fstatement instanceof
 * ReturnStatement)&&!(Fstatement instanceof ContinueStatement)&&!(Fstatement
 * instanceof ThrowStatement)) { Block Forblock=(Block)Fstatement; Assignment
 * as=ast.newAssignment(); for(int T=0;T<Forblock.statements().size();T++) {
 * if(Forblock.statements().get(T).toString().contains("("+ST+")")&&Forblock.
 * statements().get(T)instanceof
 * VariableDeclarationStatement&&!Forblock.statements().get(T).toString().
 * contains("new")&&!Forblock.statements().get(T).toString().contains("("+"("+ST
 * +")")) { VariableDeclarationStatement
 * vdstatement=(VariableDeclarationStatement)Forblock.statements().get(T);
 * VariableDeclaration
 * vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
 * CastExpression
 * castExpression=(CastExpression)vDeclarationExpression.getInitializer();
 * String tempName = vDeclarationExpression.getName().toString(); String
 * type3=castExpression.getExpression().toString(); Type
 * type4=castExpression.getType(); if(type4.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type4); svd.setType(type2); }else { Type
 * type2 = ast.newSimpleType(ast.newName(ST)); svd.setType(type2); }
 * 
 * //装入instanceof 左侧 IOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast,
 * sTlExpression)); //
 * IOE0.setLeftOperand(ast.newName(ioExpression.getLeftOperand().toString()));
 * svd.setName(ast.newSimpleName(tempName)); Is.setExpression((Expression)IOE0);
 * Forblock.statements().remove(T); System.out.println("for variable num"+T);
 * }else
 * if(Forblock.statements().get(T).toString().contains("("+ST+")")&&Forblock.
 * statements().get(T)instanceof
 * ExpressionStatement&&!Forblock.statements().get(T).toString().contains("new")
 * &&!Forblock.statements().get(T).toString().contains("("+"("+ST+")")) {
 * Assignment fas=ast.newAssignment(); ExpressionStatement
 * expressionStatement=(ExpressionStatement)Forblock.statements().get(T);
 * Expression expression=expressionStatement.getExpression(); if(!(expression
 * instanceof MethodInvocation)) { fas=(Assignment)expression; //
 * System.out.println(fas);
 * if(fas.getLeftHandSide()!=null&&!(fas.getLeftHandSide() instanceof
 * QualifiedName)) { Expression asEleftExpression=fas.getLeftHandSide(); String
 * lString=asEleftExpression.toString(); Expression
 * asErightExpression=fas.getRightHandSide(); String
 * rString=asErightExpression.toString(); Type
 * type=ioExpression.getRightOperand(); if(type.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type); svd.setType(type2); }else { Type
 * type2 = ast.newSimpleType(ast.newName(ST)); svd.setType(type2); }
 * 
 * //装入instanceof左侧 IOE0.setLeftOperand((Expression)
 * ASTNode.copySubtree(ast,sTlExpression)); //
 * IOE0.setLeftOperand(ast.newName(ioExpression.getLeftOperand().toString()));
 * 
 * 
 * // svd.setName(ast.newSimpleName(lString)); if(asEleftExpression instanceof
 * ArrayAccess) { // svd.setName( (SimpleName) ASTNode.copySubtree(ast,
 * asEleftExpression)); // svd.setName( ast.newSimpleName("hello")); ArrayAccess
 * access=(ArrayAccess)asEleftExpression; Expression
 * aExpression=access.getArray(); Expression aExpressionindex=access.getIndex();
 * // System.out.println(aExpression); // System.out.println(aExpressionindex);
 * // SimpleName aName=(SimpleName)asEleftExpression; 不能强转 // SimpleName
 * aName=(SimpleName)ASTNode.copySubtree(ast, asEleftExpression); 不能强转 //
 * SimpleName aSimpleName=(SimpleName) ASTNode.copySubtree(ast,
 * asEleftExpression); // svd.setName( aSimpleName);
 * 
 * 
 * }else { svd.setName(ast.newSimpleName(lString)); } //
 * svd.setName((SimpleName) ASTNode.copySubtree(ast, asEleftExpression));
 * Is.setExpression(IOE0); Forblock.statements().remove(T);
 * System.out.println("for expression num"+T); } } } } } } //对for循环中else if部分重构
 * if(Is.getElseStatement()!=null&&Is.getElseStatement() instanceof IfStatement)
 * { IfStatement foreIfStatement=(IfStatement)Is.getElseStatement();
 * while(foreIfStatement instanceof IfStatement) {
 * if(foreIfStatement.getExpression() instanceof InstanceofExpression) {
 * InstanceofExpression
 * forExpression=(InstanceofExpression)foreIfStatement.getExpression();
 * if(forExpression.getLeftOperand().toString()!=null&&forExpression.
 * getRightOperand().toString()!=null) { String
 * forleftString=forExpression.getLeftOperand().toString(); String
 * forrightString=forExpression.getRightOperand().toString();
 * InstanceofExpression forInstanceofExpression=ast.newInstanceofExpression();
 * SingleVariableDeclaration fordeclaration =
 * ast.newSingleVariableDeclaration(); //
 * System.out.println(forInstanceofExpression.getLeftOperand() instanceof
 * ArrayAccess); // if(forInstanceofExpression.getLeftOperand() instanceof
 * ArrayAccess) { // // }else { //
 * forInstanceofExpression.setLeftOperand(ast.newName(forExpression.
 * getLeftOperand().toString())); // } Expression
 * forleftExpression=forExpression.getLeftOperand(); //
 * forInstanceofExpression.setLeftOperand(ast.newName(forExpression.
 * getLeftOperand().toString()));
 * forInstanceofExpression.setPatternVariable(fordeclaration);
 * org.eclipse.jdt.core.dom.Statement
 * forstatement=foreIfStatement.getThenStatement(); if(!(forstatement instanceof
 * ExpressionStatement)&&!(forstatement instanceof
 * ContinueStatement)&&!(forstatement instanceof
 * ReturnStatement)&&!(forstatement instanceof ThrowStatement)) { Block
 * forblock=(Block)forstatement; for(int f=0;f<forblock.statements().size();f++)
 * { if(forblock.statements().get(f).toString().contains("(" +
 * forrightString+")")&&forblock.statements().get(f)instanceof
 * VariableDeclarationStatement&&!forblock.statements().get(f).toString().
 * contains("("+"("+forrightString+")")&&!forblock.statements().get(f).toString(
 * ).contains("new")) { VariableDeclarationStatement
 * vdstatement=(VariableDeclarationStatement)forblock.statements().get(f);
 * VariableDeclaration
 * vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
 * String tempName = vDeclarationExpression.getName().toString(); CastExpression
 * castExpression=(CastExpression)vDeclarationExpression.getInitializer();
 * String type3=castExpression.getType().toString(); Type
 * type4=castExpression.getType(); if(type4.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type4); fordeclaration.setType(type2);
 * }else { Type type2 = ast.newSimpleType(ast.newName(forrightString));
 * fordeclaration.setType(type2); }
 * 
 * forInstanceofExpression.setLeftOperand((Expression) ASTNode.copySubtree(ast,
 * forleftExpression)); //
 * forInstanceofExpression.setLeftOperand(ast.newName(forExpression.
 * getLeftOperand().toString()));
 * fordeclaration.setName(ast.newSimpleName(tempName));
 * foreIfStatement.setExpression(forInstanceofExpression);
 * forblock.statements().remove(f);
 * System.out.println("for else variable num"+f);
 * 
 * 
 * }else if(forblock.statements().get(f).toString().contains("(" +
 * forrightString+")")&&forblock.statements().get(f)instanceof
 * ExpressionStatement&&!forblock.statements().get(f).toString().contains("("+
 * "("+forrightString+")")&&!forblock.statements().get(f).toString().contains(
 * "new")) { Assignment fas=ast.newAssignment(); ExpressionStatement
 * expressionStatement=(ExpressionStatement)forblock.statements().get(f);
 * Expression expression=expressionStatement.getExpression(); if(!(expression
 * instanceof MethodInvocation)) { fas=(Assignment)expression;
 * if(fas.getLeftHandSide()!=null&&!(fas.getLeftHandSide() instanceof
 * QualifiedName)) { Expression asEleftExpression=fas.getLeftHandSide(); String
 * lString=asEleftExpression.toString(); Expression
 * asErightExpression=fas.getRightHandSide(); String
 * rString=asErightExpression.toString(); Type
 * type=forExpression.getRightOperand(); if(type.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type); fordeclaration.setType(type2);
 * }else { Type type2 = ast.newSimpleType(ast.newName(forrightString));
 * fordeclaration.setType(type2); }
 * forInstanceofExpression.setLeftOperand((Expression) ASTNode.copySubtree(ast,
 * forleftExpression)); //
 * forInstanceofExpression.setLeftOperand(ast.newName(forExpression.
 * getLeftOperand().toString()));
 * fordeclaration.setName(ast.newSimpleName(lString));
 * foreIfStatement.setExpression(forInstanceofExpression);
 * forblock.statements().remove(f);
 * System.out.println("for else expression num"+f); } } } } }
 * 
 * }
 * 
 * } if(foreIfStatement.getElseStatement() instanceof IfStatement) {
 * foreIfStatement=(IfStatement) foreIfStatement.getElseStatement(); }else {
 * break; } // foreIfStatement=(IfStatement) foreIfStatement.getElseStatement();
 * 
 * }
 * 
 * } } } }
 * 
 * 
 */
//} //对Try包含的部分重构
//if(m.getBody().statements().get(i) instanceof TryStatement&&m.getBody().statements().get(i).toString().contains("if")&&m.getBody().statements().get(i).toString().contains("instanceof")) {
//	 TryExampleRefactoring.tryExample(m, i, ast);
/*
 * TryStatement Ts=(TryStatement)m.getBody().statements().get(i);
 * org.eclipse.jdt.core.dom.Statement statement=Ts.getBody(); Block
 * block=(Block)statement; for(int k=0;k<block.statements().size();k++) {
 * if(block.statements().get(k).toString().contains("if")&&block.statements().
 * get(k)instanceof IfStatement) { IfStatement
 * Is=(IfStatement)block.statements().get(k); if(Is.getExpression() instanceof
 * InstanceofExpression) { InstanceofExpression
 * ioExpression=(InstanceofExpression)Is.getExpression();
 * if(ioExpression.getRightOperand().toString()!=null&&ioExpression.
 * getLeftOperand().toString()!=null) { String
 * ST=ioExpression.getRightOperand().toString(); String
 * ST2=ioExpression.getLeftOperand().toString(); InstanceofExpression
 * TryIOE=ast.newInstanceofExpression(); SingleVariableDeclaration
 * Trydeclaration = ast.newSingleVariableDeclaration(); //
 * TryIOE.setLeftOperand(ast.newName(ioExpression.getLeftOperand().toString()));
 * TryIOE.setPatternVariable(Trydeclaration); org.eclipse.jdt.core.dom.Statement
 * Tstatement=Is.getThenStatement(); if(!(Tstatement instanceof
 * ExpressionStatement)&&!(Tstatement instanceof ReturnStatement)&&!(Tstatement
 * instanceof ContinueStatement)&&!(Tstatement instanceof ThrowStatement)) { //
 * System.out.println(Tstatement); Block Tryblock=(Block)Tstatement; for(int
 * T=0;T<Tryblock.statements().size();T++) {
 * if(Tryblock.statements().get(T).toString().contains("("+ST+")")&&Tryblock.
 * statements().get(T)instanceof
 * VariableDeclarationStatement&&!Tryblock.statements().get(T).toString().
 * contains("new")&&!Tryblock.statements().get(T).toString().contains("("+"("+ST
 * +")")) { VariableDeclarationStatement
 * vdstatement=(VariableDeclarationStatement)Tryblock.statements().get(T);
 * VariableDeclaration
 * vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
 * CastExpression
 * castExpression=(CastExpression)vDeclarationExpression.getInitializer();
 * String tempName = vDeclarationExpression.getName().toString(); String
 * type3=castExpression.getExpression().toString(); Type
 * type4=castExpression.getType(); if(type4.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type4); Trydeclaration.setType(type2);
 * }else { Type type2 = ast.newSimpleType(ast.newName(ST));
 * Trydeclaration.setType(type2); } Expression
 * ioExpressionl=ioExpression.getLeftOperand();
 * TryIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast, ioExpressionl));
 * //
 * TryIOE.setLeftOperand(ast.newName(ioExpression.getLeftOperand().toString()));
 * Trydeclaration.setName(ast.newSimpleName(tempName));
 * Is.setExpression((Expression)TryIOE); Tryblock.statements().remove(T);
 * System.out.println("try variable num"+T); }else
 * if(Tryblock.statements().get(T).toString().contains("("+ST+")")&&Tryblock.
 * statements().get(T)instanceof
 * ExpressionStatement&&!Tryblock.statements().get(T).toString().contains("new")
 * &&!Tryblock.statements().get(T).toString().contains("("+"("+ST+")")) {
 * Assignment Tas=ast.newAssignment(); ExpressionStatement
 * expressionStatement=(ExpressionStatement)Tryblock.statements().get(T);
 * Expression expression=expressionStatement.getExpression(); if(!(expression
 * instanceof MethodInvocation)) { Tas=(Assignment)expression;
 * if(Tas.getLeftHandSide()!=null&&!(Tas.getLeftHandSide() instanceof
 * QualifiedName)) { Expression asEleftExpression=Tas.getLeftHandSide(); String
 * lString=asEleftExpression.toString(); Expression
 * asErightExpression=Tas.getRightHandSide(); String
 * rString=asErightExpression.toString(); Type
 * type=ioExpression.getRightOperand(); if(type.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type); Trydeclaration.setType(type2);
 * }else { Type type2 = ast.newSimpleType(ast.newName(ST));
 * Trydeclaration.setType(type2); } Expression
 * ioExpressionl=ioExpression.getLeftOperand();
 * TryIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast, ioExpressionl));
 * //
 * TryIOE.setLeftOperand(ast.newName(ioExpression.getLeftOperand().toString()));
 * Trydeclaration.setName(ast.newSimpleName(lString)); Is.setExpression(TryIOE);
 * Tryblock.statements().remove(T); System.out.println("try expression num"+T);
 * } } } } } } //对Try包含的 else if进行重构
 * if(Is.getElseStatement()!=null&&Is.getElseStatement() instanceof IfStatement)
 * { IfStatement tryIfStatement=(IfStatement)Is.getElseStatement();
 * while(tryIfStatement instanceof IfStatement) {
 * if(tryIfStatement.getExpression() instanceof InstanceofExpression) {
 * InstanceofExpression
 * tryExpression=(InstanceofExpression)tryIfStatement.getExpression();
 * if(tryExpression.getLeftOperand().toString()!=null&&tryExpression.
 * getRightOperand().toString()!=null) { String
 * tryleftString=tryExpression.getLeftOperand().toString(); String
 * tryrightString=tryExpression.getRightOperand().toString();
 * InstanceofExpression tryInstanceofExpression=ast.newInstanceofExpression();
 * SingleVariableDeclaration trydeclaration =
 * ast.newSingleVariableDeclaration(); //
 * tryInstanceofExpression.setLeftOperand(ast.newSimpleName(tryExpression.
 * getLeftOperand().toString()));
 * tryInstanceofExpression.setPatternVariable(trydeclaration);
 * org.eclipse.jdt.core.dom.Statement
 * trystatement=tryIfStatement.getThenStatement(); if(!(trystatement instanceof
 * ContinueStatement)&&!(trystatement instanceof
 * ReturnStatement)&&!(trystatement instanceof
 * ExpressionStatement)&&!(trystatement instanceof ThrowStatement)) { Block
 * tryblock=(Block)trystatement; for(int f=0;f<tryblock.statements().size();f++)
 * { if(tryblock.statements().get(f).toString().contains("(" +
 * tryrightString+")")&&tryblock.statements().get(f)instanceof
 * VariableDeclarationStatement&&!tryblock.statements().get(f).toString().
 * contains("("+"("+tryrightString+")")&&!tryblock.statements().get(f).toString(
 * ).contains("new")) { VariableDeclarationStatement
 * vdstatement=(VariableDeclarationStatement)tryblock.statements().get(f);
 * VariableDeclaration
 * vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
 * String tempName = vDeclarationExpression.getName().toString(); CastExpression
 * castExpression=(CastExpression)vDeclarationExpression.getInitializer();
 * String type3=castExpression.getType().toString(); Type
 * type4=castExpression.getType(); if(type4.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type4); trydeclaration.setType(type2);
 * }else { Type type2 = ast.newSimpleType(ast.newName(tryrightString));
 * trydeclaration.setType(type2); } Expression
 * tryExpressionl=tryExpression.getLeftOperand();
 * tryInstanceofExpression.setLeftOperand((Expression) ASTNode.copySubtree(ast,
 * tryExpressionl)); //
 * tryInstanceofExpression.setLeftOperand(ast.newSimpleName(tryExpression.
 * getLeftOperand().toString()));
 * trydeclaration.setName(ast.newSimpleName(tempName));
 * tryIfStatement.setExpression(tryInstanceofExpression);
 * tryblock.statements().remove(f);
 * System.out.println("try else variable num"+f);
 * 
 * 
 * }else
 * if(tryblock.statements().get(f).toString().contains("("+tryrightString+")")&&
 * tryblock.statements().get(f)instanceof
 * ExpressionStatement&&!tryblock.statements().get(f).toString().contains("new")
 * &&!tryblock.statements().get(f).toString().contains("("+"("+tryrightString+
 * ")")) { Assignment tas=ast.newAssignment(); ExpressionStatement
 * expressionStatement=(ExpressionStatement)tryblock.statements().get(f);
 * Expression expression=expressionStatement.getExpression(); if(!(expression
 * instanceof MethodInvocation)) { tas=(Assignment)expression;
 * if(tas.getLeftHandSide()!=null&&!(tas.getLeftHandSide() instanceof
 * QualifiedName)) { Expression asEleftExpression=tas.getLeftHandSide(); String
 * lString=asEleftExpression.toString(); Expression
 * asErightExpression=tas.getRightHandSide(); String
 * rString=asErightExpression.toString(); Type
 * type=tryExpression.getRightOperand(); if(type.isArrayType()) { Type
 * type2=(Type)ASTNode.copySubtree(ast, type); trydeclaration.setType(type2);
 * }else { Type type2 = ast.newSimpleType(ast.newName(tryrightString));
 * trydeclaration.setType(type2); } Expression
 * tryExpressionl=tryExpression.getLeftOperand();
 * tryInstanceofExpression.setLeftOperand((Expression) ASTNode.copySubtree(ast,
 * tryExpressionl)); //
 * tryInstanceofExpression.setLeftOperand(ast.newSimpleName(tryExpression.
 * getLeftOperand().toString()));
 * trydeclaration.setName(ast.newSimpleName(lString));
 * tryIfStatement.setExpression(tryInstanceofExpression);
 * tryblock.statements().remove(f);
 * System.out.println("try else expression num"+f); } } } } } }
 * 
 * } if(tryIfStatement.getElseStatement() instanceof IfStatement) {
 * tryIfStatement=(IfStatement) tryIfStatement.getElseStatement(); }else {
 * break; } // tryIfStatement=(IfStatement) tryIfStatement.getElseStatement();
 * 
 * }
 * 
 * }
 * 
 * } } }
 * 
 */