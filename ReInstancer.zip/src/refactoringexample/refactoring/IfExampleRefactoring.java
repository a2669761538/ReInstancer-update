package refactoringexample.refactoring;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ArrayType;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CastExpression;
import org.eclipse.jdt.core.dom.ContinueStatement;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InstanceofExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.ThrowStatement;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.VariableDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

public class IfExampleRefactoring {
	public static void ifExample(MethodDeclaration m, int i, AST ast) {

		   IfStatement iS=(IfStatement)m.getBody().statements().get(i);
		   if(iS.getExpression() instanceof InstanceofExpression) { 
			//��¼if���� 
			IfStatement Is=(IfStatement)m.getBody().statements().get(i);
         //��ȡif������  org.eclipse.jdt.core.dom getExpression()
			InstanceofExpression IOE=(InstanceofExpression)Is.getExpression();
			//��insatanceof�Ҳ�������ͽ��л�ȡ
			if(IOE.getRightOperand().toString()!=null&&IOE.getLeftOperand().toString()!=null) {
	        String ST = IOE.getRightOperand().toString();
//          String ST="Hello";
      	String ST2=IOE.getLeftOperand().toString();
			//�½�һ��InstanceofExpression�����޸���װ��Is��
			InstanceofExpression IOE0=ast.newInstanceofExpression();
//			String stringType = IOE.getRightOperand().toString();
			
//	*		Type type = ast.newSimpleType(ast.newName(ST));
			//System.out.println(IOE);
			
			//��if�ж����������޸�
//			Assignment as=ast.newAssignment();
//			SimpleName type3=ast.newSimpleName(ST2);
			SingleVariableDeclaration svd = ast.newSingleVariableDeclaration();
//*   ֱ��װ��Ľ��󲻿���      
//			svd.setName(ast.newSimpleName("str"));					
//*          Type type2 = ast.newSimpleType(ast.newName(ST));
			//��type2������תΪString
//*		    svd.setType(type2);
//			*����simplyname
			//ast.newName(IOE.getLeftOperand().toString())
//			IOE0.setLeftOperand(ast.newName(IOE.getLeftOperand().toString())); 		            
//	        IOE0.setRightOperand(ast.newSimpleType(ast.newName("String")));
//	        IOE0.setRightOperand(ast.newSimpleType(ast.newName(ST)));
			IOE0.setPatternVariable(svd);
			//��svd�����õ�nameװ��IOE0
//		    Is.setExpression((Expression)IOE0);			
			
			
			//��if���е����ݽ����޸�
			//Is.setThenStatement(statement);
			
			org.eclipse.jdt.core.dom.Statement statement=Is.getThenStatement();
			if(!(statement instanceof ExpressionStatement)&& !(statement instanceof ReturnStatement)&&!(statement instanceof ContinueStatement)&&!(statement instanceof ThrowStatement) ) {
		    Block block=(Block)statement;
			Assignment as=ast.newAssignment();
			for(int k=0;k<block.statements().size();k++) {
				 if(block.statements().get(k).toString().contains("("+ST+")")&&block.statements().get(k)instanceof VariableDeclarationStatement&&!block.statements().get(k).toString().contains("("+"("+ST+")")&&!block.statements().get(k).toString().contains("new")) {
					 VariableDeclarationStatement vdstatement=(VariableDeclarationStatement)block.statements().get(k);
			         VariableDeclaration vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
//			         System.out.println(vDeclarationExpression);
			         CastExpression castExpression=(CastExpression)vDeclarationExpression.getInitializer();
			         String tempName = vDeclarationExpression.getName().toString();
				     String type3=castExpression.getExpression().toString();
                  Type type4=castExpression.getType();
//          IOE0.setRightOperand(ast.newSimpleType(ast.newName(type3)));
//          Type type2 = ast.newSimpleType(ast.newName(type3));
//          svd.setType(type2);
               /*�����ع���������
            	  if(arratString.isPrimitiveType())
            	    {

            		  System.out.println(arratString);
//            	  System.out.println(arratString instanceof PrimitiveType);
            		  PrimitiveType pT=(PrimitiveType)arratString;
//            	  Type pType=ast.newPrimitiveType(pT.getPrimitiveTypeCode());
//            	  System.out.println(pType.toString());
//            		    svd.setType(pType);
            		    System.out.println(arratString.toString()+type.getDimensions());
//            		    List aList=ASTNode.copySubtree(ast,type.getDimensions() );
//            		    Type aType=ast.newArrayType(arratString, type.getDimensions());
            		   
            		    Type aType=(Type) ASTNode.copySubtree(ast, type4);
            		    svd.setType(aType);
            		                     		  
            	   }else {
							Type type2=(Type) ASTNode.copySubtree(ast, type4);
							svd.setType(type2);	
						}*/
//            	    String aString=arratString.toString();
//            	    Type type2=ast.newSimpleType(ast.newName(aString));
//            	    svd.setType(type2);
//            	    System.out.println(arratString);
//            	    System.out.println(type);
//            	    System.out.println(type3);
//		    	    System.out.println(castExpression);
//			    	System.out.println(tempName);
//			    	System.out.println(type4);
           //���������ع�
           if(type4.isArrayType())
            {
        	    ArrayType type=(ArrayType) castExpression.getType();
        	    Type arratString=type.getElementType();
        	    String aString=arratString.toString();
        	    Type type2=(Type) ASTNode.copySubtree(ast, type4);
			    svd.setType(type2);	
            }
           else {
            	Type type2 = ast.newSimpleType(ast.newName(ST));
            	svd.setType(type2);
//           IOE0.setRightOperand(ast.newSimpleType(ast.newName(ST)));	
				}
//*           Is.setExpression((Expression)IOE0);	
//            System.out.println(type3);
//	    	    System.out.println(castExpression);
//		    	System.out.println(tempName);
//		    	System.out.println(type4);
//*              svd.setName(ast.newSimpleName(tempName));
		    	//as.setLeftHandSide(castExpression);
		    	//svd.setName(ast.newSimpleName(as.getLeftHandSide().toString()));
           Expression IOEL=IOE.getLeftOperand();
           IOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast, IOEL));
//         IOE0.setLeftOperand(ast.newName(IOE.getLeftOperand().toString())); 
           svd.setName(ast.newSimpleName(tempName));
           Is.setExpression((Expression)IOE0);	
//           System.out.println("variable num"+k);
           block.statements().remove(k);
           
           
		}
				 		 
		else if(block.statements().get(k).toString().contains("("+ST+")")&&block.statements().get(k)instanceof ExpressionStatement&&!block.statements().get(k).toString().contains("new")&&!block.statements().get(k).toString().contains("("+"("+ST+")")) {
			   ExpressionStatement expressionStatement=(ExpressionStatement)block.statements().get(k);
//			   System.out.println(expressionStatement);
			   Expression expression=expressionStatement.getExpression();
			 if(!(expression instanceof MethodInvocation)) {
			   as=(Assignment)expression;
			   if(as.getLeftHandSide()!=null&&!(as.getLeftHandSide() instanceof QualifiedName)) { //�����ձ��޸�
			   Expression asEleftExpression=as.getLeftHandSide();
			   String lString=asEleftExpression.toString();
//			   System.out.println(lString);
			   Expression asErightExpression=as.getRightHandSide();
			   String rString=asErightExpression.toString();
//			   System.out.println(rString);
			   Type type=IOE.getRightOperand();
			   if(type.isArrayType()) {
				 Type type2=(Type)ASTNode.copySubtree(ast, type);
//				 System.out.println(type2);
				 svd.setType(type2);
			   }else {
			   Type type2 = ast.newSimpleType(ast.newName(ST));
			   svd.setType(type2);
			   }
			   Expression IOEL=IOE.getLeftOperand();
			   IOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast, IOEL));
//			   IOE0.setLeftOperand(ast.newName(IOE.getLeftOperand().toString()));
			   svd.setName(ast.newSimpleName(lString));
        	   Is.setExpression((Expression)IOE0);	
            block.statements().remove(k);
//            System.out.println("expression num"+k);
			   }
			   else if(as.getLeftHandSide() instanceof QualifiedName) {
//				   System.out.println(iS);   �д����
				   
			   }
			 }
			} else if(block.statements().get(k).toString().contains("("+ST+")")&&block.statements().get(k)instanceof FieldDeclaration&&!block.statements().get(k).toString().contains("new")&&!block.statements().get(k).toString().contains("("+"("+ST+")")) {
				System.out.println(block);
			}
				 // if�ڲ�Ƕ���ع��Ĳ���	
		else if(block.statements().get(k).toString().contains("if")&&block.statements().get(k)instanceof IfStatement) {
			 IfStatement thIf=(IfStatement)block.statements().get(k);
			 if(thIf.getExpression() instanceof InstanceofExpression) {
			 InstanceofExpression thIOE=(InstanceofExpression)thIf.getExpression();
			 if(thIOE.getRightOperand().toString()!=null&&thIOE.getRightOperand().toString()!=null) {
				 String thrString=thIOE.getRightOperand().toString();
				 String thlString=thIOE.getLeftOperand().toString();
				 InstanceofExpression thIOE0=ast.newInstanceofExpression();
				 SingleVariableDeclaration thsvd=ast.newSingleVariableDeclaration();
//				 thIOE0.setLeftOperand(ast.newName(thIOE.getLeftOperand().toString()));
				 thIOE0.setPatternVariable(thsvd);
				 org.eclipse.jdt.core.dom.Statement thenstatement=thIf.getThenStatement();
				 Block thblock=(Block)thenstatement;
				 for(int th=0;th<thblock.statements().size();th++) {
					 if(thblock.statements().get(th).toString().contains("("+thrString+")")&&thblock.statements().get(th)instanceof VariableDeclarationStatement&&!thblock.statements().get(th).toString().contains("("+"("+thrString+")")) {
						 VariableDeclarationStatement vdstatement=(VariableDeclarationStatement)thblock.statements().get(th);
				         VariableDeclaration vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
				         CastExpression castExpression=(CastExpression)vDeclarationExpression.getInitializer();
				         String tempName = vDeclarationExpression.getName().toString();
					     String type3=castExpression.getExpression().toString();
					     Type type4=castExpression.getType();
					     if(type4.isArrayType()) {
					    	 Type type2=(Type) ASTNode.copySubtree(ast, type4);
					    	 thsvd.setType(type2);
					     }else {
					    	 Type type2 = ast.newSimpleType(ast.newName(thlString));
		                     thsvd.setType(type2);
					     } 

					     Expression thIOEl=thIOE.getLeftOperand();
					     thIOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast, thIOEl));
//					     thIOE0.setLeftOperand(ast.newName(thIOE.getLeftOperand().toString()));
	                     thsvd.setName(ast.newSimpleName(tempName));
	                     thIf.setExpression((Expression)thIOE0);	
						 thblock.statements().remove(th);
//						 System.out.println("if variable num"+th);
						 
					 }else if(thblock.statements().get(th).toString().contains("("+thrString+")")&&thblock.statements().get(th)instanceof ExpressionStatement&&!thblock.statements().get(th).toString().contains("("+"("+thrString+")")) {
						 Assignment thas=ast.newAssignment();
						  ExpressionStatement expressionStatement=(ExpressionStatement)thblock.statements().get(th);
						  Expression expression=expressionStatement.getExpression();
						  if(!(expression instanceof MethodInvocation)) {
				          thas=(Assignment)expression;
				          if(thas.getLeftHandSide()!=null&&!(thas.getLeftHandSide() instanceof QualifiedName)) {
						  Expression asEleftExpression=thas.getLeftHandSide();
						  String lString=asEleftExpression.toString();
						  Expression asErightExpression=thas.getRightHandSide();
						  String rString=asErightExpression.toString();	
						  Type type=thIOE.getRightOperand();
						  if(type.isArrayType()) {
						    Type type2=(Type)ASTNode.copySubtree(ast, type);
						    thsvd.setType(type2);
						  }else {
						    Type type2 = ast.newSimpleType(ast.newName(thrString));
						    thsvd.setType(type2);
						  }
						  Expression thIOEl=thIOE.getLeftOperand();
						  thIOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast, thIOEl));
//						  thIOE0.setLeftOperand(ast.newName(thIOE.getLeftOperand().toString()));
						  thsvd.setName(ast.newSimpleName(lString));
						  thIf.setExpression((thIOE0));	
	                      thblock.statements().remove(th);
//	                      System.out.println("if expression num"+th);
					 }
					 }
					 }
				 }
				 
				 
			 }
			 if(thIf.getElseStatement()!=null&&thIf.getElseStatement() instanceof IfStatement) {
				 IfStatement theIfStatement=(IfStatement)thIf.getElseStatement();
				while(theIfStatement instanceof IfStatement) {
					if(theIfStatement.getExpression() instanceof InstanceofExpression) {
						InstanceofExpression thelsExpression=(InstanceofExpression)theIfStatement.getExpression();
						if(thelsExpression.getRightOperand().toString()!=null&&thelsExpression.getLeftOperand().toString()!=null) {
							String thelselString=thelsExpression.getLeftOperand().toString();
							String thelserString=thelsExpression.getRightOperand().toString();
							InstanceofExpression thelseIOE=ast.newInstanceofExpression();
							SingleVariableDeclaration thelseifDeclaration=ast.newSingleVariableDeclaration();
//							thelseIOE.setLeftOperand(ast.newSimpleName(thelsExpression.getLeftOperand().toString()));
							thelseIOE.setPatternVariable(thelseifDeclaration);
							org.eclipse.jdt.core.dom.Statement thelsestatement=theIfStatement.getThenStatement();
							Block thelseblock=(Block)thelsestatement;
							for(int te=0;te<thelseblock.statements().size();te++) {
								if(thelseblock.statements().get(te).toString().contains("(" + thelserString+")")&&thelseblock.statements().get(te)instanceof VariableDeclarationStatement&&!thelseblock.statements().get(te).toString().contains("("+"("+thelserString+")")&&!thelseblock.statements().get(te).toString().contains("new")) {
									VariableDeclarationStatement vdstatement=(VariableDeclarationStatement)thelseblock.statements().get(te);
				                   	VariableDeclaration vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
				  	                String tempName = vDeclarationExpression.getName().toString();
				                    CastExpression castExpression=(CastExpression)vDeclarationExpression.getInitializer();
				                    String type3=castExpression.getType().toString();
				                    Type type4=castExpression.getType();
				                    if(type4.isArrayType()) {
				                    	Type type2=(Type)ASTNode.copySubtree(ast, type4);
				                    	thelseifDeclaration.setType(type2);
				                    }else {
				                    	Type type2 = ast.newSimpleType(ast.newName(thelserString));
				                        thelseifDeclaration.setType(type2);
				                    }
				                    Expression thelseIOEl=thelsExpression.getLeftOperand();
				                    thelseIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast, thelseIOEl));
//			                        thelseIOE.setLeftOperand(ast.newSimpleName(thelsExpression.getLeftOperand().toString()));
			                        thelseifDeclaration.setName(ast.newSimpleName(tempName));
			                        theIfStatement.setExpression(thelseIOE);
			                        thelseblock.statements().remove(te);
//			                        System.out.println("ife variable num"+te);
								}else if(thelseblock.statements().get(te).toString().contains("(" + thelserString+")")&&thelseblock.statements().get(te)instanceof ExpressionStatement&&!thelseblock.statements().get(te).toString().contains("("+"("+thelserString+")")&&!thelseblock.statements().get(te).toString().contains("new")) {
									  Assignment thas=ast.newAssignment();
									  ExpressionStatement expressionStatement=(ExpressionStatement)thelseblock.statements().get(te);
									  Expression expression=expressionStatement.getExpression();
									  if(!(expression instanceof MethodInvocation)) {
							          thas=(Assignment)expression;
							          if(thas.getLeftHandSide()!=null&&!(thas.getLeftHandSide() instanceof QualifiedName)) {
									  Expression asEleftExpression=thas.getLeftHandSide();
									  String lString=asEleftExpression.toString();
									  Expression asErightExpression=thas.getRightHandSide();
									  String rString=asErightExpression.toString();	
									  Type type=thelsExpression.getRightOperand();
									  if(type.isArrayType()) {
										  Type type2 =(Type)ASTNode.copySubtree(ast, type);
										  thelseifDeclaration.setType(type2);
									  }else {
										  Type type2 = ast.newSimpleType(ast.newName(thelserString));
										  thelseifDeclaration.setType(type2);
									  }
									  Expression thelseIOEl=thelsExpression.getLeftOperand();
									  thelseIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast, thelseIOEl));
//									  thelseIOE.setLeftOperand(ast.newSimpleName(thelsExpression.getLeftOperand().toString()));
									  thelseifDeclaration.setName(ast.newSimpleName(lString));
									  theIfStatement.setExpression((thelseIOE));	
				                      thelseblock.statements().remove(te);
//				                      System.out.println("ife expression num"+te);
								}
								}
								}
							}
						}	
					}
					
					if(theIfStatement.getElseStatement() instanceof IfStatement) {
						theIfStatement=(IfStatement)theIfStatement.getElseStatement();
					}else {
						break;
					}
//					theIfStatement=(IfStatement)theIfStatement.getElseStatement();
			   } 
			 }
		}
		}
			}
	}
		   }   }
		   //��else if���ֽ����ع�
		   if(iS.getElseStatement()!=null&&iS.getElseStatement() instanceof IfStatement) {
			   IfStatement eIfStatement=(IfStatement)iS.getElseStatement();
		  while(eIfStatement instanceof IfStatement) {
			  if(eIfStatement.getExpression() instanceof InstanceofExpression) {
//				  System.out.println("elseif is ok");
				  InstanceofExpression elseifexpression=(InstanceofExpression)eIfStatement.getExpression();
				  if(elseifexpression.getLeftOperand().toString()!=null&&elseifexpression.getRightOperand().toString()!=null) {
				  String LelString=elseifexpression.getLeftOperand().toString();
				  String RelString=elseifexpression.getRightOperand().toString();
//				  System.out.println(LelString);
//				  System.out.println(RelString);
				  InstanceofExpression elseifIOE=ast.newInstanceofExpression();
				  SingleVariableDeclaration declaration = ast.newSingleVariableDeclaration();
//				  elseifIOE.setLeftOperand(ast.newSimpleName(elseifexpression.getLeftOperand().toString()));
				  elseifIOE.setPatternVariable(declaration);
				  org.eclipse.jdt.core.dom.Statement statement=eIfStatement.getThenStatement();
				  
				  if(!(statement instanceof ExpressionStatement)&&!(statement instanceof ReturnStatement)&&!(statement instanceof ContinueStatement)&&!(statement instanceof ThrowStatement)) {
				  Block block=(Block)statement;
				  for(int k=0;k<block.statements().size();k++) {
					  if(block.statements().get(k).toString().contains("(" + RelString+")")&&block.statements().get(k)instanceof VariableDeclarationStatement&&!block.statements().get(k).toString().contains("("+"("+RelString+")")&&!block.statements().get(k).toString().contains("new")) {
						  VariableDeclarationStatement vdstatement=(VariableDeclarationStatement)block.statements().get(k);
	                   	  VariableDeclaration vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
	  	                  String tempName = vDeclarationExpression.getName().toString();
	                      CastExpression castExpression=(CastExpression)vDeclarationExpression.getInitializer();
	                      String type3=castExpression.getType().toString();
	                      Type type4=castExpression.getType();
	                      if(type4.isArrayType()) {
	                    	   ArrayType type=(ArrayType) castExpression.getType();
	                    	  Type arratString=type.getElementType();
	                    	  String aString=arratString.toString();
	                    	  Type type2=(Type)ASTNode.copySubtree(ast, type4);
	                    	  declaration.setType(type2);
	                    	  
//	                    	  if(aString.equals("String")) {
//	                    	    	Type type2=ast.newSimpleType(ast.newName(aString));
//	                    	    	declaration.setType(type2);
//	                    	    }
//	                    	  declaration.setName(ast.newSimpleName(tempName));
//	                           eIfStatement.setExpression(elseifIOE);
//	                    	  
	                      }else {
	                      Type type2 = ast.newSimpleType(ast.newName(RelString));
                       declaration.setType(type2);
//                       IOE0.setRightOperand(ast.newSimpleType(ast.newName(ST)));
                        }
//	                      System.out.println(eIfStatement);
	                      Expression elseifl=elseifexpression.getLeftOperand();
	                      elseifIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast, elseifl));
//	                      elseifIOE.setLeftOperand(ast.newSimpleName(elseifexpression.getLeftOperand().toString()));
	                      declaration.setName(ast.newSimpleName(tempName));
                       eIfStatement.setExpression(elseifIOE);
	                      block.statements().remove(k);
//					      System.out.println("varialbe elseif num"+k);

					  }else if (block.statements().get(k).toString().contains("("+RelString+")")&&block.statements().get(k)instanceof ExpressionStatement&&!block.statements().get(k).toString().contains("new")&&!block.statements().get(k).toString().contains("("+"("+RelString+")")) {
						  Assignment as=ast.newAssignment();
						  ExpressionStatement expressionStatement=(ExpressionStatement)block.statements().get(k);
						   Expression expression=expressionStatement.getExpression();
						   if(!(expression instanceof MethodInvocation)) {
				           as=(Assignment)expression;
				           if(as.getLeftHandSide()!=null&&!(as.getLeftHandSide() instanceof QualifiedName)) {
						   Expression asEleftExpression=as.getLeftHandSide();
						   String lString=asEleftExpression.toString();
						   Expression asErightExpression=as.getRightHandSide();
						   String rString=asErightExpression.toString();
						   Type type=elseifexpression.getRightOperand();
						   if(type.isArrayType()) {
							   Type type2=(Type)ASTNode.copySubtree(ast, type);
							   declaration.setType(type2);
						   }else {
							   Type type2 = ast.newSimpleType(ast.newName(RelString));
							   declaration.setType(type2);
						   }
						   Expression elseifl=elseifexpression.getLeftOperand();
						   elseifIOE.setLeftOperand((Expression) ASTNode.copySubtree(ast, elseifl));
//						   elseifIOE.setLeftOperand(ast.newSimpleName(elseifexpression.getLeftOperand().toString()));
						   declaration.setName(ast.newSimpleName(lString));
						   eIfStatement.setExpression(elseifIOE);	
	                       block.statements().remove(k);
//	                       System.out.println("expression elseif num"+k);
				           }
					}
					  }  
				  }
				  }
			  }
			  }
			  if(eIfStatement.getElseStatement() instanceof IfStatement) {
				  eIfStatement=(IfStatement)eIfStatement.getElseStatement();
			  }else {
				  break;
			  }
			  
//			    eIfStatement=(IfStatement)eIfStatement.getElseStatement();
			  
			  
			   }
		 
		
		}
		   
	
	}
}
