package refactoringexample.refactoring;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ArrayAccess;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CastExpression;
import org.eclipse.jdt.core.dom.ContinueStatement;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InstanceofExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.ThrowStatement;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.VariableDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.core.dom.BreakStatement;
import org.eclipse.jdt.core.dom.EmptyStatement;
import org.eclipse.jdt.core.dom.Statement;

public class SolveRefactoring {
  public static void solveIfRefactoring(MethodDeclaration m,IfStatement IS,AST ast) {
	  if(IS.getExpression() instanceof InstanceofExpression) {
		  InstanceofExpression IOE=(InstanceofExpression)IS.getExpression();
		  if(IOE.getLeftOperand().toString()!=null&&IOE.getRightOperand()!=null) {
			  String STL=IOE.getLeftOperand().toString();
			  String STR=IOE.getRightOperand().toString();
			  Expression iOElExpression=IOE.getLeftOperand();
			  InstanceofExpression IOE0=ast.newInstanceofExpression();
			  SingleVariableDeclaration svd = ast.newSingleVariableDeclaration();
			  IOE0.setPatternVariable(svd);
			  Statement statement=IS.getThenStatement();
//			  System.out.println(statement);
			  if(!(statement instanceof ExpressionStatement)&& !(statement instanceof ReturnStatement)&&!(statement instanceof ContinueStatement)&&!(statement instanceof ThrowStatement)&&!(statement instanceof BreakStatement)&&!(statement instanceof IfStatement)&&!(statement instanceof EmptyStatement)) {
//				  System.out.println(statement);
				  Block block=(Block)statement;
				  Assignment as=ast.newAssignment();
				  for(int k=0;k<block.statements().size();k++) {
					  if(block.statements().get(k).toString().contains("("+STR+")")&&block.statements().get(k)instanceof VariableDeclarationStatement&&!block.statements().get(k).toString().contains("("+"("+STR+")")&&!block.statements().get(k).toString().contains("new")) {
						  VariableDeclarationStatement vdstatement=(VariableDeclarationStatement)block.statements().get(k);
					         VariableDeclaration vDeclarationExpression=(VariableDeclaration)(vdstatement.fragments().get(0));
					         CastExpression castExpression=(CastExpression)vDeclarationExpression.getInitializer();
					         String tempName = vDeclarationExpression.getName().toString();
						     String type3=castExpression.getExpression().toString();
		                     Type type4=castExpression.getType();
		                     Type type2=(Type) ASTNode.copySubtree(ast, type4);
		     			     svd.setType(type2);
		     			     IOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast, iOElExpression));
		     			     svd.setName(ast.newSimpleName(tempName));
		     	             IS.setExpression((Expression)IOE0);
		     	             block.statements().remove(k);
		     	             int a=1;
//		     	             System.out.println("variable");
					  }else if(block.statements().get(k).toString().contains("("+STR+")")&&block.statements().get(k)instanceof ExpressionStatement&&!block.statements().get(k).toString().contains("new")&&!block.statements().get(k).toString().contains("("+"("+STR+")"))
					  {
						  ExpressionStatement expressionStatement=(ExpressionStatement)block.statements().get(k);
						  Expression expression=expressionStatement.getExpression();
						  if(!(expression instanceof MethodInvocation)) {
							  as=(Assignment)expression;
						   if(as.getLeftHandSide()!=null&&!(as.getLeftHandSide() instanceof QualifiedName)&&!as.getLeftHandSide().toString().contains("this.")) {
							   Expression asEleftExpression=as.getLeftHandSide();
							   String lString=asEleftExpression.toString();
							   Expression asErightExpression=as.getRightHandSide();
							   String rString=asErightExpression.toString();
								   Type type=IOE.getRightOperand();
								   Type type2=(Type)ASTNode.copySubtree(ast, type);
								   svd.setType(type2);
								   IOE0.setLeftOperand((Expression) ASTNode.copySubtree(ast, iOElExpression));
								   if(asEleftExpression instanceof ArrayAccess) {
									 
									   
								   }
								   else {
									   svd.setName(ast.newSimpleName(lString));
									   block.statements().remove(k);
								   }
								   IS.setExpression((Expression)IOE0);	
//					        	   System.out.println("Expression");
							   
							  
						   }
							  
						  }
					  }
				  }
				  
			  }else {
//				  System.out.println("Does not conform to refactoring rules");
			  }
			  }

		  }
	  }
  }

