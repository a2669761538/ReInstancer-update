package refactoringexample.refactoring;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InstanceofExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.SwitchCase;
import org.eclipse.jdt.core.dom.SwitchStatement;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationExpression;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;

public class InstanceoftoswitchRefactoring {
	public void instanceoftoswitch(TypeDeclaration types, MethodDeclaration m, List<IfStatement> list, AST ast) {
		// TODO Auto-generated method stub
		ReturnStatement returnStatement=ast.newReturnStatement();
		SwitchStatement switchStatement=ast.newSwitchStatement();
		List<SingleVariableDeclaration> svdlist=new ArrayList<SingleVariableDeclaration>();
		List<Expression> exlist=new ArrayList<Expression>();
		if(m.getName().toString().equals("formatter")) {
		for(int i=0;i<m.getBody().statements().size();i++) {
			if(m.getBody().statements().get(i) instanceof IfStatement) {
			IfStatement iS=(IfStatement)m.getBody().statements().get(i);
			   if(iS.getExpression() instanceof InstanceofExpression) { 
				   InstanceofExpression instanceofExpression=(InstanceofExpression)iS.getExpression();
				   Expression lExpression=instanceofExpression.getLeftOperand();
				   String lString=instanceofExpression.getLeftOperand().toString();
				   if(instanceofExpression.getPatternVariable()!=null) {
					   SingleVariableDeclaration svd=instanceofExpression.getPatternVariable();
					   svdlist.add(svd);
					   if(iS.getThenStatement()!=null&&iS.getThenStatement()instanceof Block) {
						   Block block=(Block)iS.getThenStatement();
						   if(block.statements().size()==1&&block.statements().get(0) instanceof ExpressionStatement) {
							   ExpressionStatement expressionStatement=(ExpressionStatement)block.statements().get(0);
							   Expression expression=expressionStatement.getExpression();
							   if(expression instanceof Assignment) {
								   Assignment assignment=(Assignment)expression;
								   String exString=assignment.getLeftHandSide().toString();
								   Expression asExpression=assignment.getRightHandSide();
								   exlist.add(assignment);
								   if(iS.getElseStatement()!=null&&iS.getElseStatement() instanceof IfStatement) {
									   IfStatement eIfStatement=(IfStatement)iS.getElseStatement();
									   while(eIfStatement instanceof IfStatement) {
										   if(eIfStatement.getExpression() instanceof InstanceofExpression) {
											   InstanceofExpression elsInstanceofExpression=(InstanceofExpression)eIfStatement.getExpression();
											   String elString=elsInstanceofExpression.getLeftOperand().toString();
											   if(elString.equals(lString)&&elsInstanceofExpression.getPatternVariable()!=null) {
												   SingleVariableDeclaration elsvd=elsInstanceofExpression.getPatternVariable();
												   svdlist.add(elsvd);
												   if(eIfStatement.getThenStatement()!=null&&eIfStatement.getThenStatement() instanceof Block) {
													   Block eBlock=(Block)eIfStatement.getThenStatement();
													   if(eBlock.statements().size()==1&eBlock.statements().get(0) instanceof ExpressionStatement) {
														   ExpressionStatement inExpressionStatement=(ExpressionStatement)eBlock.statements().get(0);
														   Expression eeExpression=inExpressionStatement.getExpression();
														   if(eeExpression instanceof Assignment) {
															   Assignment eAssignment=(Assignment)eeExpression;
															   String eeString=eAssignment.getLeftHandSide().toString();
															   Expression easExpression=eAssignment.getRightHandSide();
															   if(eeString.equals(exString)) {
																   exlist.add(eAssignment);
																
															   }
														   }else {
															   break;
														   }
														   
													   }
													   
												   }
											   }else {
												   break;
											   }
											   
										   }
										   
										   if(eIfStatement.getElseStatement() instanceof IfStatement) {
												  eIfStatement=(IfStatement)eIfStatement.getElseStatement();
											  }else if(eIfStatement.getElseStatement() instanceof Block){
												  break;
												  }else {
													   Block mBlock=m.getBody();
								                    	 for(int k=0;k<mBlock.statements().size();k++) {
								                    		 if(mBlock.statements().get(k).toString().equals(iS.toString())) {
								                    			 
								                    			 Expression newExpression=(Expression)ASTNode.copySubtree(ast, lExpression);
								                    			 switchStatement.setExpression(newExpression);
								                    			 int j=exlist.size();                    			 
//							                    				   switchCase.expressions().add(aExpression);
								                    			 for(int w=0;w<j;w++) {
								                    				 SwitchCase switchCase=ast.newSwitchCase();
								                    				   SingleVariableDeclaration resvd=(SingleVariableDeclaration)svdlist.get(w);
//								                    				   System.out.println(resvd);
								                    				   VariableDeclarationFragment variableDeclarationFragment=ast.newVariableDeclarationFragment();
											    					   variableDeclarationFragment.setName(ast.newSimpleName(svdlist.get(w).getName().toString()));
											    					   Type type=svdlist.get(w).getType();
											    					   Type copyType=(Type)ASTNode.copySubtree(ast, type);
											    					   VariableDeclarationExpression variableDeclarationExpression=ast.newVariableDeclarationExpression(variableDeclarationFragment);
											    					   variableDeclarationExpression.setType(copyType);
											    					   Expression newvariableExpression=(Expression)variableDeclarationExpression;
								                    				   switchStatement.statements().add(switchCase);
								                    				   switchCase.expressions().add(newvariableExpression);
								                    				   switchCase.setSwitchLabeledRule(true);
								                    				   if(exlist.get(w) instanceof Assignment) {
//								                    					 System.out.println(exlist.get(w));
								                    					 Assignment methodInvocation=(Assignment)exlist.get(w);
								                    					 Assignment mInvocation=ast.newAssignment();
								                    					 mInvocation=(Assignment)ASTNode.copySubtree(ast, methodInvocation);
								                    					 ExpressionStatement expressionStatement2=ast.newExpressionStatement(mInvocation);
								                                         switchStatement.statements().add(expressionStatement2);
								                    					}
//								                    				  
//																	   System.out.println(aExpression);
																	   	 
								                    			 }
//								                    			 System.out.println(switchStatement);
//								                    			 System.out.println(iS);
								                    			 iS.delete();
								                    			 mBlock.statements().add(k,switchStatement);
								                    			 
								                    		 }
								                    	
								                    	 }
								                    	 
													  break;
												  
												  }
									   
								 }
								   }
							   }else {
								   break;
							   }
						   }
						   }
						   
				
					 
				   }
				   
			   }
		}
	
	}
//		System.out.println(svdlist);
//		System.out.println(exlist);
}
}
}