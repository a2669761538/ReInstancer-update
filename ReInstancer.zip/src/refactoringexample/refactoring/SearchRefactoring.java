package refactoringexample.refactoring;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.DoStatement;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.LabeledStatement;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.SynchronizedStatement;
import org.eclipse.jdt.core.dom.TryStatement;
import org.eclipse.jdt.core.dom.WhileStatement;

public class SearchRefactoring {
	MethodDeclaration m;
	int i;
	AST ast;	
	public SearchRefactoring(MethodDeclaration m,int i,AST ast) {
		// TODO Auto-generated constructor stub
		this.m=m;
		this.i=i;
		this.ast=ast;
	}
public void searchIfstatement(IfStatement is) {
	SolveRefactoring.solveIfRefactoring(m, is, ast);
	//���if�ڲ�
	Statement thStatement=is.getThenStatement();
	if(thStatement instanceof Block) {
		Block thBlock=(Block)thStatement;
		searchblock(thBlock);
	}else if(thStatement instanceof IfStatement) {
		IfStatement thIs=(IfStatement)thStatement;
		searchIfstatement(thIs);
	}else if(thStatement instanceof TryStatement) {
		TryStatement thts=(TryStatement)thStatement;
		searchTrystatement(thts);
	}else if(thStatement instanceof ForStatement) {
		ForStatement thfs=(ForStatement)thStatement;
		searchForstatement(thfs);
	}else if(thStatement instanceof DoStatement) {
		DoStatement thds=(DoStatement)thStatement;
		searchDostatement(thds);
	}else if(thStatement instanceof WhileStatement) {
		WhileStatement thws=(WhileStatement)thStatement;
		searchWhilestatement(thws);
	}else if(thStatement instanceof SynchronizedStatement) {
		SynchronizedStatement thss=(SynchronizedStatement)thStatement;
		searchSynchronizedstatement(thss);
	}else if(thStatement instanceof LabeledStatement) {
		LabeledStatement thls=(LabeledStatement)thStatement;
		searchLabeledstatement(thls);
	}
	//���else if����
	Statement elStatement=is.getElseStatement();
	if(elStatement instanceof TryStatement) {
		TryStatement ets=(TryStatement)elStatement;
		searchTrystatement(ets);
	}else if(elStatement instanceof IfStatement) {
		IfStatement eis=(IfStatement)elStatement;
		searchIfstatement(eis);
	}else if(elStatement instanceof ForStatement) {
		ForStatement efs=(ForStatement)elStatement;
		searchForstatement(efs);
	}else if(elStatement instanceof Block) {
		Block ebl=(Block)elStatement;
		searchblock(ebl);		
	}else if(elStatement instanceof DoStatement) {
		DoStatement eds=(DoStatement)elStatement;
		searchDostatement(eds);
	}else if(elStatement instanceof WhileStatement) {
		WhileStatement ews=(WhileStatement)elStatement;
		searchWhilestatement(ews);
	}else if(elStatement instanceof SynchronizedStatement) {
		SynchronizedStatement ess=(SynchronizedStatement)elStatement;
		searchSynchronizedstatement(ess);
	}else if(elStatement instanceof LabeledStatement) {
		LabeledStatement els=(LabeledStatement)elStatement;
		searchLabeledstatement(els);
	}
      
}
public void searchTrystatement(TryStatement ts) {
	Statement tStatement=ts.getBody();
	if(tStatement instanceof TryStatement) {
		TryStatement tts=(TryStatement)tStatement;
		searchTrystatement(tts);
	}else if(tStatement instanceof IfStatement) {
		IfStatement tis=(IfStatement)tStatement;
		searchIfstatement(tis);
	}else if(tStatement instanceof ForStatement) {
		ForStatement tfs=(ForStatement)tStatement;
		searchForstatement(tfs);
	}else if(tStatement instanceof Block) {
		Block tbl=(Block)tStatement;
		searchblock(tbl);		
	}else if(tStatement instanceof DoStatement) {
		DoStatement tds=(DoStatement)tStatement;
		searchDostatement(tds);
	}else if(tStatement instanceof WhileStatement) {
		WhileStatement tws=(WhileStatement)tStatement;
		searchWhilestatement(tws);
	}else if(tStatement instanceof SynchronizedStatement) {
		SynchronizedStatement tss=(SynchronizedStatement)tStatement;
		searchSynchronizedstatement(tss);
	}else if(tStatement instanceof LabeledStatement) {
		LabeledStatement tls=(LabeledStatement)tStatement;
		searchLabeledstatement(tls);
	}
}

public void searchForstatement(ForStatement fs) {
	Statement fStatement=fs.getBody();
	if(fStatement instanceof IfStatement) {
		IfStatement fis=(IfStatement)fStatement;
		searchIfstatement(fis);
	}else if(fStatement instanceof ForStatement) {
		ForStatement ffs=(ForStatement)fStatement;
		searchForstatement(ffs);
	}else if(fStatement instanceof TryStatement) {
		TryStatement fts=(TryStatement)fStatement;
		searchTrystatement(fts);
	}else if(fStatement instanceof Block) {
		Block fbl=(Block)fStatement;
		searchblock(fbl);		
	}else if(fStatement instanceof DoStatement) {
		DoStatement fds=(DoStatement)fStatement;
		searchDostatement(fds);
	}else if(fStatement instanceof WhileStatement) {
		WhileStatement fws=(WhileStatement)fStatement;
		searchWhilestatement(fws);
	}else if(fStatement instanceof SynchronizedStatement) {
		SynchronizedStatement fss=(SynchronizedStatement)fStatement;
		searchSynchronizedstatement(fss);
	}else if(fStatement instanceof LabeledStatement) {
		LabeledStatement fls=(LabeledStatement)fStatement;
		searchLabeledstatement(fls);
	}
}
public void searchblock(Block BL) {
	for(int i=0;i<BL.statements().size();i++) {
		Statement bStatement=(Statement) BL.statements().get(i);
		if(bStatement instanceof IfStatement) {
			IfStatement bis=(IfStatement)bStatement;
			searchIfstatement(bis);
		}else if(bStatement instanceof ForStatement) {
			ForStatement bfs=(ForStatement)bStatement;
			searchForstatement(bfs);
		}else if(bStatement instanceof TryStatement) {
			TryStatement bts=(TryStatement)bStatement;
			searchTrystatement(bts);
		}else if(bStatement instanceof Block) {
			Block bbl=(Block)bStatement;
			searchblock(bbl);		
		}else if(bStatement instanceof DoStatement) {
			DoStatement bds=(DoStatement)bStatement;
			searchDostatement(bds);
		}else if(bStatement instanceof WhileStatement) {
			WhileStatement  bws=(WhileStatement)bStatement;
			searchWhilestatement(bws);
		}else if(bStatement instanceof SynchronizedStatement) {
			SynchronizedStatement bss=(SynchronizedStatement)bStatement;
			searchSynchronizedstatement(bss);
		}else if(bStatement instanceof LabeledStatement) {
			LabeledStatement bls=(LabeledStatement)bStatement;
			searchLabeledstatement(bls);
		}
	}
}
public void searchDostatement(DoStatement ds) {
	Statement dStatement=ds.getBody();
	if(dStatement instanceof IfStatement) {
		IfStatement dis=(IfStatement)dStatement;
		searchIfstatement(dis);
	}else if(dStatement instanceof TryStatement) {
		TryStatement dts=(TryStatement)dStatement;
		searchTrystatement(dts);
	}else if(dStatement instanceof ForStatement) {
		ForStatement dfs=(ForStatement)dStatement;
		searchForstatement(dfs);
	}else if(dStatement instanceof Block) {
		Block dbl=(Block)dStatement;
		searchblock(dbl);
	}else if(dStatement instanceof DoStatement) {
		DoStatement dds=(DoStatement)dStatement;
		searchDostatement(dds);
	}else if(dStatement instanceof WhileStatement) {
		WhileStatement dws=(WhileStatement)dStatement;
		searchWhilestatement(dws);
	}else if(dStatement instanceof SynchronizedStatement) {
		SynchronizedStatement dss=(SynchronizedStatement)dStatement;
		searchSynchronizedstatement(dss);
	}else if(dStatement instanceof LabeledStatement) {
		LabeledStatement dls=(LabeledStatement)dStatement;
		searchLabeledstatement(dls);
	}
}
public void searchWhilestatement(WhileStatement ws) {
	Statement wStatement=ws.getBody();
	if(wStatement instanceof IfStatement) {
		IfStatement wis=(IfStatement)wStatement;
		searchIfstatement(wis);
	}else if(wStatement instanceof ForStatement) {
		ForStatement wfs=(ForStatement)wStatement;
		searchForstatement(wfs);
	}else if(wStatement instanceof TryStatement) {
		TryStatement wts=(TryStatement)wStatement;
		searchTrystatement(wts);
	}else if(wStatement instanceof Block) {
		Block wbl=(Block)wStatement;
		searchblock(wbl);
	}else if(wStatement instanceof DoStatement) {
		DoStatement wds=(DoStatement)wStatement;
		searchDostatement(wds);
	}else if(wStatement instanceof WhileStatement) {
		WhileStatement wws=(WhileStatement)wStatement;
		searchWhilestatement(wws);
	}else if(wStatement instanceof SynchronizedStatement) {
		SynchronizedStatement wss=(SynchronizedStatement)wStatement;
		searchSynchronizedstatement(wss);
	}else if(wStatement instanceof LabeledStatement) {
		 LabeledStatement wls=(LabeledStatement)wStatement;
		 searchLabeledstatement(wls);
	}
}
public void searchSynchronizedstatement(SynchronizedStatement ss) {
	Statement sStatement=ss.getBody();
	if(sStatement instanceof IfStatement) {
		IfStatement sis=(IfStatement)sStatement;
		searchIfstatement(sis);
	}else if(sStatement instanceof ForStatement) {
		ForStatement sfs=(ForStatement)sStatement;
		searchForstatement(sfs);
    }else if(sStatement instanceof TryStatement) {
    	TryStatement sts=(TryStatement)sStatement;
    	searchTrystatement(sts);
    }else if(sStatement instanceof Block) {
    	Block sbl=(Block)sStatement;
    	searchblock(sbl);
    }else if(sStatement instanceof DoStatement) {
    	DoStatement sdt=(DoStatement)sStatement;
    	searchDostatement(sdt);
    }else if(sStatement instanceof WhileStatement) {
    	WhileStatement swt=(WhileStatement)sStatement;
    	searchWhilestatement(swt);
    }else if(sStatement instanceof SynchronizedStatement) {
    	SynchronizedStatement sss=(SynchronizedStatement)sStatement;
    	searchSynchronizedstatement(sss);
    }else if(sStatement instanceof LabeledStatement) {
    	LabeledStatement sls=(LabeledStatement)sStatement;
    	searchLabeledstatement(sls);
    }
}

public void searchLabeledstatement(LabeledStatement ls) {
	Statement lStatement=ls.getBody();
	if(lStatement instanceof IfStatement) {
		IfStatement lis=(IfStatement)lStatement;
		searchIfstatement(lis);
	}else if(lStatement instanceof TryStatement) {
		TryStatement lts=(TryStatement)lStatement;
		searchTrystatement(lts);
	}else if(lStatement instanceof ForStatement) {
		ForStatement lfs=(ForStatement)lStatement;
		searchForstatement(lfs);
	}else if(lStatement instanceof Block) {
		Block lbl=(Block)lStatement;
		searchblock(lbl);
	}else if(lStatement instanceof DoStatement) {
		DoStatement lds= (DoStatement)lStatement;
		searchDostatement(lds);
	}else if(lStatement instanceof WhileStatement) {
		WhileStatement lws=(WhileStatement)lStatement;
		searchWhilestatement(lws);
	}else if(lStatement instanceof SynchronizedStatement) {
		SynchronizedStatement lss=(SynchronizedStatement)lStatement;
		searchSynchronizedstatement(lss);
	}else if(lStatement instanceof LabeledStatement) {
		LabeledStatement lls=(LabeledStatement)lStatement;
		searchLabeledstatement(lls);
	}
}
}
/*



public void searchExpressionstatement(Statement ES) {
	
}

public void searchLabeledstatement(LabeledStatement LS) {
	
}

*/